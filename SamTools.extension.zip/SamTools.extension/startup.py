# Python startup script (cleared out)
