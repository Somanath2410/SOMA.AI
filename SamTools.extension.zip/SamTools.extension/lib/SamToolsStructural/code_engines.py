# -*- coding: utf-8 -*-

class IS456Engine:
    name = "IS 456 (India)"
    
    @staticmethod
    def validate_column_slenderness(effective_length, least_lateral_dimension):
        # Ratio l/d should not exceed 60
        ratio = effective_length / least_lateral_dimension
        return ratio <= 60.0
        
    @staticmethod
    def calculate_min_eccentricity(unsupported_length, lateral_dimension):
        return max(20.0, (unsupported_length / 500.0) + (lateral_dimension / 30.0))
        
    @staticmethod
    def validate_beam_span_depth(span, effective_depth, is_cantilever=False, is_continuous=False):
        ratio = span / effective_depth
        if is_cantilever:
            return ratio <= 7.0
        elif is_continuous:
            return ratio <= 26.0
        else:
            return ratio <= 20.0

class Eurocode2Engine:
    name = "Eurocode 2 (Europe)"
    
    @staticmethod
    def validate_column_slenderness(effective_length, least_lateral_dimension):
        # Simplistic placeholder for Eurocode checks
        return (effective_length / least_lateral_dimension) <= 50.0

def get_engine(code_name):
    if "IS 456" in code_name:
        return IS456Engine
    elif "Eurocode" in code_name:
        return Eurocode2Engine
    return IS456Engine # default
