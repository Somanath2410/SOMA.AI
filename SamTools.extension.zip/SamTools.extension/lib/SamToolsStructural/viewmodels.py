# -*- coding: utf-8 -*-
from pyrevit import forms

class ControlCenterVM(forms.Reactive):
    def __init__(self):
        # WPF bindings
        self.ProjectName = "Loading..."
        self.CurrentLevel = "Loading..."
        self.CurrentSelectionCount = "0 Elements"
        
        # Stats
        self.TotalColumns = 0
        self.TotalBeams = 0
        self.TotalSlabs = 0
        
        # QAQC
        self.WarningCount = 0
        self.DisconnectedCount = 0
        
        # Combobox
        self.AvailableDesignCodes = [
            "IS 456 (India)",
            "IS 13920 (Seismic)",
            "Eurocode 2 (Europe)",
            "ACI 318 (USA)"
        ]
        self.SelectedDesignCode = self.AvailableDesignCodes[0]
