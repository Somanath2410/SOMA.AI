# -*- coding: utf-8 -*-
from pyrevit import DB

def find_duplicate_elements(doc, built_in_category):
    collector = DB.FilteredElementCollector(doc).OfCategory(built_in_category).WhereElementIsNotElementType()
    locations = {}
    duplicates = []
    
    for element in collector:
        loc = element.Location
        if isinstance(loc, DB.LocationPoint):
            pt = loc.Point
            key = "{:.3f},{:.3f},{:.3f}".format(pt.X, pt.Y, pt.Z)
            if key in locations:
                duplicates.append((element, locations[key]))
            else:
                locations[key] = element
    return duplicates

def find_unconnected_columns(doc):
    columns = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_StructuralColumns).WhereElementIsNotElementType()
    unconnected = []
    for col in columns:
        top_level = col.get_Parameter(DB.BuiltInParameter.FAMILY_TOP_LEVEL_PARAM)
        if top_level and top_level.AsElementId() == DB.ElementId.InvalidElementId:
            unconnected.append(col)
    return unconnected
