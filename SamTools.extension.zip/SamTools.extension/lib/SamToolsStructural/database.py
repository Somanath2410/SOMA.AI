import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "StructuralData.db")

def get_connection():
    return sqlite3.connect(DB_PATH)

def init_db():
    conn = get_connection()
    cursor = conn.cursor()
    
    # Create Settings Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS ProjectSettings (
            Key TEXT PRIMARY KEY,
            Value TEXT NOT NULL
        )
    ''')
    
    # Create QAQC Warnings Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS QAQCWarnings (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            ElementId INTEGER NOT NULL,
            Category TEXT NOT NULL,
            Severity TEXT NOT NULL,
            Description TEXT NOT NULL,
            Timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()

def save_setting(key, value):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT OR REPLACE INTO ProjectSettings (Key, Value) VALUES (?, ?)", (key, str(value)))
    conn.commit()
    conn.close()

def get_setting(key, default=None):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT Value FROM ProjectSettings WHERE Key = ?", (key,))
    row = cursor.fetchone()
    conn.close()
    if row: return row[0]
    return default

def log_qaqc_warning(element_id, category, severity, description):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO QAQCWarnings (ElementId, Category, Severity, Description)
        VALUES (?, ?, ?, ?)
    ''', (element_id, category, severity, description))
    conn.commit()
    conn.close()

# Initialize DB on import
init_db()
