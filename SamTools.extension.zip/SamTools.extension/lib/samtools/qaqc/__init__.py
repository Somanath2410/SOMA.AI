# -*- coding: utf-8 -*-
"""
SamTools QA/QC Model Audit Module
Provides automated model health audit, parameter compliance, and geometry checks.
"""

from samtools.qaqc.audit_engine import QAQCAuditEngine
