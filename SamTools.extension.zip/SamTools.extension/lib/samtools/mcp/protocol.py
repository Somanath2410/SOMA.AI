# -*- coding: utf-8 -*-
"""
SamTools MCP JSON-RPC 2.0 Protocol Handler
Handles incoming MCP requests and dispatches them to MCPToolRegistry.
"""

import json
from samtools.mcp.registry import MCPToolRegistry


class MCPProtocolHandler(object):
    """JSON-RPC 2.0 message handler for Model Context Protocol interactions."""

    def __init__(self, doc=None):
        self.doc = doc

    def handle_request(self, json_string):
        """
        Process an incoming JSON-RPC 2.0 request string.
        :param json_string: Raw JSON request body
        :return: String JSON response body
        """
        try:
            req = json.loads(json_string)
        except Exception as e:
            return json.dumps({
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32700, "message": "Parse error: " + str(e)}
            })

        msg_id = req.get("id")
        method = req.get("method")
        params = req.get("params", {})

        if not method:
            return json.dumps({
                "jsonrpc": "2.0",
                "id": msg_id,
                "error": {"code": -32600, "message": "Invalid Request: missing method"}
            })

        try:
            if method == "initialize":
                result = {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {
                        "tools": {}
                    },
                    "serverInfo": {
                        "name": "SamTools Revit Automation Server",
                        "version": "1.0.0"
                    }
                }
            elif method == "tools/list":
                result = MCPToolRegistry.get_mcp_tools_list()
            elif method == "tools/call":
                tool_name = params.get("name")
                arguments = params.get("arguments", {})
                result = MCPToolRegistry.call_mcp_tool(tool_name, arguments, self.doc)
            elif method == "prompts/list":
                result = {
                    "prompts": [
                        {
                            "name": "audit_model_health",
                            "description": "Execute comprehensive ISO 19650 BIM QA/QC health audit."
                        },
                        {
                            "name": "generate_datacenter_layout",
                            "description": "Calculate optimal server rack layouts and compute MW power capacities."
                        }
                    ]
                }
            elif method == "resources/list":
                result = {
                    "resources": [
                        {
                            "uri": "revit://active_model/summary",
                            "name": "Active Document Summary",
                            "mimeType": "application/json"
                        }
                    ]
                }
            elif method == "ping":
                result = {}
            else:
                return json.dumps({
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "error": {"code": -32601, "message": "Method not found: '{}'".format(method)}
                })


            return json.dumps({
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": result
            })

        except Exception as ex:
            return json.dumps({
                "jsonrpc": "2.0",
                "id": msg_id,
                "error": {"code": -32603, "message": "Internal error: " + str(ex)}
            })
