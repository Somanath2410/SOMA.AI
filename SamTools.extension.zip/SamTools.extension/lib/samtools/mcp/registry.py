# -*- coding: utf-8 -*-
"""
SamTools MCP Tool Registry & Schema Bridge
Binds registered SamTools tools into standardized Model Context Protocol (MCP) tool schemas.
"""

import json
from SamTools.tab.AIAssistant.panel.SomaChat.pushbutton.ai_commands import ToolRegistry


class MCPToolRegistry(object):
    """Bridge providing MCP protocol compatible tool schemas and execution."""

    @classmethod
    def get_mcp_tools_list(cls):
        """
        Formats registered tools into MCP tools/list JSON response structure.
        """
        raw_tools = ToolRegistry.list_tools()
        mcp_tools = []
        for t in raw_tools:
            mcp_tools.append({
                "name": t["name"],
                "description": t["description"],
                "inputSchema": t.get("parameters") or {
                    "type": "object",
                    "properties": {}
                }
            })
        return {"tools": mcp_tools}

    @classmethod
    def call_mcp_tool(cls, name, arguments, doc):
        """
        Executes a registered tool call request formatted per MCP tools/call standard.
        :param name: String tool name
        :param arguments: Dict tool parameters
        :param doc: Active Revit Document
        :return: Dict MCP formatted response {"content": [{"type": "text", "text": "..."}], "isError": bool}
        """
        if not arguments:
            arguments = {}

        result = ToolRegistry.execute(name, doc, **arguments)
        
        success = result.get("success", False)
        message = result.get("message", "")

        return {
            "content": [
                {
                    "type": "text",
                    "text": message
                }
            ],
            "isError": not success
        }
