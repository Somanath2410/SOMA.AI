# -*- coding: utf-8 -*-
"""
SamTools Sheet Management Service
Handles ISO sheet generation, title block parameter binding, and batch sheet creation.
"""

from samtools.core.base_mvc import DocumentContext

try:
    from pyrevit import DB
except ImportError:
    DB = None


class SheetService(object):
    """Production service for sheet creation, naming validation, and titling."""

    def __init__(self, doc=None):
        self.ctx = DocumentContext(doc)
        self.doc = self.ctx.doc

    def get_default_titleblock(self):
        """Retrieve the first loaded title block family symbol in the document."""
        if not self.ctx.is_valid or not DB:
            return None
        collector = DB.FilteredElementCollector(self.doc).OfCategory(DB.BuiltInCategory.OST_TitleBlocks).WhereElementIsElementType()
        titleblocks = collector.ToElements()
        return titleblocks[0] if titleblocks else None

    def find_sheet_by_number(self, sheet_number):
        """Find an existing ViewSheet by its sheet number."""
        if not self.ctx.is_valid or not DB:
            return None
        sheets = DB.FilteredElementCollector(self.doc).OfClass(DB.ViewSheet).ToElements()
        for s in sheets:
            if hasattr(s, "SheetNumber") and s.SheetNumber.strip().upper() == str(sheet_number).strip().upper():
                return s
        return None

    def update_sheet_metadata(self, sheet, drawn_by=None, checked_by=None, issue_date=None, project_number=None):
        """Update standard sheet parameter metadata."""
        if not sheet or not DB:
            return False

        with self.ctx.transaction("Update Sheet Metadata"):
            if drawn_by:
                p = sheet.get_Parameter(DB.BuiltInParameter.SHEET_DRAWN_BY)
                if p: p.Set(str(drawn_by))
            if checked_by:
                p = sheet.get_Parameter(DB.BuiltInParameter.SHEET_CHECKED_BY)
                if p: p.Set(str(checked_by))
            if issue_date:
                p = sheet.get_Parameter(DB.BuiltInParameter.SHEET_ISSUE_DATE)
                if p: p.Set(str(issue_date))
        return True

    def create_sheet(self, sheet_number, sheet_name, titleblock_id=None, drawn_by=None, checked_by=None):
        """
        Create a single drawing sheet.
        :param sheet_number: String ISO sheet number (e.g. A-101)
        :param sheet_name: String sheet title (e.g. FIRST FLOOR PLAN)
        :param titleblock_id: Optional ElementId of titleblock symbol
        :param drawn_by: Optional string initial/name
        :param checked_by: Optional string initial/name
        :return: Created ViewSheet element or None
        """
        if not self.ctx.is_valid or not DB:
            return None

        if not titleblock_id:
            tb = self.get_default_titleblock()
            if not tb:
                raise ValueError("No titleblock families are loaded in the project model.")
            titleblock_id = tb.Id

        with self.ctx.transaction("Create Sheet " + str(sheet_number)):
            sheet = DB.ViewSheet.Create(self.doc, titleblock_id)
            sheet.Name = sheet_name
            try:
                sheet.SheetNumber = sheet_number
            except Exception:
                sheet.SheetNumber = str(sheet_number) + "_DUP"

            if drawn_by:
                p = sheet.get_Parameter(DB.BuiltInParameter.SHEET_DRAWN_BY)
                if p: p.Set(str(drawn_by))
            if checked_by:
                p = sheet.get_Parameter(DB.BuiltInParameter.SHEET_CHECKED_BY)
                if p: p.Set(str(checked_by))

            return sheet

    def batch_create_sheets(self, sheet_definitions):
        """
        Batch create sheets from a list of dict definitions.
        :param sheet_definitions: List of dicts [{"number": "A-101", "name": "Ground Plan", "drawn_by": "SM"}, ...]
        :return: List of created ViewSheet elements
        """
        if not self.ctx.is_valid or not DB:
            return []

        tb = self.get_default_titleblock()
        if not tb:
            raise ValueError("No titleblock family loaded in model.")

        created = []
        with self.ctx.transaction("Batch Create Sheets"):
            for item in sheet_definitions:
                s_num = item.get("number", "A-000")
                s_name = item.get("name", "UNNAMED SHEET")
                
                sheet = DB.ViewSheet.Create(self.doc, tb.Id)
                sheet.Name = s_name
                try:
                    sheet.SheetNumber = s_num
                except Exception:
                    sheet.SheetNumber = str(s_num) + "_" + str(len(created) + 1)

                if "drawn_by" in item:
                    p = sheet.get_Parameter(DB.BuiltInParameter.SHEET_DRAWN_BY)
                    if p: p.Set(str(item["drawn_by"]))

                created.append(sheet)
        return created

