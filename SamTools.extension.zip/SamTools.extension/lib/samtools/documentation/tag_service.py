# -*- coding: utf-8 -*-
"""
SamTools Element Auto-Tagging Service
Handles category-based automatic tagging in views for Architectural, Structural, and MEP elements.
"""

from samtools.core.base_mvc import DocumentContext

try:
    from pyrevit import DB
except ImportError:
    DB = None


class TagService(object):
    """Production service for element auto-tagging."""

    def __init__(self, doc=None):
        self.ctx = DocumentContext(doc)
        self.doc = self.ctx.doc

    def tag_elements_in_view(self, view, category_enum, add_leader=False):
        """
        Auto-tag all untagged elements of a given category in the target view.
        :param view: Active View element
        :param category_enum: BuiltInCategory enum (e.g. BuiltInCategory.OST_Doors)
        :param add_leader: Bool whether to attach leader line to tags
        :return: Count of newly created tags
        """
        if not self.ctx.is_valid or not DB:
            return 0

        view_id = view.Id if hasattr(view, 'Id') else view
        collector = DB.FilteredElementCollector(self.doc, view_id).OfCategory(category_enum).WhereElementIsNotElementType()
        elements = collector.ToElements()

        tagged_count = 0
        with self.ctx.transaction("Auto-Tag Category"):
            for elem in elements:
                loc = elem.Location
                if loc and hasattr(loc, 'Point'):
                    pt = loc.Point
                elif loc and hasattr(loc, 'Curve'):
                    pt = loc.Curve.Evaluate(0.5, True)
                else:
                    continue

                try:
                    ref = DB.Reference(elem)
                    tag = DB.IndependentTag.Create(
                        self.doc,
                        view_id,
                        ref,
                        add_leader,
                        DB.TagMode.TM_ADDBY_CATEGORY,
                        DB.TagOrientation.Horizontal,
                        pt
                    )
                    if tag:
                        tagged_count += 1
                except Exception:
                    pass

        return tagged_count

    def tag_multiple_categories(self, view, category_enums):
        """
        Batch auto-tag elements across multiple categories (e.g. Doors, Windows, Equipment, Cable Trays).
        :param view: Active View element
        :param category_enums: List of BuiltInCategory enums
        :return: Dict summary with category counts and total tags created
        """
        results = {"total_tags": 0, "categories": {}}
        for cat in category_enums:
            count = self.tag_elements_in_view(view, cat)
            cat_name = str(cat).split(".")[-1]
            results["categories"][cat_name] = count
            results["total_tags"] += count
        return results

