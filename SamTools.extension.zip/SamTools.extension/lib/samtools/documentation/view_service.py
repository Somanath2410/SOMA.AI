# -*- coding: utf-8 -*-
"""
SamTools View Placement & Layout Service
Handles view placement on sheets, viewport grid alignment, and view template binding.
"""

from samtools.core.base_mvc import DocumentContext

try:
    from pyrevit import DB
except ImportError:
    DB = None


class ViewService(object):
    """Production service for view creation, placement, and grid alignment."""

    def __init__(self, doc=None):
        self.ctx = DocumentContext(doc)
        self.doc = self.ctx.doc

    def can_add_view_to_sheet(self, sheet_id, view_id):
        """Check if a view can be legally added to a sheet."""
        if not self.ctx.is_valid or not DB:
            return False
        return DB.Viewport.CanAddViewToSheet(self.doc, sheet_id, view_id)

    def place_view_on_sheet(self, sheet, view, point_xyz=None):
        """
        Place a view onto a target sheet.
        :param sheet: ViewSheet object or ElementId
        :param view: View object or ElementId
        :param point_xyz: Sheet location XYZ (defaults to sheet center [1.5, 1.0, 0])
        :return: Created Viewport instance or None
        """
        if not self.ctx.is_valid or not DB:
            return None

        sheet_id = sheet.Id if hasattr(sheet, 'Id') else sheet
        view_id = view.Id if hasattr(view, 'Id') else view

        if not self.can_add_view_to_sheet(sheet_id, view_id):
            raise ValueError("View cannot be added to target sheet (may already be placed).")

        if not point_xyz:
            point_xyz = DB.XYZ(1.5, 1.0, 0)

        with self.ctx.transaction("Place View on Sheet"):
            viewport = DB.Viewport.Create(self.doc, sheet_id, view_id, point_xyz)
            return viewport

    def align_viewports_grid(self, sheet, view_ids, rows=2, cols=2, origin_x=0.5, origin_y=0.5, spacing_x=1.2, spacing_y=0.9):
        """
        Automatically arrange multiple views on a sheet in a clean uniform grid layout.
        :param sheet: Target ViewSheet object
        :param view_ids: List of View ElementIds
        :param rows: Integer grid rows
        :param cols: Integer grid columns
        :param origin_x: Bottom-left grid X coordinate on sheet (ft)
        :param origin_y: Bottom-left grid Y coordinate on sheet (ft)
        :param spacing_x: Horizontal viewport spacing (ft)
        :param spacing_y: Vertical viewport spacing (ft)
        :return: List of created Viewport instances
        """
        if not self.ctx.is_valid or not DB:
            return []

        sheet_id = sheet.Id if hasattr(sheet, 'Id') else sheet
        created_viewports = []

        with self.ctx.transaction("Align Viewports Grid"):
            idx = 0
            for r in range(rows):
                for c in range(cols):
                    if idx >= len(view_ids):
                        break
                    v_id = view_ids[idx]
                    v_elem_id = v_id if hasattr(v_id, 'IntegerValue') else DB.ElementId(int(v_id))

                    if DB.Viewport.CanAddViewToSheet(self.doc, sheet_id, v_elem_id):
                        x = origin_x + (c * spacing_x)
                        y = origin_y + ((rows - 1 - r) * spacing_y)
                        pt = DB.XYZ(x, y, 0)
                        vp = DB.Viewport.Create(self.doc, sheet_id, v_elem_id, pt)
                        created_viewports.append(vp)
                    idx += 1

        return created_viewports

