# -*- coding: utf-8 -*-
"""
SamTools Data Centre Cable Tray Router
Combines SpatialGrid collision checking and A* pathfinding to generate clash-free cable tray routes,
supporting multi-tier overhead/underfloor elevations, cable fill capacity calculations, and path metrics.
"""

import math
from samtools.utils.geometry import SpatialGrid, PathFinder
from samtools.core.base_mvc import DocumentContext

try:
    from pyrevit import DB
except ImportError:
    DB = None


class CableTrayRouter(object):
    """Automated cable tray routing engine with 3D obstacle avoidance and multi-tier routing."""

    def __init__(self, doc=None, step_size=1.0):
        self.ctx = DocumentContext(doc)
        self.doc = self.ctx.doc
        self.path_finder = PathFinder(step_size=step_size)
        self.spatial_grid = SpatialGrid(cell_size=step_size)

    def populate_obstacles_from_model(self, categories=None):
        """
        Populate spatial grid obstacles from active Revit model elements.
        :param categories: List of BuiltInCategory values (e.g. OST_StructuralFraming, OST_Walls, OST_DuctCurves)
        """
        if not self.ctx.is_valid or not DB:
            return

        if not categories:
            categories = [
                DB.BuiltInCategory.OST_StructuralFraming,
                DB.BuiltInCategory.OST_StructuralColumns,
                DB.BuiltInCategory.OST_Walls,
                DB.BuiltInCategory.OST_DuctCurves,
                DB.BuiltInCategory.OST_MechanicalEquipment
            ]

        for cat in categories:
            collector = DB.FilteredElementCollector(self.doc).OfCategory(cat).WhereElementIsNotElementType()
            for elem in collector:
                bbox = elem.get_BoundingBox(None)
                if bbox and bbox.Min and bbox.Max:
                    self.spatial_grid.add_obstacle_bbox(bbox.Min, bbox.Max, clearance=0.5)

    def calculate_tray_sizing(self, cable_count, avg_cable_dia_in=0.3, max_fill_pct=40.0, tray_depth_in=4.0):
        """
        Calculate required cable tray width based on NEC 40% maximum cable fill ratio rules.
        :param cable_count: Total number of cables in tray
        :param avg_cable_dia_in: Average cable outer diameter in inches
        :param max_fill_pct: Maximum allowed fill percentage (NEC default 40%)
        :param tray_depth_in: Standard tray side-rail depth in inches (e.g. 4.0 in)
        :return: Dict with required_width_in, recommended_tray_width_in, fill_pct
        """
        cable_area_sqin = cable_count * (math.pi * (avg_cable_dia_in / 2.0)**2)
        req_tray_area_sqin = cable_area_sqin / (max_fill_pct / 100.0)
        req_width_in = req_tray_area_sqin / tray_depth_in

        # Round up to standard tray width increments (6, 12, 18, 24, 30, 36 inches)
        std_widths = [6.0, 12.0, 18.0, 24.0, 30.0, 36.0]
        recommended_width = std_widths[-1]
        for w in std_widths:
            if w >= req_width_in:
                recommended_width = w
                break

        return {
            "cable_count": cable_count,
            "total_cable_area_sqin": round(cable_area_sqin, 2),
            "required_width_in": round(req_width_in, 2),
            "recommended_width_in": recommended_width,
            "max_fill_pct": max_fill_pct
        }

    def compute_path_length(self, path):
        """Calculate total Euclidean 3D length of a routed path."""
        if not path or len(path) < 2:
            return 0.0
        total_len = 0.0
        for i in range(len(path) - 1):
            p1, p2 = path[i], path[i + 1]
            dx = p2[0] - p1[0]
            dy = p2[1] - p1[1]
            dz = p2[2] - p1[2]
            total_len += (dx*dx + dy*dy + dz*dz)**0.5
        return round(total_len, 2)

    def compute_route(self, start_xyz, end_xyz, tier_elevation=None):
        """
        Compute an obstacle-free 3D cable tray path.
        :param start_xyz: Start coordinate XYZ or tuple
        :param end_xyz: Target coordinate XYZ or tuple
        :param tier_elevation: Optional float override for tray routing Z elevation (ft)
        :return: List of 3D point tuples
        """
        s = list(start_xyz) if hasattr(start_xyz, '__getitem__') else [start_xyz.X, start_xyz.Y, start_xyz.Z]
        e = list(end_xyz) if hasattr(end_xyz, '__getitem__') else [end_xyz.X, end_xyz.Y, end_xyz.Z]

        if tier_elevation is not None:
            s[2] = float(tier_elevation)
            e[2] = float(tier_elevation)

        path = self.path_finder.find_path(tuple(s), tuple(e), spatial_grid=self.spatial_grid)
        return path

