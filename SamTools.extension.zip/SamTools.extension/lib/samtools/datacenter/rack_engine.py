# -*- coding: utf-8 -*-
"""
SamTools Data Centre Rack Layout Engine
Calculates optimal server rack grid coordinates, hot/cold aisle configurations, clearance zones, and power capacity metrics.
"""

import math
from samtools.core.base_mvc import DocumentContext

try:
    from pyrevit import DB
except ImportError:
    DB = None


class RackLayoutEngine(object):
    """Engine for generating Data Centre server rack row layouts and computing thermal/power capacities."""

    def __init__(self, rack_width=2.0, rack_depth=3.5, cold_aisle=4.0, hot_aisle=3.0, kw_per_rack=10.0):
        """
        :param rack_width: Rack width in feet (default 2.0 ft / 600mm)
        :param rack_depth: Rack depth in feet (default 3.5 ft / 1050mm)
        :param cold_aisle: Cold aisle width in feet (default 4.0 ft / 1200mm)
        :param hot_aisle: Hot aisle width in feet (default 3.0 ft / 900mm)
        :param kw_per_rack: Average design IT power load per server rack in kW
        """
        self.rack_width = float(rack_width)
        self.rack_depth = float(rack_depth)
        self.cold_aisle = float(cold_aisle)
        self.hot_aisle = float(hot_aisle)
        self.kw_per_rack = float(kw_per_rack)

    def calculate_room_power_capacity(self, rack_grid, kw_per_rack=None):
        """
        Compute total IT electrical power and cooling load capacity for a generated rack layout.
        :param rack_grid: List of rack dict placements from generate_rack_grid
        :param kw_per_rack: Optional override for kW/rack rating
        :return: Dict summary with total_racks, total_kw, total_mw, cold_aisle_rows, hot_aisle_rows
        """
        kw = float(kw_per_rack) if kw_per_rack is not None else self.kw_per_rack
        total_racks = len(rack_grid)
        total_kw = total_racks * kw
        total_mw = total_kw / 1000.0

        rows = set(r["row"] for r in rack_grid) if rack_grid else set()

        return {
            "total_racks": total_racks,
            "total_kw_capacity": total_kw,
            "total_mw_capacity": round(total_mw, 3),
            "kw_per_rack": kw,
            "total_rows": len(rows)
        }

    def generate_rack_grid(self, room_bbox_min, room_bbox_max, margin=3.0, row_prefix="ROW"):
        """
        Calculate grid coordinates for server racks inside a room boundary box.
        :param room_bbox_min: Tuple/XYZ min point of room
        :param room_bbox_max: Tuple/XYZ max point of room
        :param margin: Distance from room boundary walls in feet
        :param row_prefix: Prefix for row numbering (e.g. "ROW")
        :return: List of dict rack placements [{"x": float, "y": float, "z": float, "row": int, "tag": str, "aisle_type": str}]
        """
        min_x = (room_bbox_min.X if hasattr(room_bbox_min, 'X') else room_bbox_min[0]) + margin
        min_y = (room_bbox_min.Y if hasattr(room_bbox_min, 'Y') else room_bbox_min[1]) + margin
        min_z = (room_bbox_min.Z if hasattr(room_bbox_min, 'Z') else room_bbox_min[2])

        max_x = (room_bbox_max.X if hasattr(room_bbox_max, 'X') else room_bbox_max[0]) - margin
        max_y = (room_bbox_max.Y if hasattr(room_bbox_max, 'Y') else room_bbox_max[1]) - margin

        available_x = max_x - min_x
        available_y = max_y - min_y

        if available_x < self.rack_width or available_y < self.rack_depth:
            return []

        # Calculate number of rack columns per row
        cols = int(math.floor(available_x / self.rack_width))

        racks = []
        curr_y = min_y
        row_idx = 1
        is_cold = True

        while curr_y + self.rack_depth <= max_y:
            aisle_type = "COLD" if is_cold else "HOT"
            for c in range(cols):
                rx = min_x + (c * self.rack_width) + (self.rack_width / 2.0)
                ry = curr_y + (self.rack_depth / 2.0)
                tag_id = "R-{}-{:02d}-{:02d}".format(row_prefix, row_idx, c + 1)
                racks.append({
                    "x": rx,
                    "y": ry,
                    "z": min_z,
                    "row": row_idx,
                    "col": c + 1,
                    "tag": tag_id,
                    "aisle_type": aisle_type
                })

            curr_y += self.rack_depth
            curr_y += self.cold_aisle if is_cold else self.hot_aisle
            is_cold = not is_cold
            row_idx += 1

        return racks

