# -*- coding: utf-8 -*-
"""
SamTools Spatial Geometry & Pathfinding Engine
Provides 3D Spatial Grid hashing, A* pathfinding for Cable Trays & Pipes,
and bounding box collision detection.
"""

import math
import heapq


class SpatialGrid(object):
    """3D Spatial Hash Grid for fast collision detection and pathfinding obstacles."""

    def __init__(self, cell_size=1.0):
        """
        :param cell_size: Grid cell dimension in feet (Revit API internal unit, e.g. 1.0 ft ≈ 304.8 mm)
        """
        self.cell_size = float(cell_size)
        self.occupied_cells = set()
        self.obstacles = []

    def _point_to_cell(self, point):
        """Convert a 3D coordinate (x, y, z) or tuple/XYZ into discrete grid cell indices (ix, iy, iz)."""
        if hasattr(point, 'X'):
            x, y, z = point.X, point.Y, point.Z
        else:
            x, y, z = point[0], point[1], point[2]
        return (
            int(math.floor(x / self.cell_size)),
            int(math.floor(y / self.cell_size)),
            int(math.floor(z / self.cell_size))
        )

    def _cell_to_point(self, cell):
        """Convert grid cell indices back to center 3D coordinates."""
        return (
            (cell[0] + 0.5) * self.cell_size,
            (cell[1] + 0.5) * self.cell_size,
            (cell[2] + 0.5) * self.cell_size
        )

    def add_obstacle_bbox(self, min_pt, max_pt, clearance=0.5):
        """
        Add a 3D bounding box obstacle into the spatial grid with clearance.
        :param min_pt: Bounding box minimum coordinate (XYZ or tuple)
        :param max_pt: Bounding box maximum coordinate (XYZ or tuple)
        :param clearance: Buffer distance around obstacle in feet
        """
        min_x = (min_pt.X if hasattr(min_pt, 'X') else min_pt[0]) - clearance
        min_y = (min_pt.Y if hasattr(min_pt, 'Y') else min_pt[1]) - clearance
        min_z = (min_pt.Z if hasattr(min_pt, 'Z') else min_pt[2]) - clearance

        max_x = (max_pt.X if hasattr(max_pt, 'X') else max_pt[0]) + clearance
        max_y = (max_pt.Y if hasattr(max_pt, 'Y') else max_pt[1]) + clearance
        max_z = (max_pt.Z if hasattr(max_pt, 'Z') else max_pt[2]) + clearance

        self.obstacles.append(((min_x, min_y, min_z), (max_x, max_y, max_z)))

        start_cell = self._point_to_cell((min_x, min_y, min_z))
        end_cell = self._point_to_cell((max_x, max_y, max_z))

        for ix in range(start_cell[0], end_cell[0] + 1):
            for iy in range(start_cell[1], end_cell[1] + 1):
                for iz in range(start_cell[2], end_cell[2] + 1):
                    self.occupied_cells.add((ix, iy, iz))

    def is_blocked(self, cell):
        """Check if a discrete grid cell is blocked by an obstacle."""
        return cell in self.occupied_cells

    def check_clash(self, point, clearance=0.0):
        """Check if a 3D point clashes with any registered obstacle."""
        px = point.X if hasattr(point, 'X') else point[0]
        py = point.Y if hasattr(point, 'Y') else point[1]
        pz = point.Z if hasattr(point, 'Z') else point[2]

        for (min_x, min_y, min_z), (max_x, max_y, max_z) in self.obstacles:
            if (min_x - clearance <= px <= max_x + clearance and
                min_y - clearance <= py <= max_y + clearance and
                min_z - clearance <= pz <= max_z + clearance):
                return True
        return False


class PathFinder(object):
    """3D A* PathFinder engine for MEP cable tray, duct, and pipe routing."""

    def __init__(self, step_size=1.0):
        """
        :param step_size: Discrete pathfinding grid step in feet (default: 1.0 ft)
        """
        self.step_size = float(step_size)

    @staticmethod
    def _heuristic(cell_a, cell_b):
        """3D Euclidean distance heuristic."""
        dx = cell_a[0] - cell_b[0]
        dy = cell_a[1] - cell_b[1]
        dz = cell_a[2] - cell_b[2]
        return math.sqrt(dx * dx + dy * dy + dz * dz)

    def find_path(self, start_xyz, end_xyz, spatial_grid=None, max_iterations=10000):
        """
        Find an obstacle-avoiding 3D path using A* search algorithm.
        :param start_xyz: Start coordinate (XYZ object or tuple)
        :param end_xyz: Target end coordinate (XYZ object or tuple)
        :param spatial_grid: SpatialGrid instance populated with obstacles
        :param max_iterations: Maximum search iterations before fallback
        :return: List of 3D point tuples representing the routed path
        """
        if spatial_grid is None:
            spatial_grid = SpatialGrid(cell_size=self.step_size)

        start_cell = spatial_grid._point_to_cell(start_xyz)
        end_cell = spatial_grid._point_to_cell(end_xyz)

        if start_cell == end_cell:
            return [start_xyz, end_xyz]

        # 6 orthogonal 3D directions (+ Z vertical steps for cable tray drops/rises)
        directions = [
            (1, 0, 0), (-1, 0, 0),
            (0, 1, 0), (0, -1, 0),
            (0, 0, 1), (0, 0, -1)
        ]

        open_set = []
        heapq.heappush(open_set, (0.0, start_cell))

        came_from = {}
        g_score = {start_cell: 0.0}
        f_score = {start_cell: self._heuristic(start_cell, end_cell)}

        iterations = 0
        found = False

        while open_set and iterations < max_iterations:
            iterations += 1
            _, current = heapq.heappop(open_set)

            if current == end_cell:
                found = True
                break

            for dx, dy, dz in directions:
                neighbor = (current[0] + dx, current[1] + dy, current[2] + dz)

                if spatial_grid.is_blocked(neighbor) and neighbor != end_cell:
                    continue

                tentative_g = g_score[current] + 1.0  # Unit step cost

                if neighbor not in g_score or tentative_g < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f = tentative_g + self._heuristic(neighbor, end_cell)
                    f_score[neighbor] = f
                    heapq.heappush(open_set, (f, neighbor))

        if not found:
            # Fallback to direct path if no obstacle-free path is found within max_iterations
            return [start_xyz, end_xyz]

        # Reconstruct path
        path_cells = [end_cell]
        curr = end_cell
        while curr in came_from:
            curr = came_from[curr]
            path_cells.append(curr)
        path_cells.reverse()

        # Convert cells to 3D point coordinates
        points = [start_xyz]
        for cell in path_cells[1:-1]:
            points.append(spatial_grid._cell_to_point(cell))
        points.append(end_xyz)

        # Simplify/Smooth path by removing unnecessary collinear points
        return self._smooth_path(points)

    @staticmethod
    def _smooth_path(points):
        """Remove redundant collinear points in straight segments."""
        if len(points) <= 2:
            return points

        smoothed = [points[0]]
        for i in range(1, len(points) - 1):
            prev = smoothed[-1]
            curr = points[i]
            nxt = points[i + 1]

            # Vector directions
            v1 = (curr[0] - prev[0], curr[1] - prev[1], curr[2] - prev[2])
            v2 = (nxt[0] - curr[0], nxt[1] - curr[1], nxt[2] - curr[2])

            # Check cross product for collinearity
            cx = v1[1] * v2[2] - v1[2] * v2[1]
            cy = v1[2] * v2[0] - v1[0] * v2[2]
            cz = v1[0] * v2[1] - v1[1] * v2[0]

            if abs(cx) > 1e-4 or abs(cy) > 1e-4 or abs(cz) > 1e-4:
                smoothed.append(curr)

        smoothed.append(points[-1])
        return smoothed

