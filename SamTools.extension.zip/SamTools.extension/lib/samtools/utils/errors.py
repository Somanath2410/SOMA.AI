class SamToolsError(Exception):
    pass

class DataCenterValidationError(SamToolsError):
    pass

class ClashDetectedError(SamToolsError):
    pass
