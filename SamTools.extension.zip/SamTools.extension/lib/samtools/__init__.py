# -*- coding: utf-8 -*-
# SamTools Python library initialization
