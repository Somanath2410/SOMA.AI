# -*- coding: utf-8 -*-
"""
SamTools Core MVC & Context Management Framework
Provides base architecture for Model-View-Controller patterns, safe Revit transactions,
and document context handling.
"""

import sys
import clr

try:
    from pyrevit import revit, DB, UI, forms, script
except ImportError:
    revit = None
    DB = None
    UI = None
    forms = None
    script = None


class TransactionManager(object):
    """Context manager for safe Revit API transactions."""
    
    def __init__(self, doc, name="SamTools Transaction"):
        self.doc = doc
        self.name = name
        self.transaction = None

    def __enter__(self):
        if self.doc and DB:
            self.transaction = DB.Transaction(self.doc, self.name)
            self.transaction.Start()
        return self.transaction

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.transaction and self.transaction.IsValidObject:
            if exc_type is not None:
                if self.transaction.GetStatus() == DB.TransactionStatus.Started:
                    self.transaction.RollBack()
                return False  # Propagate exception
            else:
                if self.transaction.GetStatus() == DB.TransactionStatus.Started:
                    self.transaction.Commit()
        return True


class DocumentContext(object):
    """Helper wrapper for current active document, selection, and unit utilities."""
    
    def __init__(self, doc=None):
        if doc:
            self.doc = doc
        elif revit and hasattr(revit, 'doc'):
            self.doc = revit.doc
        else:
            self.doc = None

    @property
    def is_valid(self):
        return self.doc is not None and hasattr(self.doc, 'IsValidObject') and self.doc.IsValidObject

    @property
    def title(self):
        return self.doc.Title if self.is_valid else "No Document"

    def transaction(self, name="SamTools Operation"):
        return TransactionManager(self.doc, name)

    def get_collector(self, category=None, of_class=None, view_id=None):
        """Build a filtered element collector for the document."""
        if not self.is_valid or not DB:
            return None
        
        if view_id:
            collector = DB.FilteredElementCollector(self.doc, view_id)
        else:
            collector = DB.FilteredElementCollector(self.doc)

        if category:
            collector.OfCategory(category)
        if of_class:
            collector.OfClass(of_class)

        return collector


class BaseModel(object):
    """Base class for all SamTools feature models."""
    
    def __init__(self, doc=None):
        self.context = DocumentContext(doc)
        self.doc = self.context.doc

    def transaction(self, name="SamTools Model Operation"):
        return self.context.transaction(name)


class BaseView(object):
    """Base class for WPF/XAML views in SamTools."""
    
    def __init__(self, xaml_filename=None):
        self.xaml_filename = xaml_filename
        self.window = None

    def show(self, modal=True):
        """Show the WPF Window."""
        if forms and self.xaml_filename:
            try:
                self.window = forms.WPFWindow(self.xaml_filename)
                if modal:
                    return self.window.show_dialog()
                else:
                    self.window.show()
                    return True
            except Exception as e:
                if script:
                    logger = script.get_logger()
                    logger.error("Failed to show view {}: {}".format(self.xaml_filename, str(e)))
                raise e
        return False


class BaseController(object):
    """Base controller connecting Model and View."""
    
    def __init__(self, model, view):
        self.model = model
        self.view = view

    def execute(self):
        """Execute controller logic."""
        if self.view:
            return self.view.show()
        return False

