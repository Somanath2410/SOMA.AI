# -*- coding: utf-8 -*-
"""
SamTools Verification Test Suite
Provides automated unit tests for SpatialGrid, A* PathFinder, Rack Engine, ToolRegistry, and MCP Protocol Handler.
"""

from samtools.tests.test_core import run_all_tests
