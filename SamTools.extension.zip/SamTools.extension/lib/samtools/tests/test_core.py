# -*- coding: utf-8 -*-
"""
SamTools Automated Unit & Integration Tests
Runs test cases to verify 3D A* PathFinder, SpatialGrid, ToolRegistry, MCP Handler, QA/QC Audit Engine, and Exporters.
"""

import sys
import os
import json
import tempfile
from samtools.utils.geometry import SpatialGrid, PathFinder
from samtools.datacenter.rack_engine import RackLayoutEngine
from samtools.mcp.protocol import MCPProtocolHandler
from samtools.mcp.registry import MCPToolRegistry
from samtools.qaqc.audit_engine import QAQCAuditEngine
from samtools.export.pdf_exporter import PDFExportService
from samtools.export.dwg_exporter import DWGExportService
from SamTools.tab.AIAssistant.panel.SomaChat.pushbutton.ai_commands import ToolRegistry


def test_spatial_grid():
    grid = SpatialGrid(cell_size=1.0)
    grid.add_obstacle_bbox((0, 0, 0), (5, 5, 5), clearance=0.5)
    
    assert grid.check_clash((2, 2, 2)) is True, "Point inside obstacle should clash"
    assert grid.check_clash((10, 10, 10)) is False, "Point outside obstacle should not clash"
    return "test_spatial_grid PASSED"


def test_astar_pathfinder():
    grid = SpatialGrid(cell_size=1.0)
    # Add obstacle blocking straight line along X-axis
    grid.add_obstacle_bbox((4, -2, -2), (6, 2, 2), clearance=0.0)
    
    pf = PathFinder(step_size=1.0)
    start = (0, 0, 0)
    end = (10, 0, 0)
    
    path = pf.find_path(start, end, spatial_grid=grid)
    assert len(path) >= 2, "Path should contain at least start and end points"
    assert path[0] == start, "Path start must match"
    assert path[-1] == end, "Path end must match"
    return "test_astar_pathfinder PASSED"


def test_rack_layout_engine():
    engine = RackLayoutEngine(rack_width=2.0, rack_depth=3.5, cold_aisle=4.0, hot_aisle=3.0)
    grid = engine.generate_rack_grid((0, 0, 0), (30, 40, 0), margin=3.0)
    assert len(grid) > 0, "Rack engine should generate valid rack coordinates"
    return "test_rack_layout_engine PASSED"


def test_tool_registry():
    tools = ToolRegistry.list_tools()
    assert len(tools) > 0, "ToolRegistry should contain registered tools"
    tool_names = [t["name"] for t in tools]
    assert "create_door_schedule" in tool_names, "create_door_schedule should be registered"
    return "test_tool_registry PASSED"


def test_mcp_protocol():
    handler = MCPProtocolHandler(doc=None)
    
    # Test ping
    res_ping = json.loads(handler.handle_request(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "ping"})))
    assert "result" in res_ping, "MCP ping should return result"
    
    # Test tools/list
    res_list = json.loads(handler.handle_request(json.dumps({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})))
    assert "tools" in res_list["result"], "MCP tools/list should return tool definitions"
    
    return "test_mcp_protocol PASSED"


def test_qaqc_audit_engine():
    engine = QAQCAuditEngine(doc=None)
    res = engine.run_full_audit()
    assert "status" in res, "Audit result must have status"
    assert len(res["checks"]) >= 5, "Audit engine should execute checks"
    
    tmp_dir = tempfile.mkdtemp()
    json_path = os.path.join(tmp_dir, "audit_report.json")
    html_path = os.path.join(tmp_dir, "audit_report.html")
    
    engine.export_audit_report_json(json_path, res)
    engine.export_audit_report_html(html_path, res)
    
    assert os.path.exists(json_path), "JSON audit report must be written"
    assert os.path.exists(html_path), "HTML audit report dashboard must be written"
    return "test_qaqc_audit_engine PASSED"


def test_pdf_exporter():
    service = PDFExportService(doc=None)
    fn = service.format_sheet_filename("A-101", "Ground Floor Plan", "{SheetNumber}_{SheetName}")
    assert fn == "A-101_Ground Floor Plan.pdf", "PDF filename formatting failed"
    
    tmp_dir = tempfile.mkdtemp()
    summary = service.export_sheets_to_pdf([101, 102], tmp_dir, combine=True)
    assert summary["status"] == "SIMULATED", "PDF Export offline simulation status check"
    return "test_pdf_exporter PASSED"


def test_dwg_exporter():
    service = DWGExportService(doc=None)
    setups = service.get_available_export_setups()
    assert len(setups) > 0, "DWG export setups must be listed"
    
    tmp_dir = tempfile.mkdtemp()
    summary = service.export_views_to_dwg([201, 202], tmp_dir)
    assert summary["status"] == "SIMULATED", "DWG Export offline simulation status check"
    return "test_dwg_exporter PASSED"


def test_ifc_exporter():
    from samtools.export.ifc_exporter import IFCExportService
    service = IFCExportService(doc=None)
    tmp_dir = tempfile.mkdtemp()
    summary = service.export_model_to_ifc(tmp_dir, file_name="Test_Model.ifc", ifc_version="IFC4")
    assert summary["status"] == "SIMULATED", "IFC Export offline simulation status check"
    return "test_ifc_exporter PASSED"


def test_datacenter_suite():
    from samtools.datacenter.rack_engine import RackLayoutEngine
    from samtools.datacenter.cable_tray_router import CableTrayRouter
    
    rack_eng = RackLayoutEngine(rack_width=2.0, kw_per_rack=12.5)
    grid = rack_eng.generate_rack_grid((0, 0, 0), (40, 50, 0))
    cap = rack_eng.calculate_room_power_capacity(grid)
    assert cap["total_racks"] > 0, "Rack grid must contain calculated racks"
    assert cap["total_kw_capacity"] > 0, "Power capacity must be greater than zero"
    
    router = CableTrayRouter(doc=None)
    sizing = router.calculate_tray_sizing(cable_count=100, avg_cable_dia_in=0.3)
    assert sizing["recommended_width_in"] >= 6.0, "Tray width sizing calculation failed"
    return "test_datacenter_suite PASSED"


def test_extended_mcp():
    handler = MCPProtocolHandler(doc=None)
    res_prompts = json.loads(handler.handle_request(json.dumps({"jsonrpc": "2.0", "id": 10, "method": "prompts/list"})))
    assert "prompts" in res_prompts["result"], "MCP prompts/list must return prompts array"
    
    res_res = json.loads(handler.handle_request(json.dumps({"jsonrpc": "2.0", "id": 11, "method": "resources/list"})))
    assert "resources" in res_res["result"], "MCP resources/list must return resources array"
    return "test_extended_mcp PASSED"


def test_llm_client_config():
    sys.path.append(os.path.join(os.path.dirname(__file__), "../../../SamTools.tab/AIAssistant.panel/SomaChat.pushbutton"))
    import llm_client
    providers = llm_client.get_supported_providers()
    models = llm_client.get_supported_models()
    assert "OpenAI" in providers, "OpenAI must be supported provider"
    assert "Ollama / Local LLM" in providers, "Local LLM must be supported provider"
    assert "gpt-4o" in models["OpenAI"], "gpt-4o must be in OpenAI models"
    return "test_llm_client_config PASSED"


def run_all_tests():
    results = [
        test_spatial_grid(),
        test_astar_pathfinder(),
        test_rack_layout_engine(),
        test_tool_registry(),
        test_mcp_protocol(),
        test_qaqc_audit_engine(),
        test_pdf_exporter(),
        test_dwg_exporter(),
        test_ifc_exporter(),
        test_datacenter_suite(),
        test_extended_mcp(),
        test_llm_client_config()
    ]
    return results


if __name__ == "__main__":
    test_results = run_all_tests()
    for r in test_results:
        print("[PASS] " + r)



