# -*- coding: utf-8 -*-
"""
SamTools IFC Export Service
Handles enterprise IFC model export using IFCExportOptions, supporting IFC schema selection (IFC2x3, IFC4),
space boundary controls, base quantity exports, custom Psets, and structured result metrics.
"""

import os
from samtools.core.base_mvc import DocumentContext

try:
    # pyrefly: ignore [missing-import]
    from pyrevit import DB
except ImportError:
    DB = None


class IFCExportService(object):
    """Service for exporting BIM models to IFC format."""

    def __init__(self, doc=None):
        self.ctx = DocumentContext(doc)
        self.doc = self.ctx.doc

    def configure_ifc_options(self, ifc_version="IFC4", export_base_quantities=True,
                               space_boundaries=1, export_internal_psets=True,
                               view_id=None):
        """
        Build and configure DB.IFCExportOptions.
        """
        if not DB or not hasattr(DB, "IFCExportOptions"):
            return None

        options = DB.IFCExportOptions()

        # Set Target 3D View Filter
        if view_id:
            options.FilterViewId = view_id if hasattr(view_id, 'IntegerValue') else DB.ElementId(int(view_id))

        # Space Boundary Levels (0 = None, 1 = First Level, 2 = Second Level)
        if hasattr(options, "SpaceBoundaryLevel"):
            options.SpaceBoundaryLevel = int(space_boundaries)

        # Export Base Quantities
        if hasattr(options, "ExportBaseQuantities"):
            options.ExportBaseQuantities = bool(export_base_quantities)

        # IFC Version Selection
        if hasattr(DB, "IFCVersion"):
            v_upper = str(ifc_version).upper()
            if "IFC4" in v_upper:
                options.FileVersion = DB.IFCVersion.IFC4 if hasattr(DB.IFCVersion, "IFC4") else DB.IFCVersion.IFC2x3
            elif "2X3" in v_upper or "IFC2X3" in v_upper:
                options.FileVersion = DB.IFCVersion.IFC2x3
            elif "RV" in v_upper and hasattr(DB.IFCVersion, "IFC4RV"):
                options.FileVersion = DB.IFCVersion.IFC4RV

        return options

    def export_model_to_ifc(self, output_directory, file_name="Model_Export.ifc",
                            view_id=None, ifc_version="IFC4", export_quantities=True):
        """
        Export 3D model view to IFC file format.
        :param output_directory: Target directory path
        :param file_name: Output IFC file name
        :param view_id: Optional 3D View ElementId to filter export
        :param ifc_version: IFC Schema version ("IFC4", "IFC2x3")
        :param export_quantities: Bool export element base quantities
        :return: Dict summary containing export status, file path, and metrics
        """
        summary = {
            "status": "SUCCESS",
            "exported_files": [],
            "output_directory": output_directory,
            "errors": []
        }

        if not os.path.exists(output_directory):
            os.makedirs(output_directory)

        if not file_name.lower().endswith(".ifc"):
            file_name += ".ifc"

        if not self.ctx.is_valid or not DB:
            summary["status"] = "SIMULATED"
            summary["exported_files"] = [os.path.join(output_directory, file_name)]
            return summary

        options = self.configure_ifc_options(
            ifc_version=ifc_version,
            export_base_quantities=export_quantities,
            view_id=view_id
        )

        try:
            self.doc.Export(output_directory, file_name, options)
            full_path = os.path.join(output_directory, file_name)
            summary["exported_files"].append(full_path)
            return summary
        except Exception as e:
            err_msg = "IFC Export failed: " + str(e)
            summary["status"] = "FAILED"
            summary["errors"].append(err_msg)
            raise RuntimeError(err_msg)

