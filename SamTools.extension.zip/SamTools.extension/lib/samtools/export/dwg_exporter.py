# -*- coding: utf-8 -*-
"""
SamTools DWG Export Service
Handles batch DWG export for Revit views and sheets using DWGExportOptions,
supporting setup preset selection, AutoCAD version configuration, XRef merging, and batch execution reporting.
"""

import os
from samtools.core.base_mvc import DocumentContext

try:
    # pyrefly: ignore [missing-import]
    from pyrevit import DB
except ImportError:
    DB = None


class DWGExportService(object):
    """Service for batch exporting views and sheets to DWG format."""

    def __init__(self, doc=None):
        self.ctx = DocumentContext(doc)
        self.doc = self.ctx.doc

    def get_available_export_setups(self):
        """
        List all DWG Export Settings predefined in active document.
        :return: List of setup names
        """
        if not self.ctx.is_valid or not DB:
            return ["Standard DWG Setup", "AIA Standard Setup", "ISO 13567 Setup"]

        setups = DB.FilteredElementCollector(self.doc).OfClass(DB.ExportDWGSettings).ToElements()
        return [s.Name for s in setups]

    def configure_dwg_options(self, setup_name=None, acad_version="2018", merge_xrefs=True):
        """
        Build and configure DB.DWGExportOptions.
        """
        options = DB.DWGExportOptions() if DB else None
        if not options:
            return None

        # Load DWG Export Setup if specified
        if setup_name and self.doc:
            setups = DB.FilteredElementCollector(self.doc).OfClass(DB.ExportDWGSettings).ToElements()
            for s in setups:
                if s.Name == setup_name:
                    options = s.GetDWGExportOptions()
                    break

        # Configure merged external references (XRefs)
        if hasattr(options, "MergedViews"):
            options.MergedViews = merge_xrefs

        # Configure Target ACAD Version if supported
        if hasattr(DB, "ACADVersion"):
            if acad_version == "2013":
                options.TargetUnit = DB.ACADVersion.R2013 if hasattr(DB.ACADVersion, "R2013") else options.TargetUnit
            elif acad_version == "2018" and hasattr(DB.ACADVersion, "R2018"):
                options.TargetUnit = DB.ACADVersion.R2018

        return options

    def export_views_to_dwg(self, view_ids, output_directory, setup_name=None, prefix="DWG_Export"):
        """
        Export specified views to DWG files.
        :param view_ids: List of View or ViewSheet ElementIds
        :param output_directory: String target directory path
        :param setup_name: Optional DWG export setup name
        :param prefix: Output filename prefix
        :return: Dict summary with export status, paths, count, and errors
        """
        summary = {
            "status": "SUCCESS",
            "exported_files": [],
            "total_count": len(view_ids),
            "output_directory": output_directory,
            "errors": []
        }

        if not os.path.exists(output_directory):
            os.makedirs(output_directory)

        if not self.ctx.is_valid or not DB:
            summary["status"] = "SIMULATED"
            summary["exported_files"] = [os.path.join(output_directory, "{}_Simulated.dwg".format(prefix))]
            return summary

        options = self.configure_dwg_options(setup_name=setup_name)

        # pyrefly: ignore [missing-import]
        import System
        # pyrefly: ignore [missing-import]
        from System.Collections.Generic import List

        element_id_collection = List[DB.ElementId]()
        for v_id in view_ids:
            element_id_collection.Add(v_id if hasattr(v_id, 'IntegerValue') else DB.ElementId(int(v_id)))

        try:
            self.doc.Export(output_directory, prefix, element_id_collection, options)
            summary["exported_files"].append(output_directory)
            return summary
        except Exception as e:
            err_msg = "DWG Export failed: " + str(e)
            summary["status"] = "FAILED"
            summary["errors"].append(err_msg)
            raise RuntimeError(err_msg)

