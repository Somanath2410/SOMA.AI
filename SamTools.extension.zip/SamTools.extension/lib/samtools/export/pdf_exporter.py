# -*- coding: utf-8 -*-
"""
SamTools PDF Export Service
Handles batch PDF export for Revit sheets and views using native PDFExportOptions or print fallbacks,
supporting ISO 19650 naming conventions, vector/raster quality configurations, and detailed batch reporting.
"""

import os
from samtools.core.base_mvc import DocumentContext

try:
    # pyrefly: ignore [missing-import, parse-error]

 # pyrefly: ignore [parse-error]
 ImportError:
    # pyrefly: ignore [parse-error]
    DB = None


# pyrefly: ignore [parse-error]
class PDFExportService(object):
    """Service for batch exporting sheets and views to PDF format."""

    def __init__(self, doc=None):
        self.ctx = DocumentContext(doc)
        self.doc = self.ctx.doc

    def configure_pdf_options(self, combine=False, file_name="Combined_Export.pdf",
                              raster_quality="High", color_mode="Color",
                              hide_unreferenced_tags=True, hide_scope_boxes=True,
                              hide_crop_boundaries=True):
        """
        Build and configure native DB.PDFExportOptions object.
        """
        if not DB or not hasattr(DB, "PDFExportOptions"):
            return None

        options = DB.PDFExportOptions()
        options.Combine = combine
        if combine:
            options.FileName = file_name

        # Apply settings if properties exist in current API version
        if hasattr(options, "HideUnreferencedViewTags"):
            options.HideUnreferencedViewTags = hide_unreferenced_tags
        if hasattr(options, "HideScopeBoxes"):
            options.HideScopeBoxes = hide_scope_boxes
        if hasattr(options, "HideCropBoundaries"):
            options.HideCropBoundaries = hide_crop_boundaries

        # Color mode configuration
        if hasattr(DB, "PDFColorMode"):
            if color_mode.lower() == "grayscale":
                options.ColorMode = DB.PDFColorMode.Grayscale
            elif color_mode.lower() in ["blackandwhite", "monochrome"]:
                options.ColorMode = DB.PDFColorMode.BlackAndWhite
            else:
                options.ColorMode = DB.PDFColorMode.Color

        # Raster Quality configuration
        if hasattr(DB, "RasterQualityType"):
            if raster_quality.lower() == "presentation":
                options.RasterQuality = DB.RasterQualityType.Presentation
            elif raster_quality.lower() == "medium":
                options.RasterQuality = DB.RasterQualityType.Medium
            elif raster_quality.lower() == "low":
                options.RasterQuality = DB.RasterQualityType.Low
            else:
                options.RasterQuality = DB.RasterQualityType.High

        return options

    def format_sheet_filename(self, sheet_num, sheet_name, pattern="{SheetNumber}_{SheetName}"):
        """Format individual sheet PDF filename using string template pattern."""
        safe_num = "".join(c for c in sheet_num if c.isalnum() or c in ['-', '_']).strip()
        safe_name = "".join(c for c in sheet_name if c.isalnum() or c in ['-', '_', ' ']).strip()
        result = pattern.format(SheetNumber=safe_num, SheetName=safe_name)
        if not result.lower().endswith(".pdf"):
            result += ".pdf"
        return result

    def export_sheets_to_pdf(self, sheet_ids, output_directory, combine=False,
                            file_name="Combined_Export.pdf", naming_pattern="{SheetNumber}_{SheetName}"):
        """
        Export specified sheets to PDF files.
        :param sheet_ids: List of ViewSheet ElementIds
        :param output_directory: String target directory path
        :param combine: Bool combine into single PDF file
        :param file_name: Output file name if combining
        :param naming_pattern: String pattern template for uncombined sheet filenames
        :return: Dict export summary containing exported_files, count, status, and errors
        """
        summary = {
            "status": "SUCCESS",
            "exported_files": [],
            "total_count": len(sheet_ids),
            "output_directory": output_directory,
            "errors": []
        }

        if not os.path.exists(output_directory):
            os.makedirs(output_directory)

        if not self.ctx.is_valid or not DB:
            summary["status"] = "SIMULATED"
            summary["exported_files"] = [os.path.join(output_directory, "Simulated_Export.pdf")]
            return summary

        # Use Revit 2022+ native PDFExportOptions if available
        if hasattr(DB, "PDFExportOptions"):
            options = self.configure_pdf_options(combine=combine, file_name=file_name)

            element_id_collection = []
            for s_id in sheet_ids:
                element_id_collection.append(s_id if hasattr(s_id, 'IntegerValue') else DB.ElementId(int(s_id)))

            try:
                # pyrefly: ignore [missing-import]
                import System
                # pyrefly: ignore [missing-import]
                from System.Collections.Generic import List
                id_list = List[DB.ElementId](element_id_collection)

                self.doc.Export(output_directory, id_list, options)

                if combine:
                    summary["exported_files"].append(os.path.join(output_directory, file_name))
                else:
                    summary["exported_files"].append(output_directory)
                return summary
            except Exception as e:
                err_msg = "PDF Export failed: " + str(e)
                summary["status"] = "FAILED"
                summary["errors"].append(err_msg)
                raise RuntimeError(err_msg)
        else:
            err_msg = "Native PDFExportOptions not available in this Revit version."
            summary["status"] = "FAILED"
            summary["errors"].append(err_msg)
            raise NotImplementedError(err_msg)

