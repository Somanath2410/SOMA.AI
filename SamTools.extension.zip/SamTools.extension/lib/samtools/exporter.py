# -*- coding: utf-8 -*-
"""Premium ProExporter Engine for SamTools"""

from pyrevit import revit, DB, forms, script
import os
import json
import re
import sys
import clr

# Load PresentationFramework assemblies for WPF support
clr.AddReference("PresentationFramework")
clr.AddReference("PresentationCore")
clr.AddReference("WindowsBase")
clr.AddReference("System.Drawing")

import System
from System.Windows import Window, Visibility
from System.Windows.Threading import Dispatcher, DispatcherPriority
from System.Drawing.Printing import PrinterSettings
from System.Collections.Generic import List
from System.Collections.ObjectModel import ObservableCollection

doc = revit.doc

# Paths to XAML
current_dir = os.path.dirname(__file__)
exporter_xaml = os.path.join(current_dir, "ui", "exporter.xaml")
naming_xaml = os.path.join(current_dir, "ui", "naming_editor.xaml")
order_xaml = os.path.join(current_dir, "ui", "order_editor.xaml")

# Settings Configuration File
appdata = os.getenv("LOCALAPPDATA")
settings_dir = os.path.join(appdata, "SamTools")
if not os.path.exists(settings_dir):
    os.makedirs(settings_dir)
settings_path = os.path.join(settings_dir, "exporter_settings.json")


def sanitize_filename(name):
    """Sanitize sheet/view names for file export"""
    name = re.sub(r'[\\/*?:"<>|]', "", name).strip()
    return name or "Unnamed_File"


def get_parameter_value(element, param_name):
    """Safely lookup sheet, view, or project parameters"""
    if param_name == "Sheet Number" and hasattr(element, "SheetNumber"):
        return element.SheetNumber
    elif param_name == "Sheet Name" and hasattr(element, "Name"):
        return element.Name
    elif param_name == "Current Revision" and hasattr(element, "GetCurrentRevision"):
        try:
            return element.GetCurrentRevision() or ""
        except:
            pass
            
    # Standard lookup on Sheet/View
    param = element.LookupParameter(param_name)
    if param:
        if param.StorageType == DB.StorageType.String:
            return param.AsString() or ""
        elif param.StorageType == DB.StorageType.Integer:
            return str(param.AsInteger())
        elif param.StorageType == DB.StorageType.Double:
            return param.AsValueString() or ""
        elif param.StorageType == DB.StorageType.ElementId:
            return param.AsValueString() or ""
            
    # Fallback lookup on Project Info
    proj_info = doc.ProjectInformation
    if proj_info:
        param = proj_info.LookupParameter(param_name)
        if param:
            if param.StorageType == DB.StorageType.String:
                return param.AsString() or ""
            elif param.StorageType == DB.StorageType.Integer:
                return str(param.AsInteger())
            elif param.StorageType == DB.StorageType.Double:
                return param.AsValueString() or ""
            elif param.StorageType == DB.StorageType.ElementId:
                return param.AsValueString() or ""
    return ""


def get_available_parameters(mode):
    """Get all parameter definitions from Sheets, Views, and Project Info"""
    params = set(["Sheet Number", "Sheet Name", "Current Revision"])
    
    if mode in ["All", "Sheets"]:
        sheets = DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet).ToElements()
        for s in sheets[:25]:
            for p in s.Parameters:
                if p.Definition:
                    params.add(p.Definition.Name)
                    
    if mode in ["All", "Views"]:
        views = DB.FilteredElementCollector(doc).OfClass(DB.View).ToElements()
        for v in views[:25]:
            if not v.IsTemplate:
                for p in v.Parameters:
                    if p.Definition:
                        params.add(p.Definition.Name)
                        
    if mode in ["All", "Project Information"]:
        proj_info = doc.ProjectInformation
        if proj_info:
            for p in proj_info.Parameters:
                if p.Definition:
                    params.add(p.Definition.Name)
                    
    return sorted(list(params))


class SheetViewItem(object):
    """Wraps Revit sheets or views for grid binding"""
    def __init__(self, element, is_sheet=True, titleblock=None):
        self._element = element
        self._is_sheet = is_sheet
        self._selected = False
        self._number = element.SheetNumber if is_sheet else str(element.Id.IntegerValue)
        self._name = element.Name
        
        self._revision = ""
        if is_sheet:
            try:
                self._revision = element.GetCurrentRevision() or ""
            except:
                p = element.LookupParameter("Current Revision")
                if p: self._revision = p.AsString() or ""
                
        self._size = self._get_size(titleblock)
        self._custom_file_name = ""

    @property
    def element(self): return self._element
    @property
    def is_sheet(self): return self._is_sheet
    
    @property
    def Selected(self): return self._selected
    @Selected.setter
    def Selected(self, val): self._selected = val
    
    @property
    def Number(self): return self._number
    @property
    def Name(self): return self._name
    @property
    def Revision(self): return self._revision
    @property
    def Size(self): return self._size
    
    @property
    def CustomFileName(self): return self._custom_file_name
    @CustomFileName.setter
    def CustomFileName(self, val): self._custom_file_name = val

    def _get_size(self, tb):
        if not self._is_sheet:
            return "View"
        if not tb:
            return "Unknown"
        try:
            w_param = tb.get_Parameter(DB.BuiltInParameter.SHEET_WIDTH)
            h_param = tb.get_Parameter(DB.BuiltInParameter.SHEET_HEIGHT)
            if w_param and h_param:
                w = w_param.AsDouble() * 304.8
                h = h_param.AsDouble() * 304.8
                w, h = sorted([w, h], reverse=True)
                if abs(w - 1189) < 15 and abs(h - 841) < 15: return "A0"
                if abs(w - 841) < 15 and abs(h - 594) < 15: return "A1"
                if abs(w - 594) < 15 and abs(h - 420) < 15: return "A2"
                if abs(w - 420) < 15 and abs(h - 297) < 15: return "A3"
                if abs(w - 297) < 15 and abs(h - 210) < 15: return "A4"
                return "{:.0f}x{:.0f}mm".format(w, h)
        except:
            pass
        return "Unknown"


class NamingField(object):
    """Field definition for the custom naming engine"""
    def __init__(self, name, prefix="", sample_value="", suffix="", separator="-"):
        self._name = name
        self._prefix = prefix
        self._sample_value = sample_value or name
        self._suffix = suffix
        self._separator = separator

    @property
    def Name(self): return self._name
    
    @property
    def Prefix(self): return self._prefix
    @Prefix.setter
    def Prefix(self, val): self._prefix = val
    
    @property
    def SampleValue(self): return self._sample_value
    @SampleValue.setter
    def SampleValue(self, val): self._sample_value = val
    
    @property
    def Suffix(self): return self._suffix
    @Suffix.setter
    def Suffix(self, val): self._suffix = val
    
    @property
    def Separator(self): return self._separator
    @Separator.setter
    def Separator(self, val): self._separator = val


class NamingEditorWindow(forms.WPFWindow):
    """Custom File Name editor popup matching ProSheets"""
    def __init__(self, xaml_file, selected_fields):
        forms.WPFWindow.__init__(self, xaml_file)
        self.selected_fields = selected_fields
        self.available_params = get_available_parameters("All")
        
        self.listAvailableParams.ItemsSource = self.available_params
        self.gridSelectedParams.ItemsSource = self.selected_fields
        
        # Events
        self.comboParamCategory.SelectionChanged += self.on_category_changed
        self.txtParamSearch.KeyUp += self.on_search_changed
        self.btnAddParam.Click += self.add_parameter
        self.btnRemoveParam.Click += self.remove_parameter
        
        self.btnMoveTop.Click += lambda s, a: self.reorder_field("top")
        self.btnMoveUp.Click += lambda s, a: self.reorder_field("up")
        self.btnMoveDown.Click += lambda s, a: self.reorder_field("down")
        self.btnMoveBottom.Click += lambda s, a: self.reorder_field("bottom")
        self.btnResetParams.Click += self.reset_params
        
        self.btnCancel.Click += self.cancel
        self.btnOk.Click += self.confirm
        
        self.success = False
        self.update_preview()

    def on_category_changed(self, sender, args):
        self.filter_available()

    def on_search_changed(self, sender, args):
        self.filter_available()

    def filter_available(self):
        category = self.comboParamCategory.SelectedItem.Content
        search_txt = self.txtParamSearch.Text.lower().strip()
        
        # Reload parameters for the specific category
        params = get_available_parameters(category)
        if search_txt:
            params = [p for p in params if search_txt in p.lower()]
        self.listAvailableParams.ItemsSource = params

    def add_parameter(self, sender, args):
        for item in self.listAvailableParams.SelectedItems:
            # Check if already added
            if not any(f.Name == item for f in self.selected_fields):
                # Sample value lookup
                sample = "Sample_" + item.replace(" ", "")
                self.selected_fields.Add(NamingField(item, sample_value=sample))
        self.gridSelectedParams.Items.Refresh()
        self.update_preview()

    def remove_parameter(self, sender, args):
        selected_grid_items = list(self.gridSelectedParams.SelectedItems)
        for item in selected_grid_items:
            self.selected_fields.Remove(item)
        self.gridSelectedParams.Items.Refresh()
        self.update_preview()

    def reorder_field(self, direction):
        selected_items = list(self.gridSelectedParams.SelectedItems)
        if not selected_items: return
        
        item = selected_items[0]
        idx = self.selected_fields.IndexOf(item)
        
        if direction == "top" and idx > 0:
            self.selected_fields.Remove(item)
            self.selected_fields.Insert(0, item)
        elif direction == "up" and idx > 0:
            self.selected_fields.Remove(item)
            self.selected_fields.Insert(idx - 1, item)
        elif direction == "down" and idx < len(self.selected_fields) - 1:
            self.selected_fields.Remove(item)
            self.selected_fields.Insert(idx + 1, item)
        elif direction == "bottom" and idx < len(self.selected_fields) - 1:
            self.selected_fields.Remove(item)
            self.selected_fields.Add(item)
            
        self.gridSelectedParams.SelectedItem = item
        self.gridSelectedParams.Items.Refresh()
        self.update_preview()

    def reset_params(self, sender, args):
        self.selected_fields.Clear()
        self.selected_fields.Add(NamingField("Sheet Number", separator="-"))
        self.selected_fields.Add(NamingField("Sheet Name", separator=""))
        self.gridSelectedParams.Items.Refresh()
        self.update_preview()

    def update_preview(self):
        parts = []
        for field in self.selected_fields:
            val = field.SampleValue or field.Name
            parts.append("{}{}{}{}".format(field.Prefix, val, field.Suffix, field.Separator))
        self.lblCustomNamePreview.Text = "".join(parts)

    def cancel(self, sender, args):
        self.Close()

    def confirm(self, sender, args):
        self.success = True
        self.Close()


class OrderEditorWindow(forms.WPFWindow):
    """Queue ordering dialog"""
    def __init__(self, xaml_file, items):
        forms.WPFWindow.__init__(self, xaml_file)
        self.items = ObservableCollection[SheetViewItem](items)
        self.listExportOrder.ItemsSource = self.items
        
        self.btnOrderTop.Click += lambda s, a: self.reorder("top")
        self.btnOrderUp.Click += lambda s, a: self.reorder("up")
        self.btnOrderDown.Click += lambda s, a: self.reorder("down")
        self.btnOrderBottom.Click += lambda s, a: self.reorder("bottom")
        
        self.btnCancel.Click += lambda s, a: self.Close()
        self.btnOk.Click += self.apply
        self.success = False

    def reorder(self, direction):
        sel = list(self.listExportOrder.SelectedItems)
        if not sel: return
        item = sel[0]
        idx = self.items.IndexOf(item)
        
        if direction == "top" and idx > 0:
            self.items.Remove(item)
            self.items.Insert(0, item)
        elif direction == "up" and idx > 0:
            self.items.Remove(item)
            self.items.Insert(idx - 1, item)
        elif direction == "down" and idx < len(self.items) - 1:
            self.items.Remove(item)
            self.items.Insert(idx + 1, item)
        elif direction == "bottom" and idx < len(self.items) - 1:
            self.items.Remove(item)
            self.items.Add(item)
            
        self.listExportOrder.SelectedItem = item
        self.listExportOrder.Items.Refresh()

    def apply(self, sender, args):
        self.success = True
        self.Close()


class ExportQueueItem(object):
    """Task item model for Create Tab DataGrid"""
    def __init__(self, element, is_sheet, format_type, target_name):
        self._element = element
        self._is_sheet = is_sheet
        self._type = "Sheet" if is_sheet else "View"
        self._name = element.Name
        self._format = format_type
        self._target_name = target_name
        self._status = "Pending"

    @property
    def element(self): return self._element
    @property
    def is_sheet(self): return self._is_sheet
    
    @property
    def Type(self): return self._type
    @property
    def Name(self): return self._name
    @property
    def Format(self): return self._format
    
    @property
    def TargetName(self): return self._target_name
    @TargetName.setter
    def TargetName(self, val): self._target_name = val
    
    @property
    def Status(self): return self._status
    @Status.setter
    def Status(self, val): self._status = val


class ExportWindow(forms.WPFWindow):
    """Main dashboard Window matching ProSheets UI"""
    def __init__(self, xaml_file, default_format="PDF"):
        forms.WPFWindow.__init__(self, xaml_file)
        
        # Configure Default checkbox
        self.chkPDF.IsChecked = (default_format == "PDF")
        self.chkDWG.IsChecked = (default_format == "DWG")
        
        # Load Printers list asynchronously to avoid blocking UI thread
        self.comboPrinter.ItemsSource = ["Loading printers..."]
        self.comboPrinter.SelectedIndex = 0
        self.load_printers_async()
        self.btnPrinterProperties.Click += self.on_printer_properties_clicked
            
        # Load DWG export setups
        dwg_setups = DB.FilteredElementCollector(doc).OfClass(DB.ExportDWGSettings).ToElements()
        self.dwg_setup_dict = {s.Name: s for s in dwg_setups}
        self.comboDwgSetup.ItemsSource = ["<Standard Options>"] + sorted(self.dwg_setup_dict.keys())
        self.comboDwgSetup.SelectedIndex = 0
        
        # Load Views & Sheets from Document
        self.load_sheets_views()
        self.load_sheet_sets()
        
        # Default Naming Rules
        self.naming_fields = ObservableCollection[NamingField]()
        self.naming_fields.Add(NamingField("Sheet Number", separator="-"))
        self.naming_fields.Add(NamingField("Sheet Name", separator=""))
        
        # Load saved settings if any
        self.load_saved_settings()
        
        # Initialize Print Area Window properties
        self.window_defined = False
        self.window_pt1 = None
        self.window_pt2 = None
        
        # Print Area Window Events
        self.rbAreaSheet.Checked += self.on_area_mode_changed
        self.rbAreaWindow.Checked += self.on_area_mode_changed
        self.btnDefineWindow.Click += self.on_define_window_clicked
        
        # Paper Override Events
        self.rbPaperAuto.Checked += self.on_paper_mode_changed
        self.rbPaperOverride.Checked += self.on_paper_mode_changed
        
        # Hook filter events
        self.rbSelectSheets.Checked += self.on_filter_changed
        self.rbSelectViews.Checked += self.on_filter_changed
        self.comboFilterSets.SelectionChanged += self.on_filter_changed
        self.txtSearch.KeyUp += self.on_filter_changed
        self.chkShowOnlyActive.Checked += self.on_filter_changed
        self.chkShowOnlyActive.Unchecked += self.on_filter_changed
        
        # Bind check all header event
        self.gridSheetsViews.Loaded += self.bind_grid_header_events
        
        # Setup dialog hooks
        self.comboSaveSets.SelectionChanged += self.save_set_action
        self.btnCustomFileName.Click += self.open_naming_editor
        self.btnOrderSheets.Click += self.open_order_editor
        self.btnBrowseOutput.Click += self.browse_folder
        
        # Navigation
        self.btnNext.Click += self.on_next_clicked
        self.btnBack.Click += self.on_back_clicked
        
        self.btnNavSelection.Click += lambda s, a: self.navigate_to_page(0)
        self.btnNavFormat.Click += lambda s, a: self.navigate_to_page(1)
        self.btnNavCreate.Click += lambda s, a: self.navigate_to_page(2)
        
        self.current_page_idx = 0
        self.show_page(0)
        
        # Initial updates
        self.update_filenames()
        self.filter_grid()

    def bind_grid_header_events(self, sender, args):
        """Helper to bind selection change events for all rows"""
        try:
            border = System.Windows.Media.VisualTreeHelper.GetChild(self.gridSheetsViews, 0)
            scroll_viewer = border.Child
            grid_headers_presenter = scroll_viewer.Template.FindName("PART_ColumnHeadersPresenter", scroll_viewer)
            # Find checkbox inside header and bind event
            chk_all = self.find_visual_child_by_name(self.gridSheetsViews, "chkSelectAll")
            if chk_all:
                chk_all.Checked += self.check_all_rows
                chk_all.Unchecked += self.uncheck_all_rows
        except:
            pass

    def find_visual_child_by_name(self, parent, name):
        """Visual tree traverser helper"""
        for i in range(System.Windows.Media.VisualTreeHelper.GetChildrenCount(parent)):
            child = System.Windows.Media.VisualTreeHelper.GetChild(parent, i)
            if child.DependencyObjectType.Name == "CheckBox" and hasattr(child, "Name") and child.Name == name:
                return child
            res = self.find_visual_child_by_name(child, name)
            if res: return res
        return None

    def check_all_rows(self, sender, args):
        for item in self.gridSheetsViews.ItemsSource:
            item.Selected = True
        self.gridSheetsViews.Items.Refresh()
        self.update_selection_stats()

    def uncheck_all_rows(self, sender, args):
        for item in self.gridSheetsViews.ItemsSource:
            item.Selected = False
        self.gridSheetsViews.Items.Refresh()
        self.update_selection_stats()

    def load_sheets_views(self):
        """Query Revit doc elements with optimized Titleblock grouping"""
        self.all_items = []
        
        # Pre-collect all TitleBlocks in a single fast collector and map to owner sheets
        tb_map = {}
        try:
            tb_coll = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_TitleBlocks).OfClass(DB.FamilyInstance).ToElements()
            for tb in tb_coll:
                sheet_id = tb.OwnerViewId
                if sheet_id and sheet_id != DB.ElementId.InvalidElementId:
                    tb_map[sheet_id.IntegerValue] = tb
        except:
            pass
            
        # Load sheets
        sheets = DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet).ToElements()
        for s in sheets:
            if not s.IsPlaceholder:
                tb = tb_map.get(s.Id.IntegerValue)
                self.all_items.append(SheetViewItem(s, is_sheet=True, titleblock=tb))
                
        # Load views
        views = DB.FilteredElementCollector(doc).OfClass(DB.View).ToElements()
        for v in views:
            if not v.IsTemplate and v.CanBePrinted and v.ViewType not in [DB.ViewType.Internal, DB.ViewType.ProjectBrowser, DB.ViewType.SystemBrowser]:
                # Exclude view sheets already added
                if v.ViewType != DB.ViewType.DrawingSheet:
                    self.all_items.append(SheetViewItem(v, is_sheet=False))
                    
        # Sort items initially
        self.all_items.sort(key=lambda x: x.Number)

    def load_sheet_sets(self):
        """Query view/sheet sets inside the model"""
        vss = DB.FilteredElementCollector(doc).OfClass(DB.ViewSheetSet).ToElements()
        self.vss_dict = {s.Name: s for s in vss}
        self.comboFilterSets.ItemsSource = ["<All Views/Sheets>"] + sorted(self.vss_dict.keys())
        self.comboFilterSets.SelectedIndex = 0

    def load_printers_async(self):
        import threading
        def worker():
            try:
                printers = list(PrinterSettings.InstalledPrinters)
                # Dispatch back to UI thread
                self.Dispatcher.Invoke(
                    System.Action(lambda: self.populate_printers(printers))
                )
            except:
                # Fallback on UI thread
                self.Dispatcher.Invoke(
                    System.Action(lambda: self.populate_printers(["PDF24", "Microsoft Print to PDF"]))
                )
        threading.Thread(target=worker).start()

    def populate_printers(self, printers):
        self.comboPrinter.ItemsSource = printers
        if self.comboPrinter.Items.Count > 0:
            self.comboPrinter.SelectedIndex = 0

    def on_printer_properties_clicked(self, sender, args):
        selected_printer = self.comboPrinter.SelectedItem
        if selected_printer and selected_printer != "Loading printers...":
            try:
                import System.Diagnostics
                # Run rundll32.exe printui.dll,PrintUIEntry /e /n "Printer Name" to show Preferences
                args_str = 'printui.dll,PrintUIEntry /e /n "{}"'.format(selected_printer)
                System.Diagnostics.Process.Start("rundll32.exe", args_str)
            except Exception as e:
                forms.alert("Could not open printer properties: {}".format(str(e)), title="Error")

    def load_saved_settings(self):
        """Load settings from user local AppData"""
        if not os.path.exists(settings_path): return
        try:
            with open(settings_path, "r") as f:
                data = json.load(f)
                
            self.chkPDF.IsChecked = data.get("chkPDF", self.chkPDF.IsChecked)
            self.chkDWG.IsChecked = data.get("chkDWG", self.chkDWG.IsChecked)
            self.chkDGN.IsChecked = data.get("chkDGN", False)
            self.chkDWF.IsChecked = data.get("chkDWF", False)
            self.chkNWC.IsChecked = data.get("chkNWC", False)
            self.chkIFC.IsChecked = data.get("chkIFC", False)
            self.chkIMG.IsChecked = data.get("chkIMG", False)
            
            # Load path
            path = data.get("output_path", "")
            if path and os.path.exists(path):
                self.output_path = path
                self.lblOutputPath.Text = path
                self.lblOutputPath.Foreground = System.Windows.Media.Brushes.Green
                
            # Load naming rules
            rules = data.get("naming_rules", [])
            if rules:
                self.naming_fields.Clear()
                for r in rules:
                    self.naming_fields.Add(NamingField(
                        r["Name"],
                        prefix=r.get("Prefix", ""),
                        suffix=r.get("Suffix", ""),
                        separator=r.get("Separator", "")
                    ))
        except:
            pass

    def save_settings(self):
        """Serialize settings to file"""
        try:
            data = {
                "chkPDF": bool(self.chkPDF.IsChecked),
                "chkDWG": bool(self.chkDWG.IsChecked),
                "chkDGN": bool(self.chkDGN.IsChecked),
                "chkDWF": bool(self.chkDWF.IsChecked),
                "chkNWC": bool(self.chkNWC.IsChecked),
                "chkIFC": bool(self.chkIFC.IsChecked),
                "chkIMG": bool(self.chkIMG.IsChecked),
                "output_path": getattr(self, "output_path", ""),
                "naming_rules": [
                    {
                        "Name": f.Name,
                        "Prefix": f.Prefix,
                        "Suffix": f.Suffix,
                        "Separator": f.Separator
                    }
                    for f in self.naming_fields
                ]
            }
            with open(settings_path, "w") as f:
                json.dump(data, f, indent=4)
        except:
            pass

    def on_area_mode_changed(self, sender, args):
        is_window = bool(self.rbAreaWindow.IsChecked)
        self.btnDefineWindow.IsEnabled = is_window
        if is_window and self.window_defined:
            self.lblWindowInfo.Visibility = Visibility.Visible
        else:
            self.lblWindowInfo.Visibility = Visibility.Collapsed

    def on_paper_mode_changed(self, sender, args):
        is_override = bool(self.rbPaperOverride.IsChecked)
        self.panelPaperOverride.IsEnabled = is_override

    def on_define_window_clicked(self, sender, args):
        self.Hide()
        try:
            uidoc = revit.uidoc
            pt1 = uidoc.Selection.PickPoint("Click the FIRST corner of the sheet print area window.")
            pt2 = uidoc.Selection.PickPoint("Click the SECOND corner of the sheet print area window.")
            
            self.window_pt1 = pt1
            self.window_pt2 = pt2
            self.window_defined = True
            
            # Calculate picked size in mm (1 foot = 304.8 mm)
            w = abs(pt2.X - pt1.X) * 304.8
            h = abs(pt2.Y - pt1.Y) * 304.8
            self.lblWindowInfo.Text = "Picked window size: {:.0f}x{:.0f} mm".format(w, h)
            self.lblWindowInfo.Visibility = Visibility.Visible
        except Exception as e:
            # Handle Escape/cancelation
            pass
        self.Show()

    def on_filter_changed(self, sender, args):
        self.filter_grid()

    def filter_grid(self):
        """Reactively filter sheets and views in Selection tab grid"""
        search_txt = self.txtSearch.Text.lower().strip()
        show_only_active = bool(self.chkShowOnlyActive.IsChecked)
        
        # Filter sets
        selected_set_name = self.comboFilterSets.SelectedItem
        set_views = None
        if selected_set_name and selected_set_name != "<All Views/Sheets>":
            target_set = self.vss_dict.get(selected_set_name)
            if target_set:
                set_views = [v.Id.IntegerValue for v in target_set.Views]
                
        filtered = []
        for item in self.all_items:
            # Mode match
            is_match = (self.rbSelectSheets.IsChecked and item.is_sheet) or (self.rbSelectViews.IsChecked and not item.is_sheet)
            if not is_match: continue
            
            # Set match
            if set_views is not None and item.element.Id.IntegerValue not in set_views:
                continue
                
            # Search match
            if search_txt:
                num_match = search_txt in item.Number.lower()
                name_match = search_txt in item.Name.lower()
                if not (num_match or name_match): continue
                
            # Show only active/selected check
            if show_only_active and not item.Selected: continue
            
            filtered.append(item)
            
        self.gridSheetsViews.ItemsSource = filtered
        self.gridSheetsViews.Items.Refresh()
        self.update_selection_stats()

    def update_selection_stats(self):
        """Re-calculate total selected count for footer"""
        sel_sheets = sum(1 for item in self.all_items if item.Selected and item.is_sheet)
        sel_views = sum(1 for item in self.all_items if item.Selected and not item.is_sheet)
        self.lblSelectionStats.Text = "{} sheets and {} views selected. Total: {}".format(
            sel_sheets, sel_views, sel_sheets + sel_views
        )

    def update_filenames(self):
        """Update Custom Name preview in the lists"""
        rules = [
            {"Name": f.Name, "Prefix": f.Prefix, "Suffix": f.Suffix, "Separator": f.Separator}
            for f in self.naming_fields
        ]
        for item in self.all_items:
            item.CustomFileName = resolve_name(item.element, rules, item.is_sheet)
        self.gridSheetsViews.Items.Refresh()

    def save_set_action(self, sender, args):
        """Revit native sheet sets management"""
        action = self.comboSaveSets.SelectedItem.Content
        self.comboSaveSets.SelectedIndex = 0
        if not action or action == "Save V/S Set": return
        
        checked = [item.element for item in self.all_items if item.Selected]
        if not checked:
            forms.alert("Please select at least one item first.", title="Warning")
            return
            
        if action == "New Set":
            name = forms.ask_for_string(title="New Set Name", prompt="Enter name of new view/sheet set:")
            if not name: return
            if name in self.vss_dict:
                forms.alert("A set with this name already exists.")
                return
            with revit.Transaction("SamTools - Create VSS"):
                vss = DB.ViewSheetSet.Create(doc, name)
                vset = DB.ViewSet()
                for e in checked: vset.Insert(e)
                vss.Views = vset
            self.load_sheet_sets()
            self.comboFilterSets.SelectedItem = name
            
        elif action == "Add to Existing":
            names = sorted(self.vss_dict.keys())
            if not names: return
            selected = forms.SelectFromList.show(names, title="Add to Set")
            if not selected: return
            target = self.vss_dict[selected]
            with revit.Transaction("SamTools - Edit VSS"):
                vset = target.Views
                for e in checked:
                    try: vset.Insert(e)
                    except: pass
                target.Views = vset
            self.load_sheet_sets()
            self.comboFilterSets.SelectedItem = selected
            
        elif action == "Delete Set":
            names = sorted(self.vss_dict.keys())
            if not names: return
            selected = forms.SelectFromList.show(names, title="Delete Set")
            if not selected: return
            target = self.vss_dict[selected]
            with revit.Transaction("SamTools - Delete VSS"):
                doc.Delete(target.Id)
            self.load_sheet_sets()

    def open_naming_editor(self, sender, args):
        """Invoke custom naming popup"""
        win = NamingEditorWindow(naming_xaml, self.naming_fields)
        win.Owner = self
        win.show_dialog()
        if win.success:
            self.naming_fields = win.selected_fields
            self.update_filenames()
            self.save_settings()

    def open_order_editor(self, sender, args):
        """Invoke export queue reordering editor"""
        selected = [item for item in self.all_items if item.Selected]
        if not selected:
            forms.alert("Please select sheets/views to order.", title="Warning")
            return
        win = OrderEditorWindow(order_xaml, selected)
        win.Owner = self
        win.show_dialog()
        if win.success:
            # Reorder all_items list to match user selection order
            non_selected = [item for item in self.all_items if not item.Selected]
            self.all_items = list(win.items) + non_selected
            self.filter_grid()

    def browse_folder(self, sender, args):
        path = forms.pick_folder(title="Choose Output Directory")
        if path:
            self.output_path = path
            self.lblOutputPath.Text = path
            self.lblOutputPath.Foreground = System.Windows.Media.Brushes.Green
            self.save_settings()

    def on_back_clicked(self, sender, args):
        if self.current_page_idx > 0:
            self.navigate_to_page(self.current_page_idx - 1)

    def on_next_clicked(self, sender, args):
        if self.current_page_idx == 2:
            # Trigger execution
            if not getattr(self, "output_path", ""):
                forms.alert("Please select an output directory.")
                return
            self.btnNext.IsEnabled = False
            self.btnBack.IsEnabled = False
            self.run_export_batch()
            self.btnBack.IsEnabled = True
            self.btnNext.Content = "Done"
            self.btnNext.IsEnabled = True
            # change Next click handler to close window when done
            self.btnNext.Click -= self.on_next_clicked
            self.btnNext.Click += lambda s, a: self.Close()
        else:
            self.navigate_to_page(self.current_page_idx + 1)

    def show_page(self, index):
        self.current_page_idx = index
        
        self.gridPageSelection.Visibility = Visibility.Visible if index == 0 else Visibility.Collapsed
        self.gridPageFormat.Visibility = Visibility.Visible if index == 1 else Visibility.Collapsed
        self.gridPageCreate.Visibility = Visibility.Visible if index == 2 else Visibility.Collapsed
        
        active_bg = System.Windows.Media.BrushConverter().ConvertFromString("#34495E")
        trans_bg = System.Windows.Media.Brushes.Transparent
        active_fg = System.Windows.Media.Brushes.White
        inactive_fg = System.Windows.Media.BrushConverter().ConvertFromString("#BDC3C7")
        
        self.btnNavSelection.Background = active_bg if index == 0 else trans_bg
        self.btnNavSelection.Foreground = active_fg if index == 0 else inactive_fg
        
        self.btnNavFormat.Background = active_bg if index == 1 else trans_bg
        self.btnNavFormat.Foreground = active_fg if index == 1 else inactive_fg
        
        self.btnNavCreate.Background = active_bg if index == 2 else trans_bg
        self.btnNavCreate.Foreground = active_fg if index == 2 else inactive_fg
        
        if index == 0:
            self.lblStepTitle.Text = "Select Sheets & Views"
        elif index == 1:
            self.lblStepTitle.Text = "Export Configuration"
        elif index == 2:
            self.lblStepTitle.Text = "Batch Export Queue"
            
        self.btnBack.IsEnabled = (index > 0)
        self.btnNext.Content = "Export" if index == 2 else "Next"

    def navigate_to_page(self, index):
        if index == 0:
            self.show_page(0)
        elif index == 1:
            selected = [item for item in self.all_items if item.Selected]
            if not selected:
                forms.alert("Please select at least one sheet/view.")
                return
            self.show_page(1)
        elif index == 2:
            selected = [item for item in self.all_items if item.Selected]
            if not selected:
                forms.alert("Please select at least one sheet/view.")
                return
            self.formats = []
            if self.chkPDF.IsChecked: self.formats.append("PDF")
            if self.chkDWG.IsChecked: self.formats.append("DWG")
            if self.chkDGN.IsChecked: self.formats.append("DGN")
            if self.chkDWF.IsChecked: self.formats.append("DWF")
            if self.chkNWC.IsChecked: self.formats.append("NWC")
            if self.chkIFC.IsChecked: self.formats.append("IFC")
            if self.chkIMG.IsChecked: self.formats.append("IMG")
            
            if not self.formats:
                forms.alert("Please select at least one export format.")
                return
                
            self.queue_items = []
            for item in selected:
                for fmt in self.formats:
                    self.queue_items.append(ExportQueueItem(item.element, item.is_sheet, fmt, item.CustomFileName))
                    
            self.gridQueue.ItemsSource = self.queue_items
            self.gridQueue.Items.Refresh()
            self.show_page(2)

    def run_export_batch(self):
        """Main batch processor"""
        total = len(self.queue_items)
        if total == 0: return
        
        self.progressBar.Value = 0
        self.lblProgressPercent.Text = "0%"
        
        # Save settings prior to run
        self.save_settings()
        
        # Setup settings dictionary
        setup_opts = {
            "placement_center": bool(self.rbPlacementCenter.IsChecked),
            "placement_x": float(self.txtPlacementX.Text or 0),
            "placement_y": float(self.txtPlacementY.Text or 0),
            "area_window": bool(self.rbAreaWindow.IsChecked),
            "window_pt1": self.window_pt1,
            "window_pt2": self.window_pt2,
            "zoom_fit": bool(self.rbZoomFit.IsChecked),
            "zoom_percent": int(self.txtZoomPercent.Text or 100),
            "printer": self.comboPrinter.SelectedItem,
            "paper_auto": bool(self.rbPaperAuto.IsChecked),
            "paper_override_format": self.comboPaperSize.SelectedItem.Content if self.comboPaperSize.SelectedItem else "Default",
            "paper_override_landscape": bool(self.rbOrientLandscape.IsChecked),
            "vector_processing": bool(self.rbRemoveLinesVector.IsChecked),
            "raster_quality": self.comboRasterQuality.SelectedItem.Content if self.comboRasterQuality.SelectedItem else "Medium",
            "color_depth": self.comboColorDepth.SelectedItem.Content if self.comboColorDepth.SelectedItem else "Color",
            "view_links_blue": bool(self.chkViewLinksBlue.IsChecked),
            "hide_ref": bool(self.chkHideRefPlanes.IsChecked),
            "hide_unref": bool(self.chkHideUnrefTags.IsChecked),
            "hide_scope": bool(self.chkHideScopeBoxes.IsChecked),
            "hide_crop": bool(self.chkHideCropBoundaries.IsChecked),
            "replace_halftone": bool(self.chkReplaceHalftones.IsChecked),
            "mask_coincident": bool(self.chkMaskCoincidentLines.IsChecked),
            "dwg_setup_name": self.comboDwgSetup.SelectedItem,
            "combine": bool(self.rbFileCombine.IsChecked)
        }
        
        with revit.Transaction("SamTools - Batch Export"):
            for i, item in enumerate(self.queue_items):
                item.Status = "Exporting..."
                self.gridQueue.Items.Refresh()
                
                # WPF Render loop refresh to prevent Not Responding state
                Dispatcher.CurrentDispatcher.Invoke(
                    System.Action(lambda: None),
                    DispatcherPriority.Background
                )
                
                try:
                    self.export_single_item(item, setup_opts)
                    item.Status = "Success"
                except Exception as e:
                    item.Status = "Error: {}".format(str(e))
                    
                self.gridQueue.Items.Refresh()
                progress = int((i + 1) * 100.0 / total)
                self.progressBar.Value = progress
                self.lblProgressPercent.Text = "{}%".format(progress)

        # Validation & Logging Phase
        try:
            output = script.get_output()
            output.print_line(" ")
            output.print_line("==================================================================================")
            output.print_line("                  SAMTOOLS BATCH EXPORT LOG & SHEET VALIDATION                    ")
            output.print_line("==================================================================================")
            
            table_data = []
            mismatches = []
            
            for item in self.queue_items:
                if item.Format != "PDF":
                    continue
                if "Error" in item.Status:
                    table_data.append([
                        item.element.SheetNumber if item.is_sheet else "N/A",
                        item.element.Name,
                        "N/A", "N/A", "N/A", "N/A", "N/A",
                        "❌ Export Error"
                    ])
                    continue
                
                # Retrieve Revit Sheet details
                sheet = item.element
                revit_w = 0.0
                revit_h = 0.0
                
                if item.is_sheet:
                    tb = None
                    try:
                        tb_coll = DB.FilteredElementCollector(doc, sheet.Id).OfCategory(DB.BuiltInCategory.OST_TitleBlocks).OfClass(DB.FamilyInstance).ToElements()
                        if tb_coll:
                            tb = tb_coll[0]
                    except:
                        pass
                    
                    if tb:
                        try:
                            # 1. Try bounding box (actual sheet outline)
                            bbox = tb.get_BoundingBox(sheet)
                            if bbox:
                                revit_w = (bbox.Max.X - bbox.Min.X) * 304.8
                                revit_h = (bbox.Max.Y - bbox.Min.Y) * 304.8
                        except:
                            pass
                            
                        if revit_w == 0 or revit_h == 0:
                            # 2. Fallback to title block parameters
                            try:
                                w_param = tb.get_Parameter(DB.BuiltInParameter.SHEET_WIDTH)
                                h_param = tb.get_Parameter(DB.BuiltInParameter.SHEET_HEIGHT)
                                if w_param and h_param:
                                    revit_w = w_param.AsDouble() * 304.8
                                    revit_h = h_param.AsDouble() * 304.8
                            except:
                                pass
                
                # Retrieve exported PDF details
                pdf_filename = item.TargetName
                if not pdf_filename.lower().endswith(".pdf"):
                    pdf_filename += ".pdf"
                pdf_path = os.path.join(self.output_path, pdf_filename)
                
                pdf_w, pdf_h = get_pdf_page_size(pdf_path)
                
                # Properties
                orient = "Landscape" if revit_w > revit_h else "Portrait"
                scale_factor = "100%" if not setup_opts["zoom_fit"] else "Fit"
                border_offset = "0, 0 mm" if setup_opts["placement_center"] else "{}, {} mm".format(setup_opts["placement_x"], setup_opts["placement_y"])
                
                revit_size_str = "{:.1f}x{:.1f} mm".format(revit_w, revit_h) if revit_w > 0 else "Unknown"
                pdf_size_str = "{:.1f}x{:.1f} mm".format(pdf_w, pdf_h) if pdf_w else "Unknown"
                
                # Check for mismatch > 1 mm
                status = "PASS"
                if revit_w > 0 and revit_h > 0 and pdf_w and pdf_h:
                    diff_w = abs(revit_w - pdf_w)
                    diff_h = abs(revit_h - pdf_h)
                    
                    # Also check swapped orientation match
                    diff_w_swap = abs(revit_w - pdf_h)
                    diff_h_swap = abs(revit_h - pdf_w)
                    
                    is_match = (diff_w <= 1.0 and diff_h <= 1.0) or (diff_w_swap <= 1.0 and diff_h_swap <= 1.0)
                    if not is_match:
                        status = "❌ FAIL"
                        mismatches.append(item.element.SheetNumber if item.is_sheet else item.element.Name)
                    else:
                        status = "✔️ PASS"
                else:
                    status = "⚠️ UNKNOWN"
                
                table_data.append([
                    item.element.SheetNumber if item.is_sheet else "N/A",
                    item.element.Name,
                    revit_size_str,
                    pdf_size_str,
                    orient,
                    scale_factor,
                    border_offset,
                    status
                ])
                
            if table_data:
                output.print_table(
                    table_data=table_data,
                    title="Exported Sheets Validation Report",
                    columns=["Sheet Num", "Sheet Name", "Revit Size", "PDF Size", "Orientation", "Scale", "Offset", "Validation Status"]
                )
                
            if mismatches:
                output.print_line("⚠️ WARNING: Validation mismatch greater than 1mm detected on sheets: {}".format(", ".join(mismatches)), font_color="red")
                forms.alert("Batch Export completed, but validation failed for sheets: {}. Please check output log for details.".format(", ".join(mismatches)), title="Validation Mismatch Alert")
            else:
                output.print_line("✔️ SUCCESS: All exported sheet sizes match the Revit layouts exactly (mismatch <= 1mm).", font_color="green")
        except Exception as val_err:
            pass

        # Open Output folder
        try:
            os.startfile(self.output_path)
        except:
            pass
        forms.alert("Batch Export Operation Completed!", title="Success")

    def export_single_item(self, item, opts):
        """Maps output task to native Revit export APIs"""
        fmt = item.Format
        element = item.element
        is_sheet = item.is_sheet
        name = item.TargetName
        
        view_ids = List[DB.ElementId]()
        view_ids.Add(element.Id)
        
        if fmt == "PDF":
            # Native PDF Export (Revit 2022+)
            options = DB.PDFExportOptions()
            options.Combine = False # Export sheet-by-sheet with custom filename
            options.FileName = name
            
            # Dynamically set Paper Format and Orientation
            paper_w = 841.0  # default fallback A1 width
            paper_h = 594.0
            sheet_w = 0.0
            sheet_h = 0.0
            
            # Retrieve sheet width/height if available for auto-offset sizing fallback
            if is_sheet:
                try:
                    tb_coll = DB.FilteredElementCollector(doc, element.Id).OfCategory(DB.BuiltInCategory.OST_TitleBlocks).OfClass(DB.FamilyInstance).ToElements()
                    if tb_coll:
                        tb = tb_coll[0]
                        w_param = tb.get_Parameter(DB.BuiltInParameter.SHEET_WIDTH)
                        h_param = tb.get_Parameter(DB.BuiltInParameter.SHEET_HEIGHT)
                        if w_param and h_param:
                            sheet_w = w_param.AsDouble() * 304.8
                            sheet_h = h_param.AsDouble() * 304.8
                except:
                    pass

            paper_format = DB.ExportPaperFormat.Default
            paper_orientation = DB.PageOrientationType.Landscape

            if not opts.get("paper_auto", True):
                # Manual Paper Override Selection
                fmt_str = opts.get("paper_override_format", "Default")
                if "A0" in fmt_str: paper_format = DB.ExportPaperFormat.ISO_A0
                elif "A1" in fmt_str: paper_format = DB.ExportPaperFormat.ISO_A1
                elif "A2" in fmt_str: paper_format = DB.ExportPaperFormat.ISO_A2
                elif "A3" in fmt_str: paper_format = DB.ExportPaperFormat.ISO_A3
                elif "A4" in fmt_str: paper_format = DB.ExportPaperFormat.ISO_A4
                elif "ANSI A" in fmt_str: paper_format = DB.ExportPaperFormat.ANSI_A
                elif "ANSI B" in fmt_str: paper_format = DB.ExportPaperFormat.ANSI_B
                elif "ANSI C" in fmt_str: paper_format = DB.ExportPaperFormat.ANSI_C
                elif "ANSI D" in fmt_str: paper_format = DB.ExportPaperFormat.ANSI_D
                elif "ANSI E" in fmt_str: paper_format = DB.ExportPaperFormat.ANSI_E
                else: paper_format = DB.ExportPaperFormat.Default
                
                paper_orientation = DB.PageOrientationType.Landscape if opts.get("paper_override_landscape", True) else DB.PageOrientationType.Portrait
            else:
                # Auto-detect from sheet titleblock size
                if is_sheet:
                    tb = None
                    try:
                        tb_coll = DB.FilteredElementCollector(doc, element.Id).OfCategory(DB.BuiltInCategory.OST_TitleBlocks).OfClass(DB.FamilyInstance).ToElements()
                        if tb_coll:
                            tb = tb_coll[0]
                    except:
                        pass
                    
                    if tb:
                        try:
                            w_param = tb.get_Parameter(DB.BuiltInParameter.SHEET_WIDTH)
                            h_param = tb.get_Parameter(DB.BuiltInParameter.SHEET_HEIGHT)
                            if w_param and h_param:
                                sheet_w = w_param.AsDouble() * 304.8
                                sheet_h = h_param.AsDouble() * 304.8
                                
                                # Determine orientation
                                if sheet_w > sheet_h:
                                    paper_orientation = DB.PageOrientationType.Landscape
                                else:
                                    paper_orientation = DB.PageOrientationType.Portrait
                                    
                                # Sort dimensions to match paper format standard dimensions
                                long_edge = max(sheet_w, sheet_h)
                                short_edge = min(sheet_w, sheet_h)
                                
                                # Match to standard formats
                                if abs(long_edge - 1189) < 15 and abs(short_edge - 841) < 15:
                                    paper_format = DB.ExportPaperFormat.ISO_A0
                                elif abs(long_edge - 841) < 15 and abs(short_edge - 594) < 15:
                                    paper_format = DB.ExportPaperFormat.ISO_A1
                                elif abs(long_edge - 594) < 15 and abs(short_edge - 420) < 15:
                                    paper_format = DB.ExportPaperFormat.ISO_A2
                                elif abs(long_edge - 420) < 15 and abs(short_edge - 297) < 15:
                                    paper_format = DB.ExportPaperFormat.ISO_A3
                                elif abs(long_edge - 297) < 15 and abs(short_edge - 210) < 15:
                                    paper_format = DB.ExportPaperFormat.ISO_A4
                                else:
                                    paper_format = DB.ExportPaperFormat.Default
                        except:
                            pass
            
            try:
                options.PaperFormat = paper_format
                options.PaperOrientation = paper_orientation
            except Exception as ex:
                pass
            
            # Determine expected paper size (in mm) from format & orientation
            if paper_format == DB.ExportPaperFormat.ISO_A0:
                paper_w, paper_h = (1189.0, 841.0) if paper_orientation == DB.PageOrientationType.Landscape else (841.0, 1189.0)
            elif paper_format == DB.ExportPaperFormat.ISO_A1:
                paper_w, paper_h = (841.0, 594.0) if paper_orientation == DB.PageOrientationType.Landscape else (594.0, 841.0)
            elif paper_format == DB.ExportPaperFormat.ISO_A2:
                paper_w, paper_h = (594.0, 420.0) if paper_orientation == DB.PageOrientationType.Landscape else (420.0, 594.0)
            elif paper_format == DB.ExportPaperFormat.ISO_A3:
                paper_w, paper_h = (420.0, 297.0) if paper_orientation == DB.PageOrientationType.Landscape else (297.0, 420.0)
            elif paper_format == DB.ExportPaperFormat.ISO_A4:
                paper_w, paper_h = (297.0, 210.0) if paper_orientation == DB.PageOrientationType.Landscape else (210.0, 297.0)
            elif paper_format == DB.ExportPaperFormat.ANSI_A:
                paper_w, paper_h = (279.4, 215.9) if paper_orientation == DB.PageOrientationType.Landscape else (215.9, 279.4)
            elif paper_format == DB.ExportPaperFormat.ANSI_B:
                paper_w, paper_h = (431.8, 279.4) if paper_orientation == DB.PageOrientationType.Landscape else (279.4, 431.8)
            elif paper_format == DB.ExportPaperFormat.ANSI_C:
                paper_w, paper_h = (558.8, 431.8) if paper_orientation == DB.PageOrientationType.Landscape else (431.8, 558.8)
            elif paper_format == DB.ExportPaperFormat.ANSI_D:
                paper_w, paper_h = (863.6, 558.8) if paper_orientation == DB.PageOrientationType.Landscape else (558.8, 863.6)
            elif paper_format == DB.ExportPaperFormat.ANSI_E:
                paper_w, paper_h = (1117.6, 863.6) if paper_orientation == DB.PageOrientationType.Landscape else (863.6, 1117.6)
            else:
                # For Default custom format, match the sheet size
                paper_w = sheet_w if sheet_w > 0 else 841.0
                paper_h = sheet_h if sheet_h > 0 else 594.0
            
            if opts["area_window"] and opts["window_pt1"] and opts["window_pt2"]:
                try:
                    pt1 = opts["window_pt1"]
                    pt2 = opts["window_pt2"]
                    win_min_x = min(pt1.X, pt2.X)
                    win_min_y = min(pt1.Y, pt2.Y)
                    win_w_ft = abs(pt2.X - pt1.X)
                    win_h_ft = abs(pt2.Y - pt1.Y)
                    
                    options.PaperPlacement = DB.PaperPlacementType.Margins
                    
                    # Manual offset in feet (if any)
                    user_x_ft = opts["placement_x"] / 304.8
                    user_y_ft = opts["placement_y"] / 304.8
                    
                    options.OriginOffsetX = -win_min_x + user_x_ft
                    options.OriginOffsetY = -win_min_y + user_y_ft
                    
                    if opts["zoom_fit"]:
                        if win_w_ft > 0 and win_h_ft > 0:
                            paper_w_ft = paper_w / 304.8
                            paper_h_ft = paper_h / 304.8
                            scale_w = paper_w_ft / win_w_ft
                            scale_h = paper_h_ft / win_h_ft
                            scale_percent = min(scale_w, scale_h) * 100
                            
                            # Clamp zoom to [10, 1000]
                            if scale_percent < 10:
                                scale_percent = 10
                            elif scale_percent > 1000:
                                scale_percent = 1000
                            options.ZoomType = DB.ZoomType.Zoom
                            options.ZoomPercentage = int(scale_percent)
                        else:
                            options.ZoomType = DB.ZoomType.FitToPage
                    else:
                        options.ZoomType = DB.ZoomType.Zoom
                        options.ZoomPercentage = opts["zoom_percent"]
                except Exception as ex:
                    # Fallback on exception
                    options.ZoomType = DB.ZoomType.FitToPage
                    options.PaperPlacement = DB.PaperPlacementType.Center
            else:
                if opts["zoom_fit"]:
                    options.ZoomType = DB.ZoomType.FitToPage
                else:
                    options.ZoomType = DB.ZoomType.Zoom
                    options.ZoomPercentage = opts["zoom_percent"]
                    
                options.PaperPlacement = DB.PaperPlacementType.Center if opts["placement_center"] else DB.PaperPlacementType.Margins
                if not opts["placement_center"]:
                    try:
                        # Offset from corner (No Margin) - set origin offsets directly from UI parameters
                        options.OriginOffsetX = opts["placement_x"] / 304.8
                        options.OriginOffsetY = opts["placement_y"] / 304.8
                    except:
                        pass
                    
            # Set Raster Quality
            rq = opts["raster_quality"]
            if rq == "Presentation": options.RasterQuality = DB.RasterQualityType.Presentation
            elif rq == "High": options.RasterQuality = DB.RasterQualityType.High
            elif rq == "Medium": options.RasterQuality = DB.RasterQualityType.Medium
            else: options.RasterQuality = DB.RasterQualityType.Low
            
            # Set Color
            cd = opts["color_depth"]
            if cd == "Color": options.ColorDepth = DB.ColorDepthType.Color
            elif cd == "Grayscale": options.ColorDepth = DB.ColorDepthType.GrayScale
            else: options.ColorDepth = DB.ColorDepthType.BlackAndWhite
            
            # Options
            try:
                options.AlwaysUseRaster = not opts["vector_processing"]
            except:
                pass
            try:
                options.HideReferencePlane = opts["hide_ref"]
            except:
                pass
            try:
                options.HideUnreferencedViewTags = opts["hide_unref"]
            except:
                pass
            try:
                options.HideScopeBoxes = opts["hide_scope"]
            except:
                pass
            try:
                options.HideCropBoundaries = opts["hide_crop"]
            except:
                pass
            try:
                options.ViewLinksInBlue = opts["view_links_blue"]
            except:
                pass
            try:
                options.ReplaceHalftoneWithThinLines = opts["replace_halftone"]
            except:
                pass
            try:
                options.MaskCoincidentLines = opts["mask_coincident"]
            except:
                pass
                
            doc.Export(self.output_path, view_ids, options)

        elif fmt == "DWG":
            # DWG Exporter
            setup_name = opts["dwg_setup_name"]
            if setup_name and setup_name != "<Standard Options>" and setup_name in self.dwg_setup_dict:
                options = self.dwg_setup_dict[setup_name].GetDWGExportOptions()
            else:
                options = DB.DWGExportOptions()
            doc.Export(self.output_path, name, view_ids, options)

        elif fmt == "DGN":
            options = DB.DGNExportOptions()
            doc.Export(self.output_path, name, view_ids, options)

        elif fmt == "DWF":
            options = DB.DWF2DExportOptions()
            options.ExportingSheetParameters = True
            doc.Export(self.output_path, name, view_ids, options)

        elif fmt == "IFC":
            options = DB.IFCExportOptions()
            if not is_sheet:
                options.FilterViewId = element.Id
            # Note: doc.Export for IFC requires the filename to have extension or folder path
            doc.Export(self.output_path, name, options)

        elif fmt == "IMG":
            options = DB.ImageExportOptions()
            options.ExportRange = DB.ExportRange.SetOfViews
            options.SetViewsAndSheets(view_ids)
            options.FilePath = os.path.join(self.output_path, name)
            
            # Map quality to DPI
            rq = opts["raster_quality"]
            if rq == "Presentation": options.ImageResolution = DB.ImageResolution.DPI_600
            elif rq == "High": options.ImageResolution = DB.ImageResolution.DPI_300
            elif rq == "Medium": options.ImageResolution = DB.ImageResolution.DPI_150
            else: options.ImageResolution = DB.ImageResolution.DPI_72
            
            options.HLRandWFViewsFileType = DB.ImageFileType.PNG
            doc.ExportImage(options)

        elif fmt == "NWC":
            try:
                from Autodesk.Revit.DB import NavisworksExportOptions
                options = NavisworksExportOptions()
                doc.Export(self.output_path, name, options)
            except Exception as e:
                raise Exception("Navisworks Exporter assembly not installed or loaded.")


def resolve_name(element, naming_rules, is_sheet):
    """Compile custom filename pattern for a given Revit sheet or view"""
    parts = []
    for field in naming_rules:
        val = get_parameter_value(element, field["Name"])
        part = "{}{}{}{}".format(field["Prefix"], val, field["Suffix"], field["Separator"])
        parts.append(part)
    fullname = "".join(parts)
    return sanitize_filename(fullname)


def get_pdf_page_size(pdf_path):
    """Parses raw PDF file structure to retrieve the physical page dimensions from /MediaBox"""
    try:
        if not os.path.exists(pdf_path):
            return None, None
        with open(pdf_path, 'rb') as f:
            content = f.read(5 * 1024 * 1024) # read first 5MB
            
            # Find /MediaBox [llx lly urx ury]
            match = re.search(r'/MediaBox\s*\[\s*(-?[0-9.]+)\s+(-?[0-9.]+)\s+(-?[0-9.]+)\s+(-?[0-9.]+)\s*\]', content)
            if match:
                x1 = float(match.group(1))
                y1 = float(match.group(2))
                x2 = float(match.group(3))
                y2 = float(match.group(4))
                width_pt = abs(x2 - x1)
                height_pt = abs(y2 - y1)
                # Convert PDF points (1/72 inch) to millimeters (25.4 mm/inch)
                width_mm = width_pt * 25.4 / 72.0
                height_mm = height_pt * 25.4 / 72.0
                return width_mm, height_mm
    except Exception as e:
        pass
    return None, None


def run_exporter(default_format="PDF"):
    """Entry point for pushbutton scripts"""
    win = ExportWindow(exporter_xaml, default_format=default_format)
    win.show_dialog()
