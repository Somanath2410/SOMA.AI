Add-Type -AssemblyName System.Drawing

$tabPath = "C:\Users\somnath.misal\AppData\Roaming\pyRevit\Extensions\SamTools.extension\SamTools.tab"
$pushbuttons = Get-ChildItem -Path $tabPath -Recurse -Filter "*.pushbutton" -Directory

$colors = @("#007ACC", "#4CAF50", "#FF6B6B", "#FF9800", "#9C27B0", "#E91E63", "#009688", "#607D8B", "#3F51B5", "#795548")
$colorIdx = 0

foreach ($pb in $pushbuttons) {
    $iconPath = Join-Path $pb.FullName "icon.png"
    
    # Get 1 or 2 letters from the command name
    $cmdName = $pb.Name.Replace(".pushbutton", "")
    $words = $cmdName.Split(' ')
    $text = ""
    if ($words.Length -ge 2) {
        $text = $words[0].Substring(0,1) + $words[1].Substring(0,1)
    } elseif ($words[0].Length -ge 2) {
        $text = $words[0].Substring(0,2)
    } else {
        $text = $words[0]
    }
    $text = $text.ToUpper()

    # Create bitmap 96x96
    $bmp = New-Object System.Drawing.Bitmap(96, 96)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
    
    # Make background transparent
    $g.Clear([System.Drawing.Color]::Transparent)
    
    # Draw background circle
    $hex = $colors[$colorIdx % $colors.Length]
    $color = [System.Drawing.ColorTranslator]::FromHtml($hex)
    $brush = New-Object System.Drawing.SolidBrush($color)
    
    $rect = New-Object System.Drawing.Rectangle(0, 0, 96, 96)
    $g.FillEllipse($brush, 4, 4, 88, 88)
    
    # Draw text
    $font = New-Object System.Drawing.Font("Segoe UI", 32, [System.Drawing.FontStyle]::Bold)
    $textBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
    
    $format = New-Object System.Drawing.StringFormat
    $format.Alignment = [System.Drawing.StringAlignment]::Center
    $format.LineAlignment = [System.Drawing.StringAlignment]::Center
    
    $g.DrawString($text, $font, $textBrush, $rect, $format)
    
    $bmp.Save($iconPath, [System.Drawing.Imaging.ImageFormat]::Png)
    
    $g.Dispose()
    $bmp.Dispose()
    $brush.Dispose()
    $textBrush.Dispose()
    $font.Dispose()
    
    $colorIdx++
}

Write-Output "Icons generated successfully for all $($pushbuttons.Count) tools!"
