# SamTools BIM Engineering Automation Platform

An enterprise-grade pyRevit extension for Data Centre BIM automation, AI-assisted Revit workflows, Model Context Protocol (MCP) tool orchestration, and ISO 19650 documentation.

---

## 🌟 Key Subsystems & Features

### 1. 🤖 SOMA AI Assistant & Tool Registry (`SamTools.tab/AIAssistant`)
- **Centralized Tool Registry:** Safe execution wrapper managing Revit transactions, parameter validation, and user action confirmations.
- **Natural Language Orchestrator:** Parse prompts into action tools (`generate_sheets`, `find_duplicate_elements`, `ai_clash_resolution`, `auto_sheet_layout`, `ai_parameter_audit`).
- **Secure Key Resolution:** Encrypted and environment-variable API key resolution (`OPENAI_API_KEY`, `SAMTOOLS_AI_KEY`).

### 2. 🔌 Model Context Protocol (MCP) Integration (`lib/samtools/mcp`)
- Standardized **JSON-RPC 2.0 MCP Protocol Server** exposing Revit API tool endpoints (`initialize`, `tools/list`, `tools/call`, `ping`) to external AI coding assistants and agents.

### 3. 🔌 3D Spatial Pathfinding & Geometry Engine (`lib/samtools/utils/geometry.py`)
- **SpatialGrid:** 3D Spatial Hash Grid mapping model geometry bounding boxes with clearance buffers.
- **A* PathFinder:** 3D discrete grid pathfinder with path smoothing for clash-avoiding cable tray, duct, and pipe routing.

### 4. 📐 Data Centre BIM Suite (`lib/samtools/datacenter`)
- **RackLayoutEngine:** Calculates server rack grid coordinates, row/aisle spacing, and hot/cold aisle configurations.
- **CableTrayRouter:** Combines spatial hash grid clash checking with A* pathfinding to generate obstacle-free 3D cable tray runs.

### 5. 🛡️ QA/QC Model Audit Engine (`lib/samtools/qaqc`)
- Automated model compliance checks covering duplicate elements, unconnected structural columns, unplaced rooms, CAD imports, and unresolved Revit warnings with `PASS`, `WARNING`, and `ERROR` status reports.

### 6. 📄 BIM Documentation & Export Suite (`lib/samtools/documentation` & `lib/samtools/export`)
- **SheetService:** ISO sheet creation, batch generation, and titleblock binding.
- **ViewService:** View placement and grid alignment.
- **TagService:** Category-based automatic tagging.
- **ProExporter:** Modular PDF (`PDFExportService`), DWG (`DWGExportService`), and IFC (`IFCExportService`) batch exporting.

---

## 📁 Repository Architecture Map

```
SamTools.extension
│
├── SamTools.tab                --> [ Revit Ribbon Tab (AIAssistant, Modeling, Documentation, QAQC, Schedules, Export) ]
├── StructuralSuite.tab         --> [ C# WPF Structural Suite Control Center ]
│
├── lib
│   └── samtools
│       ├── core                --> [ DocumentContext, TransactionManager, BaseModel, BaseView, BaseController ]
│       ├── ai                  --> [ ToolRegistry & AI Command Executors ]
│       ├── mcp                 --> [ MCPToolRegistry & MCPProtocolHandler ]
│       ├── datacenter          --> [ RackLayoutEngine & CableTrayRouter ]
│       ├── documentation       --> [ SheetService, ViewService, TagService ]
│       ├── qaqc                --> [ QAQCAuditEngine ]
│       ├── export              --> [ PDFExportService, DWGExportService, IFCExportService ]
│       ├── geometry            --> [ SpatialGrid & A* PathFinder ]
│       ├── ui                  --> [ Modern Dark Theme WPF Styles ]
│       └── tests               --> [ Automated Test Suite (test_core.py) ]
│
└── resources                   --> [ Icons, WPF XAML Templates, and Configuration Schemas ]
```

---

## 🚀 Installation & Testing

1. Install [pyRevit 6.5.x](https://github.com/eirannejad/pyRevit).
2. Copy `SamTools.extension` into your pyRevit extensions directory (`%appdata%\pyRevit\Extensions`).
3. Reload pyRevit (`pyRevit -> Reload`).
4. Run core unit tests in Python:
   ```bash
   python lib/samtools/tests/test_core.py
   ```
