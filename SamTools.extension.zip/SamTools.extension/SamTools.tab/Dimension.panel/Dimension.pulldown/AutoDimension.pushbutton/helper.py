# -*- coding: utf-8 -*-
from pyrevit import DB

class AutoDimensionEngine:
    def __init__(self, doc, uidoc, options):
        self.doc = doc
        self.uidoc = uidoc
        self.options = options
        
    def get_wall_end_references(self, wall):
        refs = []
        loc = wall.Location
        if not isinstance(loc, DB.LocationCurve) or not isinstance(loc.Curve, DB.Line): return refs
        line = loc.Curve
        wall_dir = line.Direction.Normalize()
        p0 = line.GetEndPoint(0)
        
        opt = DB.Options()
        opt.ComputeReferences = True
        opt.IncludeNonVisibleObjects = True
        geom = wall.get_Geometry(opt)
        if not geom: return refs
        
        end_faces = [] 
        def process_solid(solid):
            if solid.Faces.Size > 0:
                for face in solid.Faces:
                    if isinstance(face, DB.PlanarFace):
                        if abs(face.FaceNormal.DotProduct(wall_dir)) > 0.99:
                            dist = (face.Origin - p0).DotProduct(wall_dir)
                            if face.Reference: end_faces.append((dist, face.Reference))
                                
        for g_obj in geom:
            if isinstance(g_obj, DB.Solid): process_solid(g_obj)
            elif isinstance(g_obj, DB.GeometryInstance):
                for inst_obj in g_obj.GetInstanceGeometry():
                    if isinstance(inst_obj, DB.Solid): process_solid(inst_obj)
                        
        if end_faces:
            end_faces.sort(key=lambda x: x[0])
            refs.append(end_faces[0][1])
            if end_faces[-1][0] - end_faces[0][0] > 0.1:
                refs.append(end_faces[-1][1])
        return refs

    def get_insert_references(self, wall):
        refs = []
        insert_ids = wall.FindInserts(True, True, True, True)
        for i_id in insert_ids:
            inst = self.doc.GetElement(i_id)
            if not isinstance(inst, DB.FamilyInstance): continue
            
            # Simple width references
            try:
                left = inst.GetReferences(DB.FamilyInstanceReferenceType.Left)
                right = inst.GetReferences(DB.FamilyInstanceReferenceType.Right)
                if left and len(left) > 0: refs.append(left[0])
                if right and len(right) > 0: refs.append(right[0])
            except Exception:
                continue
        return refs

    def get_intersecting_grid_references(self, wall):
        refs = []
        bb = wall.get_BoundingBox(self.doc.ActiveView)
        if not bb: return refs
        outline = DB.Outline(bb.Min, bb.Max)
        grids = DB.FilteredElementCollector(self.doc).OfClass(DB.Grid).WherePasses(DB.BoundingBoxIntersectsFilter(outline)).ToElements()
        for grid in grids:
            try:
                ref = DB.Reference(grid)
                if ref: refs.append(ref)
            except Exception:
                pass
        return refs

    def get_intersecting_wall_references(self, wall):
        refs = []
        bb = wall.get_BoundingBox(self.doc.ActiveView)
        if not bb: return refs
        outline = DB.Outline(bb.Min, bb.Max)
        i_walls = DB.FilteredElementCollector(self.doc).OfClass(DB.Wall).WherePasses(DB.BoundingBoxIntersectsFilter(outline)).ToElements()
        for i_wall in i_walls:
            if i_wall.Id == wall.Id: continue
            loc = i_wall.Location
            if isinstance(loc, DB.LocationCurve) and loc.Curve.Reference:
                refs.append(loc.Curve.Reference)
        return refs

    def run(self, selected_walls):
        view = self.doc.ActiveView
        success_count = 0
        
        with DB.Transaction(self.doc, "SamTools: Enterprise Auto Dimension") as t:
            t.Start()
            for wall in selected_walls:
                if self.options.get("ignore_curtain") and (wall.WallType.Kind == DB.WallKind.Curtain or wall.WallType.Kind == DB.WallKind.Stacked):
                    continue
                    
                loc = wall.Location
                if not isinstance(loc, DB.LocationCurve) or not isinstance(loc.Curve, DB.Line): continue 
                    
                line = loc.Curve
                wall_normal = DB.XYZ(-line.Direction.Y, line.Direction.X, 0).Normalize()
                offset_dist = self.options.get("offset_mm", 1000) / 304.8 
                
                p1 = line.GetEndPoint(0) + wall_normal * offset_dist
                p2 = line.GetEndPoint(1) + wall_normal * offset_dist
                dim_line = DB.Line.CreateBound(p1, p2)
                
                ref_array = DB.ReferenceArray()
                for r in self.get_wall_end_references(wall): ref_array.Append(r)
                if self.options.get("openings"):
                    for r in self.get_insert_references(wall): ref_array.Append(r)
                if self.options.get("intersecting_grids"):
                    for r in self.get_intersecting_grid_references(wall): ref_array.Append(r)
                if self.options.get("intersecting_walls"):
                    for r in self.get_intersecting_wall_references(wall): ref_array.Append(r)
                    
                if ref_array.Size > 1:
                    try:
                        dim_type = self.options.get("dim_type")
                        if dim_type:
                            self.doc.Create.NewDimension(view, dim_line, ref_array, dim_type)
                        else:
                            self.doc.Create.NewDimension(view, dim_line, ref_array)
                        success_count += 1
                    except Exception as e:
                        pass
            t.Commit()
        return success_count
