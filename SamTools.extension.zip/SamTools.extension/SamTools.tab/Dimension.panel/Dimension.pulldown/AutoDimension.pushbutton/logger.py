# -*- coding: utf-8 -*-
"""
Logger module for SamTools Auto Dimension Suite
"""
from pyrevit import script

class AppLogger:
    def __init__(self):
        self._logger = script.get_logger()
        
    def info(self, msg):
        self._logger.info(msg)
        
    def error(self, msg):
        self._logger.error(msg)
        
log = AppLogger()
