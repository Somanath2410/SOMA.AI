# -*- coding: utf-8 -*-
"""
Configuration module for SamTools Auto Dimension Suite
"""
PLUGIN_NAME = "SamTools - Smart Auto Dimension"
DEFAULT_OFFSET_MM = 1000.0
SUPPORTED_VIEW_TYPES = ["FloorPlan", "EngineeringPlan", "CeilingPlan"]
