# -*- coding: utf-8 -*-
"""
SamTools - Smart Auto Dimension Suite
Enterprise BIM Automation
"""

import sys
import os
from pyrevit import revit, DB, UI, forms
from helper import AutoDimensionEngine

class AutoDimensionViewModel(forms.WPFWindow):
    def __init__(self, xaml_file_name, doc, uidoc):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.doc = doc
        self.uidoc = uidoc
        self.selected_walls = []
        
        # Bind events
        self.btnRun.Click += self.btnRun_Click
        self.btnCancel.Click += self.btnCancel_Click
        self.btnSelectWalls.Click += self.btnSelectWalls_Click
        self.sldOffset.ValueChanged += self.sldOffset_ValueChanged
        
        # Load Dimension Types
        dim_types = DB.FilteredElementCollector(self.doc).OfClass(DB.DimensionType).ToElements()
        self.linear_dim_types = [dt for dt in dim_types if dt.StyleType == DB.DimensionStyleType.Linear]
        
        for dt in self.linear_dim_types:
            try:
                name = dt.Name
            except:
                p = dt.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM)
                name = p.AsString() if p else "Unknown"
            self.cmbDimType.Items.Add(name)
            
        if self.cmbDimType.Items.Count > 0:
            self.cmbDimType.SelectedIndex = 0
            
        self.log_msg("System Initialized. Awaiting user input.")

    def log_msg(self, msg):
        current_text = self.txtLog.Text
        self.txtLog.Text = current_text + "\n> " + msg
        self.txtStatus.Text = msg

    def sldOffset_ValueChanged(self, sender, e):
        self.txtOffset.Text = str(int(self.sldOffset.Value))

    def btnSelectWalls_Click(self, sender, e):
        self.Hide()
        try:
            sel = self.uidoc.Selection.PickElementsByRectangle("Select walls to dimension")
            self.selected_walls = [el for el in sel if isinstance(el, DB.Wall)]
            self.log_msg("Selected {} walls.".format(len(self.selected_walls)))
        except Exception:
            self.log_msg("Wall selection cancelled.")
        self.ShowDialog()

    def get_options(self):
        try:
            offset_val = float(self.txtOffset.Text)
        except:
            offset_val = 1000.0
            
        return {
            "openings": self.chkOpenings.IsChecked,
            "doors": self.chkDoors.IsChecked,
            "windows": self.chkWindows.IsChecked,
            "intersecting_walls": self.chkIntersectingWalls.IsChecked,
            "intersecting_grids": self.chkIntersectingGrids.IsChecked,
            "offset_mm": offset_val,
            "dim_type": self.linear_dim_types[self.cmbDimType.SelectedIndex] if self.cmbDimType.SelectedIndex >= 0 else None,
            "chain_dimensions": self.chkChainDimensions.IsChecked,
            "overall_dimensions": self.chkOverallDimensions.IsChecked,
            "ignore_curtain": self.chkIgnoreCurtain.IsChecked,
            "smart_spacing": self.chkSmartSpacing.IsChecked
        }

    def btnRun_Click(self, sender, e):
        if not self.selected_walls:
            # Try to grab current selection
            sel = revit.get_selection()
            self.selected_walls = [el for el in sel.elements if isinstance(el, DB.Wall)]
            
        if not self.selected_walls:
            forms.alert("No walls selected! Please use 'Select Walls' button first.")
            return
            
        self.DialogResult = True
        self.Close()
        
    def btnCancel_Click(self, sender, e):
        self.DialogResult = False
        self.Close()

def main():
    doc = revit.doc
    uidoc = revit.uidoc
    
    xaml_path = os.path.join(os.path.dirname(__file__), 'ui.xaml')
    vm = AutoDimensionViewModel(xaml_path, doc, uidoc)
    result = vm.ShowDialog()
    
    if result:
        engine = AutoDimensionEngine(doc, uidoc, vm.get_options())
        success = engine.run(vm.selected_walls)
        forms.toast("Automation Complete", "Successfully dimensioned {} elements.".format(success), appid="SamTools")

if __name__ == '__main__':
    main()
