# -*- coding: utf-8 -*-
from pyrevit import DB

class AutoTagEngine:
    def __init__(self, doc, uidoc, options):
        self.doc = doc
        self.uidoc = uidoc
        self.options = options
        self.view = self.doc.ActiveView
        
    def get_elements_to_tag(self, category, selected_elements):
        if selected_elements:
            return [e for e in selected_elements if e.Category and e.Category.Id.IntegerValue == int(category)]
        return DB.FilteredElementCollector(self.doc, self.view.Id).OfCategory(category).WhereElementIsNotElementType().ToElements()

    def get_room_elements(self, selected_elements):
        if selected_elements:
            return [e for e in selected_elements if e.Category and e.Category.Id.IntegerValue == int(DB.BuiltInCategory.OST_Rooms)]
        return DB.FilteredElementCollector(self.doc, self.view.Id).OfCategory(DB.BuiltInCategory.OST_Rooms).ToElements()

    def is_already_tagged(self, element, tag_class):
        tags = DB.FilteredElementCollector(self.doc, self.view.Id).OfClass(tag_class).ToElements()
        for t in tags:
            try:
                # Revit 2022+ returns a list of TaggedLocalElementId or GetTaggedElementIds()
                # But for compatibility, let's just check standard TaggedLocalElementId
                if hasattr(t, "TaggedLocalElementId") and t.TaggedLocalElementId == element.Id: return True
                if hasattr(t, "GetTaggedLocalElementIds") and element.Id in t.GetTaggedLocalElementIds(): return True
            except:
                pass
            
            try:
                if t.TaggedElementId.Id == element.Id: return True
            except:
                pass
                
            if isinstance(t, DB.Architecture.RoomTag):
                try:
                    if t.Room.Id == element.Id: return True
                except:
                    pass
        return False

    def get_clash_free_point(self, pt):
        safety_radius = 1.5
        obstacle_pts = []
        tags = DB.FilteredElementCollector(self.doc, self.view.Id).OfClass(DB.IndependentTag).ToElements()
        for t in tags:
            try: obstacle_pts.append(t.TagHeadPosition)
            except: pass
                
        dims = DB.FilteredElementCollector(self.doc, self.view.Id).OfClass(DB.Dimension).ToElements()
        dim_lines = []
        for dim in dims:
            try:
                if dim.Curve and isinstance(dim.Curve, DB.Line): dim_lines.append(dim.Curve)
                if dim.Segments.Size > 0:
                    for seg in dim.Segments:
                        try:
                            if seg.TextPosition: obstacle_pts.append(seg.TextPosition)
                        except: pass
                else:
                    if dim.TextPosition: obstacle_pts.append(dim.TextPosition)
            except: pass
                
        offsets = [DB.XYZ(0,0,0)]
        step = 1.0
        for i in range(1, 4):
            offsets.append(DB.XYZ(step*i, step*i, 0))
            offsets.append(DB.XYZ(-step*i, step*i, 0))
            offsets.append(DB.XYZ(-step*i, -step*i, 0))
            offsets.append(DB.XYZ(step*i, -step*i, 0))
            offsets.append(DB.XYZ(step*i*1.5, 0, 0))
            offsets.append(DB.XYZ(-step*i*1.5, 0, 0))
            offsets.append(DB.XYZ(0, step*i*1.5, 0))
            offsets.append(DB.XYZ(0, -step*i*1.5, 0))
            
        for offset in offsets:
            test_pt = pt + offset
            clash = False
            for obs_pt in obstacle_pts:
                d = DB.XYZ(test_pt.X - obs_pt.X, test_pt.Y - obs_pt.Y, 0).GetLength()
                if d < safety_radius:
                    clash = True
                    break
            if clash: continue
            for line in dim_lines:
                res = line.Project(test_pt)
                if res and res.Distance < (safety_radius * 0.5):
                    clash = True
                    break
            if not clash: return test_pt
        return pt

    def place_tag(self, element, is_room=False, type_id=None):
        if self.options.get("ignore_tagged"):
            if is_room:
                if self.is_already_tagged(element, DB.SpatialElementTag): return False
            else:
                if self.is_already_tagged(element, DB.IndependentTag): return False

        # Find location
        loc = element.Location
        pt = None
        if isinstance(loc, DB.LocationPoint):
            pt = loc.Point
        elif isinstance(loc, DB.LocationCurve):
            pt = loc.Curve.Evaluate(0.5, True)
        elif is_room:
            if hasattr(element, "Location") and element.Location:
                pt = element.Location.Point
            
        if not pt:
            bb = element.get_BoundingBox(self.view)
            if bb:
                pt = (bb.Min + bb.Max) / 2.0
            else:
                return False
                
        if self.options.get("clash_safe"):
            pt = self.get_clash_free_point(pt)
                
        if is_room:
            uv_pt = DB.UV(pt.X, pt.Y)
            try:
                tag = self.doc.Create.NewRoomTag(DB.LinkElementId(element.Id), uv_pt, self.view.Id)
                if type_id and tag.GetTypeId() != type_id:
                    tag.ChangeTypeId(type_id)
                return True
            except Exception:
                return False
                
        try:
            mode = DB.TagMode.TM_ADDBY_CATEGORY
            orient = self.options.get("orientation", DB.TagOrientation.Horizontal)
            ref = DB.Reference(element)
            add_leader = self.options.get("leader", False)
            tag = DB.IndependentTag.Create(self.doc, self.view.Id, ref, add_leader, mode, orient, pt)
            if type_id and tag.GetTypeId() != type_id:
                tag.ChangeTypeId(type_id)
            return True
        except Exception:
            return False

    def run(self, selected_elements=None):
        success_count = 0
        
        # If no selected_elements provided via UI button, check active Revit selection
        if not selected_elements:
            sel_ids = self.uidoc.Selection.GetElementIds()
            if sel_ids:
                selected_elements = [self.doc.GetElement(id) for id in sel_ids]
                
        with DB.Transaction(self.doc, "SamTools: Enterprise Auto Tag") as t:
            t.Start()
            
            if self.options.get("walls"):
                type_id = self.options.get("wall_tag_id")
                for w in self.get_elements_to_tag(DB.BuiltInCategory.OST_Walls, selected_elements):
                    if self.place_tag(w, type_id=type_id): success_count += 1
                    
            if self.options.get("doors"):
                type_id = self.options.get("door_tag_id")
                for d in self.get_elements_to_tag(DB.BuiltInCategory.OST_Doors, selected_elements):
                    if self.place_tag(d, type_id=type_id): success_count += 1
                    
            if self.options.get("windows"):
                type_id = self.options.get("window_tag_id")
                for win in self.get_elements_to_tag(DB.BuiltInCategory.OST_Windows, selected_elements):
                    if self.place_tag(win, type_id=type_id): success_count += 1
                    
            if self.options.get("rooms"):
                type_id = self.options.get("room_tag_id")
                for r in self.get_room_elements(selected_elements):
                    if self.place_tag(r, is_room=True, type_id=type_id): success_count += 1
                    
            t.Commit()
            
        return success_count
