# -*- coding: utf-8 -*-
"""
SamTools - Smart Auto Tag Suite
"""
import sys
import os
from pyrevit import revit, DB, UI, forms
from helper import AutoTagEngine

class AutoTagViewModel(forms.WPFWindow):
    def __init__(self, xaml_file_name, doc, uidoc):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.doc = doc
        self.uidoc = uidoc
        self.selected_elements = []
        
        # Load Tag Families
        self.wall_tags = DB.FilteredElementCollector(self.doc).OfCategory(DB.BuiltInCategory.OST_WallTags).WhereElementIsElementType().ToElements()
        self.door_tags = DB.FilteredElementCollector(self.doc).OfCategory(DB.BuiltInCategory.OST_DoorTags).WhereElementIsElementType().ToElements()
        self.window_tags = DB.FilteredElementCollector(self.doc).OfCategory(DB.BuiltInCategory.OST_WindowTags).WhereElementIsElementType().ToElements()
        self.room_tags = DB.FilteredElementCollector(self.doc).OfCategory(DB.BuiltInCategory.OST_RoomTags).WhereElementIsElementType().ToElements()
        
        self.populate_combo(self.cmbWallTag, self.wall_tags)
        self.populate_combo(self.cmbDoorTag, self.door_tags)
        self.populate_combo(self.cmbWindowTag, self.window_tags)
        self.populate_combo(self.cmbRoomTag, self.room_tags)
        
        self.btnRun.Click += self.btnRun_Click
        self.btnCancel.Click += self.btnCancel_Click
        self.btnSelectElements.Click += self.btnSelectElements_Click
            
        self.log_msg("System Initialized. Awaiting user input.")

    def populate_combo(self, cmb, tags):
        cmb.Items.Add("<Default Category Tag>")
        for t in tags:
            try:
                name = t.FamilyName + " - " + t.Name
            except:
                p = t.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM)
                name = p.AsString() if p else "Unknown"
            cmb.Items.Add(name)
        cmb.SelectedIndex = 0

    def log_msg(self, msg):
        current_text = self.txtLog.Text
        self.txtLog.Text = current_text + "\n> " + msg
        self.txtStatus.Text = msg

    def btnSelectElements_Click(self, sender, e):
        self.Hide()
        try:
            sel = self.uidoc.Selection.PickElementsByRectangle("Select elements to tag")
            self.selected_elements = [el for el in sel]
            self.log_msg("Manually selected {} elements.".format(len(self.selected_elements)))
        except Exception:
            self.log_msg("Element selection cancelled.")
        self.ShowDialog()

    def get_options(self):
        orient = DB.TagOrientation.Horizontal
        sel = self.cmbOrientation.Text
        if sel == "Vertical":
            orient = DB.TagOrientation.Vertical
            
        return {
            "walls": self.chkWalls.IsChecked,
            "doors": self.chkDoors.IsChecked,
            "windows": self.chkWindows.IsChecked,
            "rooms": self.chkRooms.IsChecked,
            "leader": self.chkLeader.IsChecked,
            "orientation": orient,
            "ignore_tagged": self.chkIgnoreTagged.IsChecked,
            "clash_safe": self.chkClashSafe.IsChecked,
            "wall_tag_id": self.wall_tags[self.cmbWallTag.SelectedIndex - 1].Id if self.cmbWallTag.SelectedIndex > 0 else None,
            "door_tag_id": self.door_tags[self.cmbDoorTag.SelectedIndex - 1].Id if self.cmbDoorTag.SelectedIndex > 0 else None,
            "window_tag_id": self.window_tags[self.cmbWindowTag.SelectedIndex - 1].Id if self.cmbWindowTag.SelectedIndex > 0 else None,
            "room_tag_id": self.room_tags[self.cmbRoomTag.SelectedIndex - 1].Id if self.cmbRoomTag.SelectedIndex > 0 else None
        }

    def btnRun_Click(self, sender, e):
        self.DialogResult = True
        self.Close()
        
    def btnCancel_Click(self, sender, e):
        self.DialogResult = False
        self.Close()

def main():
    doc = revit.doc
    uidoc = revit.uidoc
    
    xaml_path = os.path.join(os.path.dirname(__file__), 'ui.xaml')
    vm = AutoTagViewModel(xaml_path, doc, uidoc)
    result = vm.ShowDialog()
    
    if result:
        engine = AutoTagEngine(doc, uidoc, vm.get_options())
        success = engine.run(vm.selected_elements)
        forms.toast("Auto Tag Complete", "Successfully placed {} tags.".format(success), appid="SamTools")

if __name__ == '__main__':
    main()
