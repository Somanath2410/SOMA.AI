# -*- coding: utf-8 -*-
"""Delete all Imported and Linked CAD files"""

__title__ = 'CAD Cleaner'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms

doc = revit.doc

def main():
    cad_instances = DB.FilteredElementCollector(doc).OfClass(DB.ImportInstance).ToElements()
    
    if not cad_instances:
        forms.alert("No CAD instances found in project.", title="Clean")
        return
        
    if forms.alert("Are you sure you want to delete {} CAD files?".format(len(cad_instances)), yes=True, no=True):
        with revit.Transaction("SamTools - Clean CAD"):
            for cad in cad_instances:
                doc.Delete(cad.Id)
        forms.alert("Successfully deleted all CAD instances.", title="Success")

if __name__ == '__main__':
    main()
