# -*- coding: utf-8 -*-
"""Check Status of Linked Revit Models"""

__title__ = 'Linked Model\nChecker'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script

doc = revit.doc
output = script.get_output()

def main():
    links = DB.FilteredElementCollector(doc).OfClass(DB.RevitLinkInstance).ToElements()
    
    output.print_md("# Linked Revit Models")
    
    if not links:
        print("No Revit links found in this project.")
        return
        
    for link in links:
        try:
            link_type = doc.GetElement(link.GetTypeId())
            name = link.Name
            status = link_type.get_Parameter(DB.BuiltInParameter.RELOAD_LATEST_STATE).AsValueString()
            path = link_type.get_Parameter(DB.BuiltInParameter.MODELPATH_PARAM).AsString()
            
            print("---")
            print("Name: {}".format(name))
            print("Status: {}".format(status or "Loaded"))
            print("Path: {}".format(path))
        except: pass

if __name__ == '__main__':
    main()
