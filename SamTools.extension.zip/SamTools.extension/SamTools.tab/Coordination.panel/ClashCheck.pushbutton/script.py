# -*- coding: utf-8 -*-
"""Basic BoundingBox Clash Check between Categories"""

__title__ = 'Clash Check'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script

doc = revit.doc
output = script.get_output()

class ClashCheckWindow(forms.WPFWindow):
    def __init__(self, xaml_file):
        forms.WPFWindow.__init__(self, xaml_file)
        self.cats = ["Walls", "Structural Columns", "Structural Framing", "Ducts", "Pipes"]
        self.comboCat1.ItemsSource = self.cats
        self.comboCat2.ItemsSource = self.cats
        self.comboCat1.SelectedIndex = 0
        self.comboCat2.SelectedIndex = 1
        
        self.btnCancel.Click += self.cancel
        self.btnRun.Click += self.run_clash
        self.success = False

    def cancel(self, sender, args):
        self.Close()
        
    def run_clash(self, sender, args):
        self.sel_cat1 = self.comboCat1.SelectedItem
        self.sel_cat2 = self.comboCat2.SelectedItem
        self.success = True
        self.Close()

def main():
    xaml_file = script.get_bundle_file('ui.xaml')
    win = ClashCheckWindow(xaml_file)
    win.show_dialog()
    
    if not win.success: return
    cat1_name = win.sel_cat1
    cat2_name = win.sel_cat2
    
    bic_map = {
        "Walls": DB.BuiltInCategory.OST_Walls,
        "Structural Columns": DB.BuiltInCategory.OST_StructuralColumns,
        "Structural Framing": DB.BuiltInCategory.OST_StructuralFraming,
        "Ducts": DB.BuiltInCategory.OST_DuctCurves,
        "Pipes": DB.BuiltInCategory.OST_PipeCurves
    }
    
    elems1 = DB.FilteredElementCollector(doc).OfCategory(bic_map[cat1_name]).WhereElementIsNotElementType().ToElements()
    elems2 = DB.FilteredElementCollector(doc).OfCategory(bic_map[cat2_name]).WhereElementIsNotElementType().ToElements()
    
    output.print_md("# Clash Report: {} vs {}".format(cat1_name, cat2_name))
    
    clash_count = 0
    for e1 in elems1:
        bb1 = e1.get_BoundingBox(None)
        if not bb1: continue
        outline1 = DB.Outline(bb1.Min, bb1.Max)
        
        # Fast filter for potential clashes
        filter = DB.ElementIntersectsOutlineFilter(outline1)
        clashes = DB.FilteredElementCollector(doc, [e2.Id for e2 in elems2]).WherePasses(filter).ToElementIds()
        
        for cid in clashes:
            if cid == e1.Id: continue
            print("Clash Found: {} (ID: {}) with {} (ID: {})".format(e1.Name, e1.Id, doc.GetElement(cid).Name, cid))
            clash_count += 1
            
    if clash_count == 0:
        print("No clashes detected.")
    else:
        output.print_md("### Total Clashes: **{}**".format(clash_count))

if __name__ == '__main__':
    main()
