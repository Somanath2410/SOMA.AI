# -*- coding: utf-8 -*-
"""
SOMA AI - Multi-Provider LLM Client
Supports OpenAI (gpt-4o), Anthropic (claude-3-7-sonnet), Google Gemini (gemini-2.5-pro),
and Ollama / Local Open-AI compatible endpoints for offline enterprise BIM privacy.
"""

import os
import json

try:
    # pyrefly: ignore [missing-import]
    import System
    # pyrefly: ignore [missing-import]
    from System.Net import HttpWebRequest, WebRequest, WebException
    # pyrefly: ignore [missing-import]
    from System.IO import StreamReader, StreamWriter
    # pyrefly: ignore [missing-import]
    from System.Text import Encoding
    HAS_DOTNET = True
except ImportError:
    HAS_DOTNET = False

CONFIG_FILE = os.path.join(os.path.dirname(__file__), "soma_ai_config.json")
OLD_KEY_FILE = os.path.join(os.path.dirname(__file__), "openai_api_key.txt")

DEFAULT_CONFIG = {
    "provider": "OpenAI",
    "model": "gpt-4o",
    "api_key": "",
    "endpoint_url": "https://api.openai.com/v1/chat/completions",
    "temperature": 0.7,
    "max_tokens": 1500
}



def load_config():
    """Load SOMA AI configuration from JSON file or migrate old key file."""
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r') as f:
                cfg = json.load(f)
                merged = DEFAULT_CONFIG.copy()
                merged.update(cfg)
                return merged
        except Exception:
            pass

    # Migrate old key file if exists
    config = DEFAULT_CONFIG.copy()
    if os.path.exists(OLD_KEY_FILE):
        try:
            with open(OLD_KEY_FILE, 'r') as f:
                config["api_key"] = f.read().strip()
        except Exception:
            pass
    return config


def save_config(config_dict):
    """Save SOMA AI configuration to JSON file."""
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config_dict, f, indent=2)


def get_api_key():
    """Get active API key from config."""
    cfg = load_config()
    return cfg.get("api_key", "")


def set_api_key(key):
    """Update API key in config."""
    cfg = load_config()
    cfg["api_key"] = key.strip()
    save_config(cfg)


def get_supported_providers():
    return ["OpenAI", "Anthropic", "Google Gemini", "Ollama / Local LLM"]


def get_supported_models():
    return {
        "OpenAI": ["gpt-4o", "gpt-4o-mini", "o3-mini"],
        "Anthropic": ["claude-3-7-sonnet", "claude-3-5-sonnet"],
        "Google Gemini": ["gemini-2.5-pro", "gemini-2.5-flash"],
        "Ollama / Local LLM": ["llama3.2", "deepseek-r1", "mistral", "qwen2.5-coder"]
    }


def ask_llm(user_message, system_prompt=None):
    """
    Query the configured AI model across OpenAI, Anthropic, Gemini, or Ollama/Local endpoints.
    """
    config = load_config()
    provider = config.get("provider", "OpenAI")
    model = config.get("model", "gpt-4o")
    api_key = config.get("api_key", "").strip()
    endpoint_url = config.get("endpoint_url", "").strip()
    temperature = config.get("temperature", 0.7)

    if not system_prompt:
        system_prompt = (
            "You are SOMA AI, an advanced BIM automation orchestrator inside Revit. "
            "Provide helpful, concise answers and BIM recommendations."
        )

    if provider != "Ollama / Local LLM" and not api_key:
        return (
            "API Key Missing! Click the Settings gear icon in the top right "
            "to configure your {} API Key.".format(provider)
        )

    # Determine endpoint and request format
    if provider == "OpenAI":
        url = endpoint_url or "https://api.openai.com/v1/chat/completions"
        headers = {"Authorization": "Bearer " + api_key}
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message}
            ],
            "temperature": temperature
        }
    elif provider == "Ollama / Local LLM":
        url = endpoint_url or "http://localhost:11434/v1/chat/completions"
        headers = {}
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message}
            ],
            "temperature": temperature
        }
    elif provider == "Anthropic":
        url = endpoint_url or "https://api.anthropic.com/v1/messages"
        headers = {
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01"
        }
        payload = {
            "model": model,
            "system": system_prompt,
            "messages": [
                {"role": "user", "content": user_message}
            ],
            "max_tokens": 1500,
            "temperature": temperature
        }
    elif provider == "Google Gemini":
        url = "https://generativelanguage.googleapis.com/v1beta/models/{}:generateContent?key={}".format(model, api_key)
        headers = {}
        payload = {
            "contents": [
                {
                    "role": "user",
                    "parts": [{"text": system_prompt + "\n\nUser Question:\n" + user_message}]
                }
            ]
        }
    else:
        url = "https://api.openai.com/v1/chat/completions"
        headers = {"Authorization": "Bearer " + api_key}
        payload = {
            "model": "gpt-4o",
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message}
            ]
        }

    try:
        json_payload = json.dumps(payload)

        if HAS_DOTNET:
            request = WebRequest.Create(url)
            request.Method = "POST"
            request.ContentType = "application/json"
            
            for k, v in headers.items():
                request.Headers.Add(k, v)

            bytes_data = Encoding.UTF8.GetBytes(json_payload)
            request.ContentLength = bytes_data.Length

            req_stream = request.GetRequestStream()
            req_stream.Write(bytes_data, 0, bytes_data.Length)
            req_stream.Close()

            response = request.GetResponse()
            res_stream = response.GetResponseStream()
            reader = StreamReader(res_stream)
            response_text = reader.ReadToEnd()
            reader.Close()
            res_stream.Close()
            response.Close()
        else:
            try:
                import urllib.request as urllib_req
            except ImportError:
                import urllib2 as urllib_req

            req = urllib_req.Request(url, data=json_payload.encode('utf-8'))
            req.add_header('Content-Type', 'application/json')
            for k, v in headers.items():
                req.add_header(k, v)
            resp = urllib_req.urlopen(req)
            response_text = resp.read().decode('utf-8')

        response_data = json.loads(response_text)


        # Parse Provider Specific Response
        if provider == "Anthropic":
            if "content" in response_data and len(response_data["content"]) > 0:
                return response_data["content"][0]["text"].strip()
        elif provider == "Google Gemini":
            if "candidates" in response_data and len(response_data["candidates"]) > 0:
                parts = response_data["candidates"][0]["content"]["parts"]
                return parts[0]["text"].strip()
        else: # OpenAI & Ollama
            if "choices" in response_data and len(response_data["choices"]) > 0:
                return response_data["choices"][0]["message"]["content"].strip()

        return "Response received from {} but no valid text choices returned.".format(provider)

    except WebException as e:
        if e.Response:
            try:
                reader = StreamReader(e.Response.GetResponseStream())
                error_text = reader.ReadToEnd()
                try:
                    error_json = json.loads(error_text)
                    msg = error_json.get("error", {}).get("message", error_text)
                    return "AI API Error ({}): {}".format(provider, msg)
                except Exception:
                    return "AI API Error ({}): {}".format(provider, error_text)
            except Exception:
                pass
        return "Connection Error to {}: {}".format(provider, str(e))
    except Exception as e:
        return "SOMA AI Error: " + str(e)

