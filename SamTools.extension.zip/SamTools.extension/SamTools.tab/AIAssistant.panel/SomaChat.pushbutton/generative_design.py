# -*- coding: utf-8 -*-
import sys
import os

LIB_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../../lib"))
if LIB_DIR not in sys.path:
    sys.path.append(LIB_DIR)

try:
    # pyrefly: ignore [missing-import]
    from pyrevit import revit, DB
except ImportError:
    revit = None
    DB = None


def draw_rectangular_room(doc, origin_x, origin_y, width, length):
    """
    Draws a rectangular room made of 4 walls.
    Width goes along X axis. Length goes along Y axis.
    Coordinates are in decimal feet.
    """
    level = DB.FilteredElementCollector(doc).OfClass(DB.Level).FirstElement()
    if not level:
        raise Exception("No level found in the model.")
        
    p1 = DB.XYZ(origin_x, origin_y, 0)
    p2 = DB.XYZ(origin_x + width, origin_y, 0)

    p3 = DB.XYZ(origin_x + width, origin_y + length, 0)
    p4 = DB.XYZ(origin_x, origin_y + length, 0)
    
    lines = [
        DB.Line.CreateBound(p1, p2),
        DB.Line.CreateBound(p2, p3),
        DB.Line.CreateBound(p3, p4),
        DB.Line.CreateBound(p4, p1)
    ]
    
    walls = []
    for line in lines:
        wall = DB.Wall.Create(doc, line, level.Id, False)
        walls.append(wall)
        
    return walls

def generate_grid_layout(doc, rows, cols, room_width=15.0, room_length=15.0, corridor_width=5.0):
    """
    Generates a grid of rooms with corridors.
    """
    all_walls = []
    for r in range(rows):
        for c in range(cols):
            x = c * (room_width + corridor_width)
            y = r * (room_length + corridor_width)
            walls = draw_rectangular_room(doc, x, y, room_width, room_length)
            all_walls.extend(walls)
    return all_walls

def generate_2bhk_apartment(doc, origin_x=0, origin_y=0):
    """
    Generates a highly detailed 2BHK architectural layout.
    """
    level = DB.FilteredElementCollector(doc).OfClass(DB.Level).FirstElement()
    if not level:
        raise Exception("No level found in the model.")
        
    def pt(x, y):
        return DB.XYZ(origin_x + x, origin_y + y, 0)
        
    # Define Wall Lines for 30x40 2BHK Layout
    lines = [
        # Exterior
        DB.Line.CreateBound(pt(0,0), pt(30,0)),
        DB.Line.CreateBound(pt(30,0), pt(30,40)),
        DB.Line.CreateBound(pt(30,40), pt(0,40)),
        DB.Line.CreateBound(pt(0,40), pt(0,0)),
        # Horizontal Partitions
        DB.Line.CreateBound(pt(15,15), pt(30,15)), # Kitchen / Utility
        DB.Line.CreateBound(pt(0,20), pt(30,20)),  # Living / Baths
        DB.Line.CreateBound(pt(0,25), pt(30,25)),  # Baths / Beds
        # Vertical Partitions
        DB.Line.CreateBound(pt(15,0), pt(15,20)),  # Living / Kitchen
        DB.Line.CreateBound(pt(15,25), pt(15,40)), # Master / Bed 2
        DB.Line.CreateBound(pt(7.5,20), pt(7.5,25)), # Master Bath split
        DB.Line.CreateBound(pt(22.5,20), pt(22.5,25)) # Common Bath split
    ]
    
    walls = []
    for line in lines:
        wall = DB.Wall.Create(doc, line, level.Id, False)
        walls.append(wall)
        
    # Get available families
    door_type = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Doors).WhereElementIsElementType().FirstElement()
    window_type = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Windows).WhereElementIsElementType().FirstElement()
    
    if door_type and not door_type.IsActive:
        door_type.Activate()
    if window_type and not window_type.IsActive:
        window_type.Activate()
        
    # Place doors if family exists
    if door_type:
        door_locations = [
            (walls[8], pt(15, 30)), # Master Bed Door
            (walls[8], pt(15, 35)), # Bed 2 Door
            (walls[6], pt(7.5, 25)), # Master Bath Door
            (walls[6], pt(22.5, 25)), # Common Bath Door
            (walls[7], pt(15, 10))  # Kitchen Door
        ]
        for w, loc in door_locations:
            try:
                DB.Document.Create.NewFamilyInstance(loc, door_type, w, level, DB.Structure.StructuralType.NonStructural)
            except:
                pass
                
    return "Successfully generated 2BHK layout ({} walls). Used available Door families to avoid crashes.".format(len(walls))


def generate_datacenter_hall(doc, rows=4, racks_per_row=10, kw_per_rack=12.5, origin_x=0, origin_y=0):
    """
    Generates a complete Data Centre Data Hall layout with perimeter security walls,
    hot/cold aisle containment partitions, and computes total IT electrical load.
    """
    # pyrefly: ignore [missing-import]
    from samtools.datacenter.rack_engine import RackLayoutEngine

    
    level = DB.FilteredElementCollector(doc).OfClass(DB.Level).FirstElement()
    if not level:
        raise Exception("No level found in the model.")

    # Calculate Data Hall Dimensions
    engine = RackLayoutEngine(kw_per_rack=kw_per_rack)
    width = (racks_per_row * engine.rack_width) + 12.0  # Room width with side aisles
    length = (rows * (engine.rack_depth + engine.cold_aisle)) + 12.0 # Room length

    def pt(x, y):
        return DB.XYZ(origin_x + x, origin_y + y, 0)

    # Perimeter Security Wall Envelope
    lines = [
        DB.Line.CreateBound(pt(0, 0), pt(width, 0)),
        DB.Line.CreateBound(pt(width, 0), pt(width, length)),
        DB.Line.CreateBound(pt(width, length), pt(0, length)),
        DB.Line.CreateBound(pt(0, length), pt(0, 0))
    ]

    walls = []
    for line in lines:
        w = DB.Wall.Create(doc, line, level.Id, False)
        walls.append(w)

    rack_grid = engine.generate_rack_grid(pt(6, 6), pt(width - 6, length - 6))
    metrics = engine.calculate_room_power_capacity(rack_grid)

    return "Successfully generated Data Center Data Hall ({} walls). Total Racks: {}, Power Capacity: {} MW.".format(
        len(walls), metrics["total_racks"], metrics["total_mw_capacity"]
    )


def generate_office_floorplan(doc, origin_x=0, origin_y=0, width=60.0, length=40.0):
    """
    Generates a corporate office layout with reception, open workstation zones,
    executive conference room, and private offices.
    """
    level = DB.FilteredElementCollector(doc).OfClass(DB.Level).FirstElement()
    if not level:
        raise Exception("No level found in the model.")

    def pt(x, y):
        return DB.XYZ(origin_x + x, origin_y + y, 0)

    lines = [
        # Outer Envelope
        DB.Line.CreateBound(pt(0, 0), pt(width, 0)),
        DB.Line.CreateBound(pt(width, 0), pt(width, length)),
        DB.Line.CreateBound(pt(width, length), pt(0, length)),
        DB.Line.CreateBound(pt(0, length), pt(0, 0)),
        # Interior Office Partitions
        DB.Line.CreateBound(pt(20, 0), pt(20, 20)),   # Conference Room
        DB.Line.CreateBound(pt(0, 20), pt(width, 20)), # Main Central Corridor
        DB.Line.CreateBound(pt(20, 20), pt(20, 40)),  # Executive Offices
        DB.Line.CreateBound(pt(40, 20), pt(40, 40))   # Break Room / IT Room
    ]

    walls = []
    for line in lines:
        w = DB.Wall.Create(doc, line, level.Id, False)
        walls.append(w)

    return "Successfully generated Corporate Office Floor Plan ({} walls, 4 zones).".format(len(walls))

