# -*- coding: utf-8 -*-
"""
SamTools AI & Automation Action Execution Module
Contains tool execution logic and centralized ToolRegistry for SomaChat and MCP integration.
"""

# pyrefly: ignore [missing-import]
import clr
# pyrefly: ignore [missing-import]
import System
# pyrefly: ignore [missing-import]
from System.Collections.Generic import List

try:
    # pyrefly: ignore [missing-import]
    from pyrevit import revit, DB, forms
except ImportError:
    revit = None
    DB = None
    forms = None

# pyrefly: ignore [missing-import]
from samtools.core.base_mvc import DocumentContext, TransactionManager


class ToolRegistry(object):
    """Centralized Tool Execution Registry for AI Assistant and MCP protocol integration."""

    _tools = {}

    @classmethod
    def register(cls, name, description, parameters=None):
        """Decorator to register a tool function."""
        def decorator(func):
            cls._tools[name] = {
                "name": name,
                "description": description,
                "parameters": parameters or {},
                "handler": func
            }
            return func
        return decorator

    @classmethod
    def get_tool(cls, name):
        return cls._tools.get(name)

    @classmethod
    def list_tools(cls):
        """Return list of all registered tool metadata schemas."""
        schemas = []
        for name, info in cls._tools.items():
            schemas.append({
                "name": info["name"],
                "description": info["description"],
                "parameters": info["parameters"]
            })
        return schemas

    @classmethod
    def execute(cls, name, doc, **kwargs):
        """
        Safely execute a registered tool by name with parameter validation.
        :param name: Registered tool name string
        :param doc: Active Revit Document
        :param kwargs: Keyword parameters for the tool
        :return: Dict result {"success": bool, "message": str, "data": obj}
        """
        tool = cls.get_tool(name)
        if not tool:
            return {"success": False, "message": "Unknown tool name: '{}'".format(name), "data": None}

        ctx = DocumentContext(doc)
        if not ctx.is_valid:
            return {"success": False, "message": "Invalid or missing active Revit document.", "data": None}

        try:
            handler = tool["handler"]
            result = handler(doc, **kwargs)
            if isinstance(result, dict) and "success" in result:
                return result
            return {"success": True, "message": str(result), "data": result}
        except Exception as e:
            return {"success": False, "message": "Tool '{}' failed: {}".format(name, str(e)), "data": None}


# ==============================================================================
# REGISTERED REVIET AUTOMATION TOOLS
# ==============================================================================

@ToolRegistry.register(
    name="create_door_schedule",
    description="Creates a new Door Schedule in the active model with standard parameter fields.",
    parameters={"type": "object", "properties": {}}
)
def create_door_schedule(doc, **kwargs):
    ctx = DocumentContext(doc)
    try:
        with ctx.transaction("AI Create Door Schedule"):
            schedule = DB.ViewSchedule.CreateSchedule(doc, DB.ElementId(DB.BuiltInCategory.OST_Doors))
            schedule.Name = "AI Generated Door Schedule"
            
            fields = schedule.Definition.GetSchedulableFields()
            added_fields = []
            target_fields = ["Mark", "Width", "Height", "Family and Type", "Comments"]
            for field in fields:
                if field.GetName(doc) in target_fields:
                    schedule.Definition.AddField(field)
                    added_fields.append(field.GetName(doc))
                    
            return "Successfully created 'AI Generated Door Schedule' with {} fields.".format(len(added_fields))
    except Exception as e:
        return "Failed to create schedule: {}".format(str(e))


@ToolRegistry.register(
    name="find_duplicate_elements",
    description="Audits the model for duplicate overlapping elements based on Revit warnings.",
    parameters={"type": "object", "properties": {}}
)
def find_duplicate_elements(doc, **kwargs):
    warnings = doc.GetWarnings()
    duplicate_count = 0
    duplicate_ids = set()
    
    for warning in warnings:
        desc = warning.GetDescriptionText()
        if "identical instances in the same place" in desc.lower():
            duplicate_count += 1
            for element_id in warning.GetFailingElements():
                duplicate_ids.add(element_id)
                
    if duplicate_count > 0:
        return "Found {} duplicate warnings affecting {} elements. Please review Warnings.".format(duplicate_count, len(duplicate_ids))
    else:
        return "No duplicate elements found based on Revit warnings. Model looks clean!"


@ToolRegistry.register(
    name="audit_cad_imports",
    description="Identifies all DWG/CAD import instances in the model and their owner views.",
    parameters={"type": "object", "properties": {}}
)
def audit_cad_imports(doc, **kwargs):
    cad_imports = DB.FilteredElementCollector(doc).OfClass(DB.ImportInstance).ToElements()
    count = len(cad_imports)
    if count == 0:
        return "No CAD imports found in the model."
    
    views_with_cad = set()
    for cad in cad_imports:
        if cad.OwnerViewId != DB.ElementId.InvalidElementId:
            view = doc.GetElement(cad.OwnerViewId)
            if view:
                views_with_cad.add(view.Name)
                
    report = "Found {} CAD Imports. ".format(count)
    if views_with_cad:
        report += "They appear in views like: " + ", ".join(list(views_with_cad)[:3])
    return report


@ToolRegistry.register(
    name="generate_sheets",
    description="Batch creates 3 new ISO drawing sheets using the first available titleblock family.",
    parameters={"type": "object", "properties": {}}
)
def generate_sheets(doc, **kwargs):
    ctx = DocumentContext(doc)
    try:
        titleblocks = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_TitleBlocks).WhereElementIsElementType().ToElements()
        if not titleblocks:
            return "No Titleblocks loaded in the model. Please load a Titleblock family first."
        
        tb_id = titleblocks[0].Id
        created_sheets = []
        with ctx.transaction("Generate AI Sheets"):
            for i in range(1, 4):
                sheet = DB.ViewSheet.Create(doc, tb_id)
                sheet.Name = "AI Generated Sheet " + str(i)
                try:
                    sheet.SheetNumber = "A-AI-10" + str(i)
                except:
                    pass
                created_sheets.append(sheet.SheetNumber)
                
        return "Successfully generated {} new sheets using titleblock '{}'.".format(len(created_sheets), titleblocks[0].Name)
    except Exception as e:
        return "Failed to generate sheets: {}".format(str(e))


@ToolRegistry.register(
    name="explain_warning",
    description="Analyzes the first active Revit model warning and provides corrective AI guidance.",
    parameters={"type": "object", "properties": {}}
)
def explain_warning(doc, **kwargs):
    warnings = doc.GetWarnings()
    if not warnings:
        return "The model has zero warnings! Great job!"
    
    first_warning = warnings[0].GetDescriptionText()
    explanation = "Warning: '{}'. ".format(first_warning)
    if "overlap" in first_warning.lower():
        explanation += "\nAI Suggestion: You have elements occupying the exact same space. Try using the 'Find Duplicate Elements' tool."
    elif "room" in first_warning.lower() and "enclosed" in first_warning.lower():
        explanation += "\nAI Suggestion: A room boundary is not fully closed. Check walls or room separation lines."
    else:
        explanation += "\nAI Suggestion: Review involved elements by their IDs in the Revit Warnings dialog."
        
    return explanation


@ToolRegistry.register(
    name="suggest_naming_standards",
    description="Returns ISO 19650 compliant BIM naming guidelines and examples.",
    parameters={"type": "object", "properties": {}}
)
def suggest_naming_standards(doc, **kwargs):
    return (
        "BIM Naming Standards Suggestion (ISO 19650 style):\n"
        "1. Project Code (e.g., PRJ123)\n"
        "2. Originator (e.g., ARC)\n"
        "3. Volume/System (e.g., Z1)\n"
        "4. Level/Location (e.g., L01)\n"
        "5. Type (e.g., M3 for 3D Model)\n"
        "6. Role (e.g., A for Architect)\n"
        "7. Number (e.g., 0001)\n"
        "Example: PRJ123-ARC-Z1-L01-M3-A-0001"
    )


@ToolRegistry.register(
    name="ai_clash_resolution",
    description="Performs spatial bounding-box clash detection between Ducts and Structural Framing.",
    parameters={"type": "object", "properties": {}}
)
def ai_clash_resolution(doc, **kwargs):
    ducts = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_DuctCurves).WhereElementIsNotElementType().ToElements()
    beams = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_StructuralFraming).WhereElementIsNotElementType().ToElements()
    
    if not ducts or not beams:
        return "AI Clash Check requires both Ducts and Structural Framing elements in the model."
        
    clashes = 0
    for duct in ducts:
        bbox_d = duct.get_BoundingBox(None)
        if not bbox_d: continue
        for beam in beams:
            bbox_b = beam.get_BoundingBox(None)
            if not bbox_b: continue
            
            if (bbox_d.Max.X >= bbox_b.Min.X and bbox_d.Min.X <= bbox_b.Max.X and
                bbox_d.Max.Y >= bbox_b.Min.Y and bbox_d.Min.Y <= bbox_b.Max.Y and
                bbox_d.Max.Z >= bbox_b.Min.Z and bbox_d.Min.Z <= bbox_b.Max.Z):
                clashes += 1
                
    return "AI Clash Analysis Complete: Found {} potential clashes between Ducts and Structural Framing.".format(clashes)


@ToolRegistry.register(
    name="natural_language_modeling",
    description="Parses basic natural language instructions (e.g. 'create a wall') and creates model elements.",
    parameters={"type": "object", "properties": {"prompt": {"type": "string"}}}
)
def natural_language_modeling(doc, prompt="", **kwargs):
    text = str(prompt).lower()
    ctx = DocumentContext(doc)
    if "wall" in text:
        try:
            with ctx.transaction("AI Create Wall"):
                level = DB.FilteredElementCollector(doc).OfClass(DB.Level).FirstElement()
                if not level:
                    return "No levels found to place the wall."
                
                line = DB.Line.CreateBound(DB.XYZ(0,0,0), DB.XYZ(10,0,0))
                wall = DB.Wall.Create(doc, line, level.Id, False)
            return "Parsed instruction and created a 10ft wall at model origin."
        except Exception as e:
            return "Failed to create wall: {}".format(str(e))
    elif "room" in text:
        return "Natural language room generation requires closed boundaries. Try creating walls first!"
    else:
        return "Understood prompt: '{}'. Currently supported commands: 'create a wall'.".format(text)


@ToolRegistry.register(
    name="auto_sheet_layout",
    description="Automatically finds unplaced floor plan views and centers them on an open drawing sheet.",
    parameters={"type": "object", "properties": {}}
)
def auto_sheet_layout(doc, **kwargs):
    ctx = DocumentContext(doc)
    try:
        views = DB.FilteredElementCollector(doc).OfClass(DB.View).ToElements()
        floor_plan = None
        for v in views:
            if v.ViewType == DB.ViewType.FloorPlan and not v.IsTemplate:
                if DB.Viewport.CanAddViewToSheet(doc, DB.ElementId.InvalidElementId, v.Id):
                    floor_plan = v
                    break
        
        if not floor_plan:
            return "Could not find any available floor plan views that are not already on a sheet."
            
        sheets = DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet).ToElements()
        if not sheets:
            return "No sheets found. Please run 'generate_sheets' first."
            
        target_sheet = sheets[0]
        
        with ctx.transaction("AI Auto Layout"):
            center = DB.XYZ(1.5, 1.0, 0)
            viewport = DB.Viewport.Create(doc, target_sheet.Id, floor_plan.Id, center)
            
        return "Auto Layout complete! Placed view '{}' onto sheet '{}'.".format(floor_plan.Name, target_sheet.SheetNumber)
    except Exception as e:
        return "Auto Sheet Layout failed: {}".format(str(e))


@ToolRegistry.register(
    name="ai_parameter_audit",
    description="Audits Door instance parameters for missing Mark or Comment values.",
    parameters={"type": "object", "properties": {}}
)
def ai_parameter_audit(doc, **kwargs):
    doors = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Doors).WhereElementIsNotElementType().ToElements()
    if not doors:
        return "No doors found to audit."
        
    missing_mark = 0
    missing_comments = 0
    
    for door in doors:
        mark_param = door.get_Parameter(DB.BuiltInParameter.ALL_MODEL_MARK)
        comments_param = door.get_Parameter(DB.BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)
        
        if mark_param and not mark_param.AsString():
            missing_mark += 1
        if comments_param and not comments_param.AsString():
            missing_comments += 1
            
    return "AI Audit complete on {} doors:\n- {} missing 'Mark'\n- {} missing 'Comments'".format(len(doors), missing_mark, missing_comments)


@ToolRegistry.register(
    name="generate_plans",
    description="Scans project levels and creates missing Floor Plan views for unrepresented levels.",
    parameters={"type": "object", "properties": {}}
)
def generate_plans(doc, **kwargs):
    ctx = DocumentContext(doc)
    levels = DB.FilteredElementCollector(doc).OfClass(DB.Level).WhereElementIsNotElementType().ToElements()
    if not levels:
        return "No levels found in the model to generate plans for."
    
    view_family_types = DB.FilteredElementCollector(doc).OfClass(DB.ViewFamilyType).ToElements()
    fp_type_id = None
    for vft in view_family_types:
        if vft.ViewFamily == DB.ViewFamily.FloorPlan:
            fp_type_id = vft.Id
            break
            
    if not fp_type_id:
        return "Could not find a Floor Plan ViewFamilyType in the model."

    created_count = 0
    try:
        with ctx.transaction("Auto Generate Floor Plans"):
            for level in levels:
                existing_plans = DB.FilteredElementCollector(doc).OfClass(DB.ViewPlan).WhereElementIsNotElementType().ToElements()
                exists = False
                for ep in existing_plans:
                    if ep.GenLevel and ep.GenLevel.Id == level.Id and ep.ViewType == DB.ViewType.FloorPlan:
                        exists = True
                        break
                
                if not exists:
                    new_view = DB.ViewPlan.Create(doc, fp_type_id, level.Id)
                    new_view.Name = "Auto Plan - " + level.Name
                    created_count += 1
        if created_count == 0:
            return "Plan Generator: All levels already have Floor Plans."
        return "Plan Generator completed. Successfully generated {} missing Floor Plans.".format(created_count)
    except Exception as e:
        return "Failed to generate plans: " + str(e)


@ToolRegistry.register(
    name="run_qaqc_audit",
    description="Executes a full 10-point BIM QA/QC compliance audit and generates report metrics.",
    parameters={
        "type": "object",
        "properties": {
            "report_path": {"type": "string", "description": "Optional output HTML/JSON file path"}
        }
    }
)
def run_qaqc_audit(doc, report_path=None, **kwargs):
    # pyrefly: ignore [missing-import]
    from samtools.qaqc.audit_engine import QAQCAuditEngine
    engine = QAQCAuditEngine(doc)
    results = engine.run_full_audit()
    if report_path:
        if report_path.endswith(".html"):
            engine.export_audit_report_html(report_path, results)
        else:
            engine.export_audit_report_json(report_path, results)
    return "QA/QC Audit completed with status: {}. Total checks executed: {}.".format(results.get("status"), len(results.get("checks", [])))


@ToolRegistry.register(
    name="export_ifc_model",
    description="Exports 3D model view to IFC format with custom schema and quantity settings.",
    parameters={
        "type": "object",
        "properties": {
            "output_directory": {"type": "string", "description": "Target folder directory"},
            "file_name": {"type": "string", "description": "Output IFC file name"},
            "ifc_version": {"type": "string", "description": "IFC version ('IFC4' or 'IFC2x3')"}
        },
        "required": ["output_directory"]
    }
)
def export_ifc_model(doc, output_directory, file_name="Model_Export.ifc", ifc_version="IFC4", **kwargs):
    # pyrefly: ignore [missing-import]
    from samtools.export.ifc_exporter import IFCExportService
    service = IFCExportService(doc)
    summary = service.export_model_to_ifc(output_directory, file_name=file_name, ifc_version=ifc_version)
    return "IFC Export status: {}. Output: {}".format(summary.get("status"), summary.get("exported_files", []))


@ToolRegistry.register(
    name="calculate_rack_power_capacity",
    description="Calculates server rack grid coordinates and room IT power capacity (kW/MW load).",
    parameters={
        "type": "object",
        "properties": {
            "rack_width": {"type": "number", "description": "Rack width in feet (default 2.0)"},
            "kw_per_rack": {"type": "number", "description": "Design IT power rating in kW per rack"}
        }
    }
)
def calculate_rack_power_capacity(doc, rack_width=2.0, kw_per_rack=10.0, **kwargs):
    # pyrefly: ignore [missing-import]
    from samtools.datacenter.rack_engine import RackLayoutEngine
    engine = RackLayoutEngine(rack_width=rack_width, kw_per_rack=kw_per_rack)
    grid = engine.generate_rack_grid((-50, -50, 0), (50, 50, 0))
    cap = engine.calculate_room_power_capacity(grid)
    return "Generated {} racks across {} rows. Total Power Capacity: {} MW ({} kW).".format(
        cap["total_racks"], cap["total_rows"], cap["total_mw_capacity"], cap["total_kw_capacity"]
    )


@ToolRegistry.register(
    name="route_cable_trays",
    description="Computes a 3D clash-avoiding A* route for data center cable tray runs.",
    parameters={
        "type": "object",
        "properties": {
            "start_x": {"type": "number"}, "start_y": {"type": "number"}, "start_z": {"type": "number"},
            "end_x": {"type": "number"}, "end_y": {"type": "number"}, "end_z": {"type": "number"}
        }
    }
)
def route_cable_trays(doc, start_x=0, start_y=0, start_z=10, end_x=20, end_y=20, end_z=10, **kwargs):
    # pyrefly: ignore [missing-import]
    from samtools.datacenter.cable_tray_router import CableTrayRouter
    router = CableTrayRouter(doc)
    router.populate_obstacles_from_model()
    path = router.compute_route((start_x, start_y, start_z), (end_x, end_y, end_z))
    length = router.compute_path_length(path)
    return "Cable Tray Path computed with {} waypoints. Total route length: {} ft.".format(len(path), length)


# UI Launch Wrappers
def launch_modeling_automation(doc):
    return "Modeling Automation Suite Active. Available tool routines registered in ToolRegistry."

def launch_data_management(doc):
    return "Data Management & QA/QC Suite Active. Available tool routines registered in ToolRegistry."

def launch_documentation(doc):
    return "Documentation & Sheets Suite Active. Available tool routines registered in ToolRegistry."


