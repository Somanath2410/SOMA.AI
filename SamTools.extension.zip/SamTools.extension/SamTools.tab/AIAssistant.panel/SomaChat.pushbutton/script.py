# -*- coding: utf-8 -*-
"""SOMA AI Assistant - Enterprise BIM Orchestrator"""

__title__ = 'SOMA AI\nAssistant'
__author__ = 'SamTools'

import System
import os
import clr
clr.AddReference("PresentationFramework")
clr.AddReference("PresentationCore")
clr.AddReference("WindowsBase")
from System.Windows import Thickness, HorizontalAlignment, CornerRadius
from System.Windows.Controls import Border, TextBlock
from System.Windows.Media import SolidColorBrush, ColorConverter

from pyrevit import revit, DB, forms, script
import llm_client
import threading
import re
import generative_design


class SettingsDialog(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.btnCancel.Click += self.close_dialog
        self.btnSave.Click += self.save_settings

        self.cfg = llm_client.load_config()
        self.providers = llm_client.get_supported_providers()
        self.models_map = llm_client.get_supported_models()

        # Populate Provider Dropdown
        for p in self.providers:
            self.cboProvider.Items.Add(p)

        curr_provider = self.cfg.get("provider", "OpenAI")
        if curr_provider in self.providers:
            self.cboProvider.SelectedItem = curr_provider
        else:
            self.cboProvider.SelectedIndex = 0

        self.update_model_dropdown()
        self.cboProvider.SelectionChanged += lambda s, e: self.update_model_dropdown()

        self.txtApiKey.Text = self.cfg.get("api_key", "")
        self.is_ok = False

    def update_model_dropdown(self):
        self.cboModel.Items.Clear()
        provider = str(self.cboProvider.SelectedItem) if self.cboProvider.SelectedItem else "OpenAI"
        models = self.models_map.get(provider, ["gpt-4o"])
        for m in models:
            self.cboModel.Items.Add(m)
        
        curr_model = self.cfg.get("model", models[0])
        if curr_model in models:
            self.cboModel.SelectedItem = curr_model
        elif len(models) > 0:
            self.cboModel.SelectedIndex = 0

    def close_dialog(self, sender, args):
        self.Close()

    def save_settings(self, sender, args):
        self.cfg["provider"] = str(self.cboProvider.SelectedItem) if self.cboProvider.SelectedItem else "OpenAI"
        self.cfg["model"] = str(self.cboModel.SelectedItem) if self.cboModel.SelectedItem else "gpt-4o"
        self.cfg["api_key"] = self.txtApiKey.Text.strip()
        llm_client.save_config(self.cfg)
        self.is_ok = True
        self.Close()


class LoginDialog(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.btnCancel.Click += self.close_dialog
        self.btnLoginSubmit.Click += self.login_submit
        self.is_ok = False
        self.username = ""

    def close_dialog(self, sender, args):
        self.Close()
        
    def login_submit(self, sender, args):
        self.username = self.txtUsername.Text.strip()
        self.is_ok = True
        self.Close()

class SomaChatWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        
        # Clear the mock static chat
        self.stackChat.Children.Clear()
        
        # Pull Live Revit Data for the Dashboard
        self.update_health_dashboard()
            
        # Initial greeting bubble
        self.add_chat_bubble("System Online. Live BIM Health loaded. How can I orchestrate your tasks today?", is_user=False)
        
        # Wire up Left Panel (Chat & Inputs)
        self.btnSend.Click += self.process_command
        self.btnVoice.Click += self.start_voice_recognition

        
        # Wire up Right Panel (Quick Actions)
        self.btnQAModeling.Click += lambda s,e: self.trigger_quick_action("Modeling Automation")
        self.btnQAData.Click += lambda s,e: self.trigger_quick_action("Data Management & QA/QC")
        self.btnQASheets.Click += lambda s,e: self.trigger_quick_action("Documentation & Sheets")
        
        # Wire up Smart Command Chips
        self.btnChip1.Click += lambda s,e: self.simulate_user_message("Create door schedule")
        self.btnChip2.Click += lambda s,e: self.simulate_user_message("Find duplicate elements")
        self.btnChip3.Click += lambda s,e: self.simulate_user_message("Audit CAD imports")
        self.btnChip4.Click += lambda s,e: self.simulate_user_message("Generate sheets")
        self.btnChip5.Click += lambda s,e: self.simulate_user_message("Explain warning")
        self.btnChip6.Click += lambda s,e: self.simulate_user_message("Suggest naming standards")
        
        # Wire up Advanced AI Features
        self.btnAdv1.Click += lambda s,e: self.simulate_user_message("AI clash resolution")
        self.btnAdv2.Click += lambda s,e: self.simulate_user_message("Natural language modeling")
        self.btnAdv3.Click += lambda s,e: self.simulate_user_message("Auto sheet layout")
        self.btnAdv4.Click += lambda s,e: self.simulate_user_message("AI parameter audit")
        
        # Wire up Header Buttons
        self.btnLogin.Click += self.prompt_login
        self.btnSettings.Click += self.prompt_api_key

        # Auto-refresh live health dashboard when switching back to AI Assistant window from Revit
        self.Activated += lambda s, e: self.update_health_dashboard()


    def prompt_login(self, sender, args):
        dialog_file = script.get_bundle_file('login_dialog.xaml')
        dialog = LoginDialog(dialog_file)
        dialog.Owner = self
        dialog.show_dialog()
        if getattr(dialog, 'is_ok', False):
            self.add_chat_bubble("Welcome back, {}! Enterprise authentication successful.".format(dialog.username), is_user=False)


    def start_voice_recognition(self, sender, args):
        try:
            self.txtInput.Text = "Listening..."
            def listen_task():
                try:
                    import clr
                    clr.AddReference("System.Speech")
                    from System.Speech.Recognition import SpeechRecognitionEngine, DictationGrammar
                    recognizer = SpeechRecognitionEngine()
                    recognizer.LoadGrammar(DictationGrammar())
                    recognizer.SetInputToDefaultAudioDevice()
                    result = recognizer.Recognize()
                    if result and result.Text:
                        self.Dispatcher.Invoke(System.Action(lambda: self.process_voice_result(result.Text)))
                    else:
                        self.Dispatcher.Invoke(System.Action(lambda: self.process_voice_result(None)))
                    recognizer.Dispose()
                except Exception as ex:
                    self.Dispatcher.Invoke(System.Action(lambda: self.process_voice_result(None)))
            t = threading.Thread(target=listen_task)
            t.start()
        except Exception as e:
            self.txtInput.Text = ""
            self.add_chat_bubble("Speech Recognition Error: " + str(e), is_user=False)

            
    def process_voice_result(self, text):
        if text:
            self.txtInput.Text = text
            self.simulate_user_message(text)
        else:
            self.txtInput.Text = ""
            self.add_chat_bubble("Did not catch any audio. Please check your microphone.", is_user=False)

    def prompt_api_key(self, sender, args):
        dialog_file = script.get_bundle_file('settings_dialog.xaml')
        dialog = SettingsDialog(dialog_file)
        dialog.Owner = self
        dialog.show_dialog()
        if getattr(dialog, 'is_ok', False):
            self.add_chat_bubble("API Key successfully saved! SOMA AI Engine is now connected to the live LLM.", is_user=False)

    def update_health_dashboard(self):
        doc = revit.doc
        if not doc:
            return
            
        try:
            # 1. Warnings
            warnings = doc.GetWarnings()
            self.txtWarningsCount.Text = str(warnings.Count)
            self.txtWarningsSub.Text = "Live project count"
            
            # 2. CAD Imports
            cad_imports = DB.FilteredElementCollector(doc).OfClass(DB.ImportInstance).ToElements()
            self.txtCadCount.Text = str(len(cad_imports))
            if len(cad_imports) > 0:
                self.txtCadSub.Text = "Review recommended"
            else:
                self.txtCadSub.Text = "Clean model"
                
            # 3. File Size
            if doc.IsModelInCloud:
                self.txtFileSize.Text = "Cloud"
                self.txtFileSub.Text = "BIM 360 / ACC"
            elif doc.PathName:
                size_bytes = os.path.getsize(doc.PathName)
                size_mb = size_bytes / (1024 * 1024.0)
                self.txtFileSize.Text = "{:.0f} MB".format(size_mb)
                self.txtFileSub.Text = "Local file"
            else:
                self.txtFileSize.Text = "Unsaved"
                self.txtFileSub.Text = "Please save model"
                
            # 4. Sync Status
            if doc.IsWorkshared:
                self.txtSyncStatus.Text = "Workshared"
                self.txtSyncSub.Text = "Ready to sync"
            else:
                self.txtSyncStatus.Text = "Local"
                self.txtSyncSub.Text = "Non-workshared"
        except Exception as e:
            pass # Keep XAML default placeholders if there is an error

    def add_chat_bubble(self, text, is_user=False):
        bubble = Border()
        bubble.Padding = Thickness(15)
        bubble.Margin = Thickness(40, 0, 0, 15) if is_user else Thickness(0, 0, 40, 15)
        bubble.CornerRadius = CornerRadius(15, 15, 0, 15) if is_user else CornerRadius(0, 15, 15, 15)
        bubble.HorizontalAlignment = HorizontalAlignment.Right if is_user else HorizontalAlignment.Left
        
        if is_user:
            # User Bubble: Dark Green Glass
            bubble.Background = SolidColorBrush(ColorConverter.ConvertFromString("#1A00D084"))
            bubble.BorderBrush = SolidColorBrush(ColorConverter.ConvertFromString("#3300D084"))
            bubble.BorderThickness = Thickness(1)
        else:
            # AI Bubble: Dark White Glass
            bubble.Background = SolidColorBrush(ColorConverter.ConvertFromString("#1AFFFFFF"))
        
        tb = TextBlock()
        tb.Text = text
        tb.TextWrapping = System.Windows.TextWrapping.Wrap
        tb.Foreground = SolidColorBrush(ColorConverter.ConvertFromString("#FFFFFF"))
        
        bubble.Child = tb
        self.stackChat.Children.Add(bubble)

        # Scroll down
        try:
            self.scrollChat.ScrollToBottom()
        except:
            pass

    def simulate_user_message(self, text):
        self.add_chat_bubble(text, is_user=True)
        self.process_ai_response(text)
        
    def trigger_quick_action(self, module_name):
        self.simulate_user_message("Launch {}".format(module_name))
        
    def voice_command(self, sender, args):
        self.add_chat_bubble("Listening for voice commands...", is_user=False)
        
    def process_command(self, sender, args):
        cmd = self.txtInput.Text.strip()
        if not cmd: return
        self.txtInput.Text = ""
        self.simulate_user_message(cmd)

    def get_live_context(self):
        doc = revit.doc
        uidoc = revit.uidoc
        if not doc or not uidoc: return ""
        
        context = []
        context.append("Active Document: {}".format(doc.Title))
        if doc.ActiveView:
            context.append("Active View: {} ({})".format(doc.ActiveView.Name, doc.ActiveView.ViewType))
            
        try:
            selection_ids = uidoc.Selection.GetElementIds()
            if selection_ids:
                context.append("Current Selection ({} elements):".format(len(selection_ids)))
                for eid in list(selection_ids)[:10]: # Limit to 10
                    el = doc.GetElement(eid)
                    cat = el.Category.Name if el.Category else "No Category"
                    try: name = el.Name
                    except: name = "Unknown"
                    context.append(" - ID: {}, Category: {}, Name: {}".format(eid.IntegerValue, cat, name))
                if len(selection_ids) > 10:
                    context.append(" - ... and {} more".format(len(selection_ids) - 10))
            else:
                context.append("Current Selection: None")
        except Exception as e:
            context.append("Current Selection: Unable to read.")
            
        return "\n".join(context)

    def execute_ai_code(self, code_string):
        import ai_commands
        from samtools.documentation.sheet_service import SheetService
        from samtools.documentation.view_service import ViewService
        from samtools.documentation.tag_service import TagService
        from samtools.export.pdf_exporter import PDFExportService
        from samtools.export.dwg_exporter import DWGExportService
        from samtools.export.ifc_exporter import IFCExportService
        from samtools.qaqc.audit_engine import QAQCAuditEngine
        from samtools.datacenter.rack_engine import RackLayoutEngine
        from samtools.datacenter.cable_tray_router import CableTrayRouter

        doc = revit.doc
        uidoc = revit.uidoc
        exec_locals = {
            'doc': doc,
            'uidoc': uidoc,
            'DB': DB,
            'revit': revit,
            'generative_design': generative_design,
            'ai_commands': ai_commands,
            'SheetService': SheetService,
            'ViewService': ViewService,
            'TagService': TagService,
            'PDFExportService': PDFExportService,
            'DWGExportService': DWGExportService,
            'IFCExportService': IFCExportService,
            'QAQCAuditEngine': QAQCAuditEngine,
            'RackLayoutEngine': RackLayoutEngine,
            'CableTrayRouter': CableTrayRouter
        }
        try:
            exec(code_string, globals(), exec_locals)
            return "AI Script Executed Successfully."
        except Exception as e:
            return "AI Script Execution Failed: " + str(e)

    def run_llm_async(self, text):
        import ai_commands
        live_ctx = self.get_live_context()
        registered_tools = ai_commands.ToolRegistry.list_tools()
        tools_str = json.dumps(registered_tools, indent=2)

        sys_prompt = """You are SOMA AI, an enterprise BIM automation orchestrator inside Revit. 
Process ANY user request by generating exact Python code or calling registered BIM automation routines.

REGISTERED REVIT AUTOMATION TOOLS AVAILABLE:
""" + tools_str + """

GENERATIVE DESIGN MODULE:
- `generative_design.draw_rectangular_room(doc, origin_x, origin_y, width, length)`
- `generative_design.generate_grid_layout(doc, rows, cols, room_width=15.0, room_length=15.0)`
- `generative_design.generate_2bhk_apartment(doc, origin_x=0, origin_y=0)`
- `generative_design.generate_datacenter_hall(doc, rows=4, racks_per_row=10, kw_per_rack=12.5)`
- `generative_design.generate_office_floorplan(doc, origin_x=0, origin_y=0, width=60.0, length=40.0)`

AVAILABLE SERVICES IN SCOPE:
- `SheetService(doc)`: sheet creation, titleblock parameter metadata updates.
- `ViewService(doc)`: align_viewports_grid(), place_view_on_sheet().
- `TagService(doc)`: tag_elements_in_view(), tag_multiple_categories().
- `PDFExportService(doc)`: export_sheets_to_pdf().
- `DWGExportService(doc)`: export_views_to_dwg().
- `IFCExportService(doc)`: export_model_to_ifc().
- `QAQCAuditEngine(doc)`: run_full_audit(), export_audit_report_html(), export_audit_report_json().

Execution Rules:
1. Always wrap executable Python script code in ```python ... ``` blocks.
2. Use: `with revit.Transaction("SOMA AI Action"):` when modifying Revit model elements.

LIVE REVIT CONTEXT:
""" + live_ctx

        def task():
            res = llm_client.ask_llm(text, system_prompt=sys_prompt)
            
            code_blocks = re.findall(r'```python(.*?)```', res, re.DOTALL)
            if code_blocks:
                code_to_run = code_blocks[0].strip()
                self.Dispatcher.Invoke(System.Action(lambda: self.add_chat_bubble("Executing AI Generated Script...", is_user=False)))
                
                def run_code():
                    exec_res = self.execute_ai_code(code_to_run)
                    self.add_chat_bubble(exec_res, is_user=False)
                    clean_res = re.sub(r'```python.*?```', '\n*[AI Python Script Executed]*\n', res, flags=re.DOTALL).strip()
                    if clean_res:
                        self.add_chat_bubble(clean_res, is_user=False)
                        
                self.Dispatcher.Invoke(System.Action(run_code))
            else:
                self.Dispatcher.Invoke(System.Action(lambda: self.add_chat_bubble(res, is_user=False)))
                
        t = threading.Thread(target=task)
        t.start()

    def process_ai_response(self, text):
        import ai_commands
        cmd = text.lower()
        doc = revit.doc
        
        if "2bhk" in cmd or "apartment" in cmd:
            self.add_chat_bubble("Orchestrating Generative Design: Generating 2BHK Apartment Layout...", is_user=False)
            with revit.Transaction("AI 2BHK Layout"):
                res = generative_design.generate_2bhk_apartment(doc)
            self.add_chat_bubble(res, is_user=False)
        elif "office" in cmd and ("layout" in cmd or "floorplan" in cmd):
            self.add_chat_bubble("Orchestrating Generative Design: Generating Corporate Office Layout...", is_user=False)
            with revit.Transaction("AI Office Layout"):
                res = generative_design.generate_office_floorplan(doc)
            self.add_chat_bubble(res, is_user=False)
        elif "datacenter hall" in cmd or "data hall" in cmd:
            self.add_chat_bubble("Orchestrating Generative Design: Generating Data Center Data Hall...", is_user=False)
            with revit.Transaction("AI Data Hall"):
                res = generative_design.generate_datacenter_hall(doc)
            self.add_chat_bubble(res, is_user=False)
        elif "datacenter" in cmd or "data center" in cmd or "rack" in cmd:
            self.add_chat_bubble("Orchestrating Workflow: Calculating Data Center IT Power Capacity...", is_user=False)
            response = ai_commands.calculate_rack_power_capacity(doc)
            self.add_chat_bubble(response, is_user=False)
        elif "cable tray" in cmd or "route tray" in cmd:
            self.add_chat_bubble("Orchestrating Workflow: Computing 3D Cable Tray Route...", is_user=False)
            response = ai_commands.route_cable_trays(doc)
            self.add_chat_bubble(response, is_user=False)
        elif "audit" in cmd and ("qa" in cmd or "model" in cmd):
            self.add_chat_bubble("Orchestrating Workflow: Running Full QA/QC Audit...", is_user=False)
            response = ai_commands.run_qaqc_audit(doc)
            self.add_chat_bubble(response, is_user=False)
        elif "ifc" in cmd or "export ifc" in cmd:
            self.add_chat_bubble("Orchestrating Workflow: Exporting Model to IFC...", is_user=False)
            output_dir = os.path.join(os.path.expanduser("~"), "Desktop")
            response = ai_commands.export_ifc_model(doc, output_directory=output_dir)
            self.add_chat_bubble(response, is_user=False)
        elif "pdf" in cmd or "export pdf" in cmd:
            self.add_chat_bubble("Orchestrating Workflow: Batch Exporting Sheets to PDF...", is_user=False)
            from samtools.export.pdf_exporter import PDFExportService
            exporter = PDFExportService(doc)
            sheets = DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet).ToElementIds()
            if sheets:
                output_dir = os.path.join(os.path.expanduser("~"), "Desktop")
                summary = exporter.export_sheets_to_pdf(sheets, output_dir, combine=True)
                self.add_chat_bubble("PDF Export completed. Status: {}. Output: {}".format(summary.get("status"), summary.get("exported_files")), is_user=False)
            else:
                self.add_chat_bubble("No sheets found in active model to export to PDF.", is_user=False)
        elif "schedule" in cmd:
            self.add_chat_bubble("Orchestrating Workflow: Launching Modern Schedule Creator...", is_user=False)
            response = ai_commands.create_door_schedule(doc)
            self.add_chat_bubble(response, is_user=False)
        elif "duplicate" in cmd or "mark" in cmd:
            self.add_chat_bubble("Orchestrating Workflow: Launching Duplicate Finder...", is_user=False)
            response = ai_commands.find_duplicate_elements(doc)
            self.add_chat_bubble(response, is_user=False)
        elif "cad" in cmd or "import" in cmd:
            self.add_chat_bubble("Found {} CAD Imports in the model. Launching CAD Import Audit...".format(self.txtCadCount.Text), is_user=False)
            response = ai_commands.audit_cad_imports(doc)
            self.add_chat_bubble(response, is_user=False)
        elif "health" in cmd or "scan" in cmd:
            self.add_chat_bubble("Orchestrating Workflow: Running Model Health Check...", is_user=False)
            self.update_health_dashboard()
            self.add_chat_bubble("Dashboard updated. Check top right panel.", is_user=False)
        elif "warn" in cmd:
            self.add_chat_bubble("AI Copilot: There are {} warnings. Launching Warning Explainer...".format(self.txtWarningsCount.Text), is_user=False)
            response = ai_commands.explain_warning(doc)
            self.add_chat_bubble(response, is_user=False)
        elif "naming" in cmd or "standards" in cmd:
            self.add_chat_bubble("Orchestrating Workflow: Suggesting Naming Standards...", is_user=False)
            response = ai_commands.suggest_naming_standards(doc)
            self.add_chat_bubble(response, is_user=False)
        elif "clash" in cmd:
            self.add_chat_bubble("Orchestrating Workflow: Launching AI Clash Resolution...", is_user=False)
            response = ai_commands.ai_clash_resolution(doc)
            self.add_chat_bubble(response, is_user=False)
        elif "sheet layout" in cmd:
            self.add_chat_bubble("Orchestrating Workflow: Running Auto Sheet Layout...", is_user=False)
            response = ai_commands.auto_sheet_layout(doc)
            self.add_chat_bubble(response, is_user=False)
        elif "generate sheets" in cmd or "sheets" in cmd:
            self.add_chat_bubble("Orchestrating Workflow: Generating Default Sheets...", is_user=False)
            response = ai_commands.generate_sheets(doc)
            self.add_chat_bubble(response, is_user=False)
        elif "modeling automation" in cmd:
            response = ai_commands.launch_modeling_automation(doc)
            self.add_chat_bubble(response, is_user=False)
        elif "data management" in cmd or "qa/qc" in cmd:
            response = ai_commands.launch_data_management(doc)
            self.add_chat_bubble(response, is_user=False)
        elif "documentation & sheets" in cmd:
            response = ai_commands.launch_documentation(doc)
            self.add_chat_bubble(response, is_user=False)
        else:
            self.add_chat_bubble("Thinking...", is_user=False)
            self.run_llm_async(text)


def main():
    try:
        xaml_file = script.get_bundle_file('ui.xaml')
        window = SomaChatWindow(xaml_file)
        window.show_dialog()
    except Exception as e:
        if forms:
            forms.alert("Could not launch SOMA AI Assistant: " + str(e))

if __name__ == '__main__':
    main()



