# -*- coding: utf-8 -*-
"""Create and Export Schedules for selected categories.

Provides a UI to select categories (Walls, Windows, Doors, Areas, Materials, etc.)
and automatically generates schedules for them. Allows selecting specific Fields 
before exporting them to a selected folder.
"""

__title__ = 'Export\nSchedules'
__author__ = 'SamTools'

import os
from pyrevit import revit, DB
from pyrevit import forms
from pyrevit import script

doc = revit.doc
uidoc = revit.uidoc

def main():
    # 1. Define available categories with their BuiltInCategories
    cat_dict = {
        "Walls": DB.BuiltInCategory.OST_Walls,
        "Windows": DB.BuiltInCategory.OST_Windows,
        "Doors": DB.BuiltInCategory.OST_Doors,
        "Areas": DB.BuiltInCategory.OST_Areas,
        "Materials": "MATERIAL_TAKEOFF",  # Special case for material takeoff
        "Rooms": DB.BuiltInCategory.OST_Rooms,
        "Floors": DB.BuiltInCategory.OST_Floors,
        "Ceilings": DB.BuiltInCategory.OST_Ceilings,
        "Furniture": DB.BuiltInCategory.OST_Furniture,
        "Plumbing Fixtures": DB.BuiltInCategory.OST_PlumbingFixtures,
        "Structural Columns": DB.BuiltInCategory.OST_StructuralColumns,
        "Structural Framing": DB.BuiltInCategory.OST_StructuralFraming
    }

    # 2. Show UI for user to select categories
    selected_cats = forms.SelectFromList.show(
        sorted(cat_dict.keys()),
        title='Select Categories to Create & Export Schedules',
        button_name='Next: Select Fields',
        multiselect=True
    )

    if not selected_cats:
        return

    # 3. Pick export folder
    export_folder = forms.pick_folder(title="Select Folder to Export CSVs")
    if not export_folder:
        return

    created_schedules = []

    # 4. Create Schedules
    with revit.Transaction("Create Multiple Schedules"):
        for cat_name in selected_cats:
            bic = cat_dict[cat_name]
            
            try:
                if bic == "MATERIAL_TAKEOFF":
                    # Material takeoff uses multi-category
                    multi_cat = DB.Category.GetCategory(doc, DB.BuiltInCategory.OST_MultiCategory)
                    if multi_cat:
                        schedule = DB.ViewSchedule.CreateMaterialTakeoff(doc, multi_cat.Id)
                        schedule.Name = "SamTools - Material Takeoff"
                    else:
                        print("Could not find Multi-Category for Material Takeoff.")
                        continue
                else:
                    # Regular schedule
                    category = DB.Category.GetCategory(doc, bic)
                    if category:
                        schedule = DB.ViewSchedule.CreateSchedule(doc, category.Id)
                        schedule.Name = "SamTools - {} Schedule".format(cat_name)
                    else:
                        print("Could not find Category: {}".format(cat_name))
                        continue
                
                # Get all available fields for this category
                definition = schedule.Definition
                schedulable_fields = definition.GetSchedulableFields()
                
                # Create a dictionary mapping field names to the SchedulableField object
                field_dict = {}
                for sf in schedulable_fields:
                    field_name = sf.GetName(doc)
                    # Handle duplicate names if any exist
                    if field_name not in field_dict:
                        field_dict[field_name] = sf
                    else:
                        field_dict[field_name + " (1)"] = sf
                
                # Prompt user to select fields for this specific schedule
                selected_field_names = forms.SelectFromList.show(
                    sorted(field_dict.keys()),
                    title='Select Fields for: {}'.format(cat_name),
                    button_name='Add Fields',
                    multiselect=True
                )
                
                # If user selected fields, add them
                if selected_field_names:
                    for fname in selected_field_names:
                        definition.AddField(field_dict[fname])
                else:
                    # If they cancel or select none, add at least one field so it's valid
                    if schedulable_fields:
                        definition.AddField(schedulable_fields[0])
                
                created_schedules.append(schedule)
            except Exception as e:
                print("Failed to create schedule for {}: {}".format(cat_name, str(e)))

    # 5. Export Schedules
    if not created_schedules:
        forms.alert("No schedules were created.", title="Warning")
        return

    export_opt = DB.ViewScheduleExportOptions()
    export_opt.FieldDelimiter = ","
    export_opt.Title = True
    export_opt.HeadersFootersBlanks = True

    exported_count = 0
    for sched in created_schedules:
        try:
            # Clean name for file system
            safe_name = "".join([c for c in sched.Name if c.isalpha() or c.isdigit() or c==' ']).rstrip()
            filename = safe_name + ".csv"
            
            sched.Export(export_folder, filename, export_opt)
            exported_count += 1
            print("Successfully exported: {}".format(filename))
        except Exception as e:
            print("Failed to export schedule '{}': {}".format(sched.Name, str(e)))

    forms.alert("Successfully created and exported {} schedules to:\n{}".format(exported_count, export_folder), title="SamTools - Success")

if __name__ == '__main__':
    main()
