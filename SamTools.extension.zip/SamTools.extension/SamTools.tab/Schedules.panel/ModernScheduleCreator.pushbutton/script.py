# -*- coding: utf-8 -*-
"""Comprehensive Modern Schedule Creator"""

__title__ = 'Modern\nSchedule Creator'
__author__ = 'SamTools'

import os
from pyrevit import revit, DB
from pyrevit import forms
from pyrevit import script

doc = revit.doc

# Operator Map
operator_map = {
    "Equals": DB.ScheduleFilterType.Equal,
    "Not Equals": DB.ScheduleFilterType.NotEqual,
    "Greater Than": DB.ScheduleFilterType.GreaterThan,
    "Less Than": DB.ScheduleFilterType.LessThan,
    "Contains": DB.ScheduleFilterType.Contains,
    "Begins With": DB.ScheduleFilterType.BeginsWith,
    "Ends With": DB.ScheduleFilterType.EndsWith
}

class ModernScheduleWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        
        # Data tracking
        self.available_fields_full = []
        self.selected_fields = []
        self.formatting_data = {} 
        self.current_formatting_field = None
        
        # Categories
        self.cat_dict = {
            "Walls": DB.BuiltInCategory.OST_Walls,
            "Windows": DB.BuiltInCategory.OST_Windows,
            "Doors": DB.BuiltInCategory.OST_Doors,
            "Areas": DB.BuiltInCategory.OST_Areas,
            "Rooms": DB.BuiltInCategory.OST_Rooms,
            "Floors": DB.BuiltInCategory.OST_Floors,
            "Ceilings": DB.BuiltInCategory.OST_Ceilings,
            "Furniture": DB.BuiltInCategory.OST_Furniture,
            "Plumbing Fixtures": DB.BuiltInCategory.OST_PlumbingFixtures,
            "Structural Columns": DB.BuiltInCategory.OST_StructuralColumns,
            "Structural Framing": DB.BuiltInCategory.OST_StructuralFraming,
            "Materials (Multi-Category)": "MATERIAL_TAKEOFF"
        }
        self.comboCategory.ItemsSource = sorted(self.cat_dict.keys())
        
        # Populate Sheets
        sheets = DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet).ToElements()
        self.sheet_dict = {"{} - {}".format(s.SheetNumber, s.Name): s.Id for s in sheets}
        self.comboSheets.ItemsSource = sorted(self.sheet_dict.keys())
        if self.sheet_dict:
            self.comboSheets.SelectedIndex = 0
            
        # CATEGORY AUTO-DETECTION
        selected_element = None
        selection = revit.get_selection()
        if selection:
            selected_element = selection[0]
        
        detected_cat_name = None
        if selected_element:
            try:
                elem_cat = selected_element.Category
                if elem_cat:
                    for name, bic in self.cat_dict.items():
                        if bic != "MATERIAL_TAKEOFF" and elem_cat.Id.IntegerValue == int(bic):
                            detected_cat_name = name
                            break
            except: pass
            
        if detected_cat_name:
            self.comboCategory.SelectedItem = detected_cat_name
            self.on_category_changed(None, None)
        else:
            self.comboCategory.SelectedIndex = 0
        
        # Populate Operators
        ops = list(operator_map.keys())
        for combo in [self.comboFilterOperator1, self.comboFilterOperator2, self.comboFilterOperator3]:
            combo.ItemsSource = ops
            combo.SelectedIndex = 0
            
        # Populate TextNoteTypes for Appearance
        text_types = DB.FilteredElementCollector(doc).OfClass(DB.TextNoteType).ToElements()
        self.text_type_dict = {}
        for t in text_types:
            try:
                t_name = t.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString()
                if not t_name: t_name = t.Name
                self.text_type_dict[t_name] = t.Id
            except Exception as e:
                pass
                
        text_type_names = sorted(self.text_type_dict.keys())
        for combo in [self.comboTitleText, self.comboHeaderText, self.comboBodyText]:
            combo.ItemsSource = text_type_names
            if text_type_names:
                combo.SelectedIndex = 0

        # Event Handlers
        self.comboCategory.SelectionChanged += self.on_category_changed
        self.txtSearchFields.TextChanged += self.on_search_changed
        self.btnAddField.Click += self.add_field
        self.btnRemoveField.Click += self.remove_field
        self.btnMoveUp.Click += self.move_field_up
        self.btnMoveDown.Click += self.move_field_down
        self.btnCancel.Click += self.cancel
        self.btnCreate.Click += self.create_schedule
        
        # Formatting Events
        self.listFormattingFields.SelectionChanged += self.on_format_field_selected
        
        for control in [self.comboAlignment, self.comboOrientation, self.chkHiddenField, 
                        self.radioMultipleProject, self.radioMultipleVaries, self.radioMultipleCustom, 
                        self.comboConditionTest, self.comboConditionColor]:
            if hasattr(control, 'SelectionChanged'):
                control.SelectionChanged += self.on_format_changed
            elif hasattr(control, 'Click'):
                control.Click += self.on_format_changed
                
        self.txtHeading.TextChanged += self.on_format_changed
        self.txtMultipleCustom.TextChanged += self.on_format_changed
        self.txtConditionValue.TextChanged += self.on_format_changed
        
    def get_fields_for_category(self, bic):
        field_names = []
        t = DB.Transaction(doc, "Temp Schedule")
        t.Start()
        try:
            if bic == "MATERIAL_TAKEOFF":
                multi_cat = DB.Category.GetCategory(doc, DB.BuiltInCategory.OST_MultiCategory)
                schedule = DB.ViewSchedule.CreateMaterialTakeoff(doc, multi_cat.Id)
            else:
                category = DB.Category.GetCategory(doc, bic)
                schedule = DB.ViewSchedule.CreateSchedule(doc, category.Id)
            
            for sf in schedule.Definition.GetSchedulableFields():
                name = sf.GetName(doc)
                if name not in field_names:
                    field_names.append(name)
        except Exception as e:
            pass
        t.RollBack()
        return sorted(field_names)

    def on_category_changed(self, sender, args):
        cat_name = self.comboCategory.SelectedItem
        if not cat_name: return
        self.txtScheduleName.Text = "SamTools - {} Schedule".format(cat_name)
        
        self.selected_fields = []
        self.formatting_data = {}
        self.listSelectedFields.ItemsSource = None
        self.listFormattingFields.ItemsSource = None
        
        bic = self.cat_dict[cat_name]
        self.available_fields_full = self.get_fields_for_category(bic)
        
        # Auto-populate default fields for specific categories
        default_fields_map = {
            "Doors": ["Mark", "Type Mark", "Type Comments", "Width", "Height", "Finish", "Location", "Level"],
            "Windows": ["Mark", "Type Mark", "Width", "Height", "Clear Opening", "Finish M", "Room Naming", "Level"],
            "Walls": ["Mark", "Type Mark", "Width", "Length", "Area", "Level"],
            "Rooms": ["Number", "Name", "Area", "Perimeter", "Level", "Limit Offset"],
            "Furniture": ["Mark", "Type Mark", "Type", "Comments", "Level"],
            "Structural Columns": ["Mark", "Type Mark", "Type", "Base Level", "Top Level"],
            "Structural Framing": ["Mark", "Type Mark", "Type", "Reference Level", "Length"]
        }
        
        if cat_name in default_fields_map:
            for d in default_fields_map[cat_name]:
                # If the field exists in the project, add it automatically
                if d in self.available_fields_full and d not in self.selected_fields:
                    self.selected_fields.append(d)
                    self.formatting_data[d] = self.get_default_formatting()
                    
        self.refresh_selected_lists()
        self.filter_available_fields()
        self.update_dropdowns()
        
        # Reset UI Presets
        self.comboFilterField1.SelectedItem = None
        self.comboFilterOperator1.SelectedIndex = 0
        self.txtFilterValue1.Text = ""
        self.comboSortField1.SelectedItem = None
        
        # Apply Logic Presets
        if cat_name == "Doors" and "Mark" in self.selected_fields:
            self.comboFilterField1.SelectedItem = "Mark"
            self.comboFilterOperator1.SelectedItem = "Contains"
            self.txtFilterValue1.Text = "AD" # Can be changed to SD or TD by user
            self.comboSortField1.SelectedItem = "Mark"
            self.formatting_data["Mark"]["align"] = "Center"
            
        elif cat_name == "Windows" and "Mark" in self.selected_fields:
            self.comboFilterField1.SelectedItem = "Mark"
            self.comboFilterOperator1.SelectedItem = "Begins With"
            self.txtFilterValue1.Text = "W"
            self.comboSortField1.SelectedItem = "Mark"
            self.formatting_data["Mark"]["align"] = "Center"
            
        elif cat_name == "Walls" and "Mark" in self.selected_fields:
            self.comboFilterField1.SelectedItem = "Mark"
            self.comboFilterOperator1.SelectedItem = "Begins With"
            self.txtFilterValue1.Text = "CW"
            self.comboSortField1.SelectedItem = "Mark"
            self.formatting_data["Mark"]["align"] = "Center"

    def on_search_changed(self, sender, args):
        self.filter_available_fields()

    def filter_available_fields(self):
        search_text = self.txtSearchFields.Text.lower()
        if not search_text:
            filtered = self.available_fields_full
        else:
            filtered = [f for f in self.available_fields_full if search_text in f.lower()]
            
        self.listAvailableFields.ItemsSource = None
        self.listAvailableFields.ItemsSource = filtered

    def add_field(self, sender, args):
        for item in list(self.listAvailableFields.SelectedItems):
            if item not in self.selected_fields:
                self.selected_fields.append(item)
                if item not in self.formatting_data:
                    self.formatting_data[item] = self.get_default_formatting()
        
        self.refresh_selected_lists()

    def remove_field(self, sender, args):
        sel_item = self.listSelectedFields.SelectedItem
        if sel_item and sel_item in self.selected_fields:
            self.selected_fields.remove(sel_item)
                
        self.refresh_selected_lists()

    def move_field_up(self, sender, args):
        sel_item = self.listSelectedFields.SelectedItem
        if not sel_item: return
        idx = self.selected_fields.index(sel_item)
        if idx > 0:
            self.selected_fields[idx], self.selected_fields[idx-1] = self.selected_fields[idx-1], self.selected_fields[idx]
            self.refresh_selected_lists()
            self.listSelectedFields.SelectedItem = sel_item

    def move_field_down(self, sender, args):
        sel_item = self.listSelectedFields.SelectedItem
        if not sel_item: return
        idx = self.selected_fields.index(sel_item)
        if idx < len(self.selected_fields) - 1:
            self.selected_fields[idx], self.selected_fields[idx+1] = self.selected_fields[idx+1], self.selected_fields[idx]
            self.refresh_selected_lists()
            self.listSelectedFields.SelectedItem = sel_item
        
    def refresh_selected_lists(self):
        self.listSelectedFields.ItemsSource = None
        self.listSelectedFields.ItemsSource = self.selected_fields
        self.listFormattingFields.ItemsSource = None
        self.listFormattingFields.ItemsSource = self.selected_fields
        self.update_dropdowns()

    def update_dropdowns(self):
        for combo in [self.comboFilterField1, self.comboFilterField2, self.comboFilterField3, 
                      self.comboSortField1, self.comboSortField2]:
            combo.ItemsSource = None
            combo.ItemsSource = self.selected_fields

    def get_default_formatting(self):
        return {
            "heading": "",
            "orientation": "Horizontal",
            "align": "Left",
            "hidden": False,
            "multiple": "project",
            "multiple_text": "",
            "cond_test": "None",
            "cond_val": "",
            "cond_color": "Red"
        }

    def on_format_field_selected(self, sender, args):
        field_name = self.listFormattingFields.SelectedItem
        if not field_name: return
        self.current_formatting_field = field_name
        data = self.formatting_data.get(field_name, self.get_default_formatting())
        
        # Load data into UI
        self.txtHeading.Text = data["heading"]
        
        if data["orientation"] == "Horizontal": self.comboOrientation.SelectedIndex = 0
        else: self.comboOrientation.SelectedIndex = 1
        
        if data["align"] == "Left": self.comboAlignment.SelectedIndex = 0
        elif data["align"] == "Center": self.comboAlignment.SelectedIndex = 1
        elif data["align"] == "Right": self.comboAlignment.SelectedIndex = 2
        
        self.chkHiddenField.IsChecked = data["hidden"]
        
        if data["multiple"] == "project": self.radioMultipleProject.IsChecked = True
        elif data["multiple"] == "varies": self.radioMultipleVaries.IsChecked = True
        else: self.radioMultipleCustom.IsChecked = True
        
        self.txtMultipleCustom.Text = data["multiple_text"]
        
        # Cond Format
        test_index = {"None":0, "Equals":1, "Not Equals":2, "Greater Than":3, "Less Than":4}.get(data["cond_test"], 0)
        self.comboConditionTest.SelectedIndex = test_index
        self.txtConditionValue.Text = data["cond_val"]
        color_index = {"Red":0, "Green":1, "Blue":2, "Yellow":3, "Orange":4}.get(data["cond_color"], 0)
        self.comboConditionColor.SelectedIndex = color_index

    def on_format_changed(self, sender, args):
        if not self.current_formatting_field: return
        
        align_item = self.comboAlignment.SelectedItem
        align_str = align_item.Content if hasattr(align_item, 'Content') else "Left"
        
        orient_item = self.comboOrientation.SelectedItem
        orient_str = orient_item.Content if hasattr(orient_item, 'Content') else "Horizontal"
        
        multiple = "project"
        if self.radioMultipleVaries.IsChecked: multiple = "varies"
        elif self.radioMultipleCustom.IsChecked: multiple = "custom"
        
        cond_test_item = self.comboConditionTest.SelectedItem
        cond_test_str = cond_test_item.Content if hasattr(cond_test_item, 'Content') else "None"
        
        cond_color_item = self.comboConditionColor.SelectedItem
        cond_color_str = cond_color_item.Content if hasattr(cond_color_item, 'Content') else "Red"
        
        self.formatting_data[self.current_formatting_field] = {
            "heading": self.txtHeading.Text,
            "orientation": orient_str,
            "align": align_str,
            "hidden": bool(self.chkHiddenField.IsChecked),
            "multiple": multiple,
            "multiple_text": self.txtMultipleCustom.Text,
            "cond_test": cond_test_str,
            "cond_val": self.txtConditionValue.Text,
            "cond_color": cond_color_str
        }

    def cancel(self, sender, args):
        self.Close()

    def get_color(self, color_str):
        if color_str == "Red": return DB.Color(255,0,0)
        if color_str == "Green": return DB.Color(0,255,0)
        if color_str == "Blue": return DB.Color(0,0,255)
        if color_str == "Yellow": return DB.Color(255,255,0)
        if color_str == "Orange": return DB.Color(255,165,0)
        return DB.Color(255,0,0)

    def create_schedule(self, sender, args):
        cat_name = self.comboCategory.SelectedItem
        if not cat_name or not self.selected_fields:
            forms.alert("Please select a category and at least one field.", title="Warning")
            return
            
        sched_name = self.txtScheduleName.Text
        bic = self.cat_dict[cat_name]
        
        export_csv = bool(self.chkExportCSV.IsChecked)
        add_to_sheet = bool(self.chkAddToSheet.IsChecked)
        selected_sheet_name = self.comboSheets.SelectedItem
        
        self.Close()
        
        export_folder = None
        if export_csv:
            export_folder = forms.pick_folder(title="Select Folder to Export Schedule")
            if not export_folder:
                export_csv = False
        
        created_schedule = None
        
        with revit.Transaction("Create Comprehensive Schedule"):
            try:
                # 1. CREATE
                if bic == "MATERIAL_TAKEOFF":
                    multi_cat = DB.Category.GetCategory(doc, DB.BuiltInCategory.OST_MultiCategory)
                    created_schedule = DB.ViewSchedule.CreateMaterialTakeoff(doc, multi_cat.Id)
                else:
                    category = DB.Category.GetCategory(doc, bic)
                    created_schedule = DB.ViewSchedule.CreateSchedule(doc, category.Id)
                
                if sched_name:
                    try: created_schedule.Name = sched_name
                    except: created_schedule.Name = sched_name + " (1)"
                
                definition = created_schedule.Definition
                
                # 2. FIELDS & FORMATTING
                all_schedulable_fields = {sf.GetName(doc): sf for sf in definition.GetSchedulableFields()}
                added_fields = {}
                
                for field_name in self.selected_fields:
                    if field_name in all_schedulable_fields:
                        sf = all_schedulable_fields[field_name]
                        added_field = definition.AddField(sf)
                        added_fields[field_name] = added_field
                        
                        fmt = self.formatting_data.get(field_name, self.get_default_formatting())
                        
                        # Heading & Orientation
                        if fmt["heading"]: added_field.ColumnHeading = fmt["heading"]
                        if fmt["orientation"] == "Vertical": added_field.HeadingOrientation = DB.ScheduleHeadingOrientation.Vertical
                        
                        # Alignment & Hidden
                        if fmt["hidden"]: added_field.IsHidden = True
                        if fmt["align"] == "Center": added_field.HorizontalAlignment = DB.ScheduleHorizontalAlignment.Center
                        elif fmt["align"] == "Right": added_field.HorizontalAlignment = DB.ScheduleHorizontalAlignment.Right
                        else: added_field.HorizontalAlignment = DB.ScheduleHorizontalAlignment.Left

                        # Multiple Values (Revit 2023/2024+)
                        try:
                            if fmt["multiple"] == "varies":
                                added_field.MultipleValuesDisplayType = DB.ScheduleFieldMultipleValuesDisplayType.Predefined
                            elif fmt["multiple"] == "custom":
                                added_field.MultipleValuesDisplayType = DB.ScheduleFieldMultipleValuesDisplayType.Custom
                                added_field.MultipleValuesText = fmt["multiple_text"]
                            else:
                                added_field.MultipleValuesDisplayType = DB.ScheduleFieldMultipleValuesDisplayType.ProjectSettings
                        except:
                            pass # Older Revit

                        # Conditional Formatting MVP
                        if fmt["cond_test"] != "None" and fmt["cond_val"]:
                            try:
                                style = DB.TableCellStyle()
                                style.BackgroundColor = self.get_color(fmt["cond_color"])
                                override_opts = DB.TableCellStyleOverrideOptions()
                                override_opts.BackgroundColor = True
                                style.SetCellStyleOverrideOptions(override_opts)
                                
                                f_type = operator_map.get(fmt["cond_test"], DB.ScheduleFilterType.Equal)
                                
                                # Try String filter
                                try:
                                    flt = DB.ScheduleFilter(added_field.FieldId, f_type, str(fmt["cond_val"]))
                                    added_field.AddConditionalFormat(flt, style)
                                except:
                                    try: # Try Float
                                        flt = DB.ScheduleFilter(added_field.FieldId, f_type, float(fmt["cond_val"]))
                                        added_field.AddConditionalFormat(flt, style)
                                    except: pass
                            except: pass

                # 3. FILTERS
                filters = [
                    (self.comboFilterField1, self.comboFilterOperator1, self.txtFilterValue1),
                    (self.comboFilterField2, self.comboFilterOperator2, self.txtFilterValue2),
                    (self.comboFilterField3, self.comboFilterOperator3, self.txtFilterValue3)
                ]
                for f_cb, op_cb, val_tb in filters:
                    f_name = f_cb.SelectedItem
                    if f_name and f_name in added_fields and val_tb.Text:
                        f_type = operator_map[op_cb.SelectedItem]
                        try:
                            definition.AddFilter(DB.ScheduleFilter(added_fields[f_name].FieldId, f_type, str(val_tb.Text)))
                        except:
                            try: definition.AddFilter(DB.ScheduleFilter(added_fields[f_name].FieldId, f_type, float(val_tb.Text)))
                            except: pass

                # 4. SORTING
                sorts = [
                    (self.comboSortField1, self.comboSortOrder1, self.chkSortBlank1),
                    (self.comboSortField2, self.comboSortOrder2, self.chkSortBlank2)
                ]
                for s_cb, o_cb, b_chk in sorts:
                    s_name = s_cb.SelectedItem
                    if s_name and s_name in added_fields:
                        sg = DB.ScheduleSortGroupField(added_fields[s_name].FieldId)
                        order_str = o_cb.Text if hasattr(o_cb, 'Text') else o_cb.SelectedItem.Content
                        if "Desc" in order_str: sg.SortOrder = DB.ScheduleSortOrder.Descending
                        else: sg.SortOrder = DB.ScheduleSortOrder.Ascending
                        
                        sg.HasBlankRow = bool(b_chk.IsChecked)
                        definition.AddSortGroupField(sg)
                
                definition.IsItemized = bool(self.chkItemizeEveryInstance.IsChecked)

                # 5. APPEARANCE
                definition.ShowTitle = bool(self.chkShowTitle.IsChecked)
                definition.ShowHeaders = bool(self.chkShowHeaders.IsChecked)
                
                if hasattr(created_schedule, "TitleTextTypeId"):
                    t_name = self.comboTitleText.SelectedItem
                    if t_name in self.text_type_dict: created_schedule.TitleTextTypeId = self.text_type_dict[t_name]
                    
                    h_name = self.comboHeaderText.SelectedItem
                    if h_name in self.text_type_dict: created_schedule.HeaderTextTypeId = self.text_type_dict[h_name]
                    
                    b_name = self.comboBodyText.SelectedItem
                    if b_name in self.text_type_dict: created_schedule.BodyTextTypeId = self.text_type_dict[b_name]

                # 6. PLACE ON SHEET
                if add_to_sheet and selected_sheet_name in self.sheet_dict:
                    sheet_id = self.sheet_dict[selected_sheet_name]
                    try:
                        DB.ScheduleSheetInstance.Create(doc, sheet_id, created_schedule.Id, DB.XYZ.Zero)
                    except Exception as e:
                        print("Could not place on sheet: " + str(e))
                        
            except Exception as e:
                forms.alert("Error creating schedule: " + str(e), title="Error")
                return

        # 7. EXPORT
        if created_schedule and export_csv and export_folder:
            try:
                export_opt = DB.ViewScheduleExportOptions()
                export_opt.FieldDelimiter = ","
                export_opt.Title = True
                export_opt.HeadersFootersBlanks = True
                
                safe_name = "".join([c for c in created_schedule.Name if c.isalpha() or c.isdigit() or c==' ']).rstrip()
                filename = safe_name + ".csv"
                
                created_schedule.Export(export_folder, filename, export_opt)
                forms.alert("Schedule created and exported to:\n" + export_folder, title="Success")
            except Exception as e:
                forms.alert("Schedule created, but export failed: " + str(e), title="Warning")
        else:
            forms.alert("Schedule '{}' created successfully!".format(created_schedule.Name), title="Success")

def main():
    xaml_file = script.get_bundle_file('ui.xaml')
    ModernScheduleWindow(xaml_file).show_dialog()

if __name__ == '__main__':
    main()
