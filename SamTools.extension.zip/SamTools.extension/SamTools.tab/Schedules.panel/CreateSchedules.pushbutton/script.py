# -*- coding: utf-8 -*-
"""Create Schedules for selected categories.

Provides a UI to select categories (Walls, Windows, Doors, Areas, Materials, etc.).
Then, for each selected category, it prompts you to select which Fields to add.
"""

__title__ = 'Create\nSchedules'
__author__ = 'SamTools'

from pyrevit import revit, DB
from pyrevit import forms
from pyrevit import script

doc = revit.doc
uidoc = revit.uidoc

def main():
    # 1. Define available categories
    cat_dict = {
        "Walls": DB.BuiltInCategory.OST_Walls,
        "Windows": DB.BuiltInCategory.OST_Windows,
        "Doors": DB.BuiltInCategory.OST_Doors,
        "Areas": DB.BuiltInCategory.OST_Areas,
        "Materials": "MATERIAL_TAKEOFF",  # Special case for material takeoff
        "Rooms": DB.BuiltInCategory.OST_Rooms,
        "Floors": DB.BuiltInCategory.OST_Floors,
        "Ceilings": DB.BuiltInCategory.OST_Ceilings,
        "Furniture": DB.BuiltInCategory.OST_Furniture,
        "Plumbing Fixtures": DB.BuiltInCategory.OST_PlumbingFixtures,
        "Structural Columns": DB.BuiltInCategory.OST_StructuralColumns,
        "Structural Framing": DB.BuiltInCategory.OST_StructuralFraming
    }

    # 2. Show UI for user to select categories
    selected_cats = forms.SelectFromList.show(
        sorted(cat_dict.keys()),
        title='Select Categories to Create Schedules',
        button_name='Next: Select Fields',
        multiselect=True
    )

    if not selected_cats:
        return

    created_schedules = []

    # 3. Create Schedules and prompt for fields
    with revit.Transaction("Create Multiple Schedules"):
        for cat_name in selected_cats:
            bic = cat_dict[cat_name]
            
            try:
                if bic == "MATERIAL_TAKEOFF":
                    multi_cat = DB.Category.GetCategory(doc, DB.BuiltInCategory.OST_MultiCategory)
                    if multi_cat:
                        schedule = DB.ViewSchedule.CreateMaterialTakeoff(doc, multi_cat.Id)
                        schedule.Name = "SamTools - Material Takeoff"
                    else:
                        continue
                else:
                    category = DB.Category.GetCategory(doc, bic)
                    if category:
                        schedule = DB.ViewSchedule.CreateSchedule(doc, category.Id)
                        schedule.Name = "SamTools - {} Schedule".format(cat_name)
                    else:
                        continue
                
                # Get all available fields for this category
                definition = schedule.Definition
                schedulable_fields = definition.GetSchedulableFields()
                
                # Create a dictionary mapping field names to the SchedulableField object
                field_dict = {}
                for sf in schedulable_fields:
                    field_name = sf.GetName(doc)
                    # Handle duplicate names if any exist
                    if field_name not in field_dict:
                        field_dict[field_name] = sf
                    else:
                        field_dict[field_name + " (1)"] = sf
                
                # Prompt user to select fields for this specific schedule
                selected_field_names = forms.SelectFromList.show(
                    sorted(field_dict.keys()),
                    title='Select Fields for: {}'.format(cat_name),
                    button_name='Add Fields',
                    multiselect=True
                )
                
                # If user selected fields, add them
                if selected_field_names:
                    for fname in selected_field_names:
                        definition.AddField(field_dict[fname])
                else:
                    # If they cancel or select none, add at least one field so it's valid
                    if schedulable_fields:
                        definition.AddField(schedulable_fields[0])
                
                created_schedules.append(schedule)
            except Exception as e:
                print("Failed to create schedule for {}: {}".format(cat_name, str(e)))

    if not created_schedules:
        forms.alert("No schedules were created.", title="Warning")
        return

    forms.alert("Successfully created {} schedules with custom fields!".format(len(created_schedules)), title="SamTools - Success")

if __name__ == '__main__':
    main()
