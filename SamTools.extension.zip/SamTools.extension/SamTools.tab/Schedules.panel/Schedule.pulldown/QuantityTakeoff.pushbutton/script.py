# -*- coding: utf-8 -*-

from pyrevit import revit, DB, UI
from pyrevit import forms
from pyrevit import script
import os
import csv
import json
import System
from System.Windows.Controls import TreeViewItem, CheckBox, StackPanel, TextBlock, ComboBox, TextBox, Button, Orientation

doc = revit.doc
app = doc.Application

# Path to templates.json
JSON_PATH = os.path.join(os.path.dirname(__file__), "templates.json")

class QuantityTakeoffWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        
        # 1. Load Templates from JSON
        self.preset_templates = {}
        if os.path.exists(JSON_PATH):
            with open(JSON_PATH, 'r') as f:
                self.preset_templates = json.load(f)
                
        self.comboTemplates.ItemsSource = sorted(self.preset_templates.keys())
        self.comboTemplates.SelectedIndex = 0
        
        # 2. Categories grouped for TreeView
        self.cat_dict = self.get_all_categories()
        self.tree_nodes = []
        self.populate_category_tree()
        
        # UI State
        self.selected_fields = []
        self.available_fields = []
        self.filter_rows = []
        
        # Bind Events
        self.btnAddField.Click += self.add_field
        self.btnRemoveField.Click += self.remove_field
        self.btnLoadTemplate.Click += self.load_template
        self.btnEditTemplates.Click += self.edit_templates
        self.btnGenerate.Click += self.generate_takeoff
        self.btnCancel.Click += self.close_window
        self.btnBrowseFolder.Click += self.browse_folder
        self.btnAddFilter.Click += self.add_filter_row
        self.btnClearFilters.Click += self.clear_filters
        self.btnSelectAllCats.Click += self.select_all_cats
        self.btnClearAllCats.Click += self.clear_all_cats
        self.chkMaterialTakeoff.Click += self.refresh_available_fields
        
        # Set Default Path
        self.txtExportFolder.Text = os.path.expanduser("~\\Documents")
        
    def get_all_categories(self):
        cats = {}
        for cat in doc.Settings.Categories:
            if cat.CategoryType == DB.CategoryType.Model and cat.AllowsBoundParameters:
                cats[cat.Name] = cat
        return cats

    def populate_category_tree(self):
        groups = {
            "Architecture": ["Walls", "Floors", "Roofs", "Ceilings", "Doors", "Windows", "Stairs", "Railings", "Rooms", "Casework", "Furniture"],
            "Structure": ["Structural Columns", "Structural Framing", "Structural Foundations", "Structural Rebar", "Structural Connections"],
            "MEP": ["Ducts", "Pipes", "Cable Trays", "Conduits", "Mechanical Equipment", "Plumbing Fixtures", "Lighting Fixtures", "Air Terminals"],
            "Other": []
        }
        
        cat_names_sorted = sorted(self.cat_dict.keys())
        assigned = set()
        
        for g_name, g_list in groups.items():
            if g_name == "Other": continue
            node = TreeViewItem()
            node.Header = g_name
            node.IsExpanded = True
            
            for c in g_list:
                if c in cat_names_sorted:
                    child = CheckBox()
                    child.Content = c
                    child.Click += self.refresh_available_fields
                    node.Items.Add(child)
                    self.tree_nodes.append(child)
                    assigned.add(c)
            self.treeCategories.Items.Add(node)
            
        node_other = TreeViewItem()
        node_other.Header = "Other Model Categories"
        for c in cat_names_sorted:
            if c not in assigned:
                child = CheckBox()
                child.Content = c
                child.Click += self.refresh_available_fields
                node_other.Items.Add(child)
                self.tree_nodes.append(child)
        self.treeCategories.Items.Add(node_other)
        
    def get_selected_categories(self):
        return [chk.Content for chk in self.tree_nodes if chk.IsChecked]
        
    def select_all_cats(self, sender, args):
        for chk in self.tree_nodes: chk.IsChecked = True
        self.refresh_available_fields(None, None)
        
    def clear_all_cats(self, sender, args):
        for chk in self.tree_nodes: chk.IsChecked = False
        self.refresh_available_fields(None, None)

    def refresh_available_fields(self, sender, args):
        sel_cat_names = self.get_selected_categories()
        if not sel_cat_names:
            self.listAvailableFields.ItemsSource = []
            return
            
        field_names = set()
        t = DB.Transaction(doc, "Temp Schedule")
        t.Start()
        try:
            is_mat_takeoff = getattr(self.chkMaterialTakeoff, 'IsChecked', False)
            for cat_name in sel_cat_names:
                cat = self.cat_dict[cat_name]
                if is_mat_takeoff:
                    schedule = DB.ViewSchedule.CreateMaterialTakeoff(doc, cat.Id)
                else:
                    schedule = DB.ViewSchedule.CreateSchedule(doc, cat.Id)
                    
                for sf in schedule.Definition.GetSchedulableFields():
                    field_names.add(sf.GetName(doc))
        except Exception as e:
            pass
        t.RollBack()
        
        self.available_fields = sorted(list(field_names))
        self.update_field_lists()

    def add_field(self, sender, args):
        items = [item for item in self.listAvailableFields.SelectedItems]
        for item in items:
            if item not in self.selected_fields:
                self.selected_fields.append(item)
        self.update_field_lists()

    def remove_field(self, sender, args):
        items = [item for item in self.listSelectedFields.SelectedItems]
        for item in items:
            if item in self.selected_fields:
                self.selected_fields.remove(item)
        self.update_field_lists()
        
    def update_field_lists(self):
        avail = [f for f in self.available_fields if f not in self.selected_fields]
        self.listAvailableFields.ItemsSource = sorted(avail)
        self.listSelectedFields.ItemsSource = None
        self.listSelectedFields.ItemsSource = self.selected_fields
        
        sel_sort1 = self.comboSort1.SelectedItem
        sel_sort2 = self.comboSort2.SelectedItem
        self.comboSort1.ItemsSource = ["<None>"] + self.selected_fields
        self.comboSort2.ItemsSource = ["<None>"] + self.selected_fields
        
        if sel_sort1 in self.selected_fields: self.comboSort1.SelectedItem = sel_sort1
        else: self.comboSort1.SelectedIndex = 0
        
        if sel_sort2 in self.selected_fields: self.comboSort2.SelectedItem = sel_sort2
        else: self.comboSort2.SelectedIndex = 0

    def edit_templates(self, sender, args):
        if os.path.exists(JSON_PATH):
            os.startfile(JSON_PATH)
        else:
            forms.alert("templates.json not found!")

    def load_template(self, sender, args):
        template = self.comboTemplates.SelectedItem
        if not template or template not in self.preset_templates: return
        
        data = self.preset_templates[template]
        self.txtScheduleName.Text = template
        
        # 1. Categories
        cats = data.get("categories", [])
        for chk in self.tree_nodes:
            chk.IsChecked = (chk.Content in cats)
            
        # Material Takeoff Check
        fields = data.get("fields", [])
        if "Material:" in "".join(fields):
            self.chkMaterialTakeoff.IsChecked = True
        else:
            self.chkMaterialTakeoff.IsChecked = False
            
        self.refresh_available_fields(None, None)
        
        # 2. Fields
        self.selected_fields = [f for f in fields if f in self.available_fields]
        self.update_field_lists()
        
        # 3. Exclusions
        excls = data.get("exclusions", {})
        for ui_name, val in excls.items():
            if hasattr(self, ui_name):
                getattr(self, ui_name).IsChecked = val
                
        # 4. Calculation
        calcs = data.get("calculation", {})
        for ui_name, val in calcs.items():
            if hasattr(self, ui_name):
                ui_elem = getattr(self, ui_name)
                if isinstance(ui_elem, CheckBox) or hasattr(ui_elem, "IsChecked"):
                    ui_elem.IsChecked = val
                elif isinstance(ui_elem, ComboBox):
                    for item in ui_elem.Items:
                        if item.Content == val:
                            ui_elem.SelectedItem = item
                            break
                            
        # 5. Export
        exports = data.get("export", {})
        for ui_name, val in exports.items():
            if hasattr(self, ui_name):
                getattr(self, ui_name).IsChecked = val

        # 6. Filters
        self.clear_filters(None, None)
        filters = data.get("filters", [])
        for f in filters:
            sp = self.add_filter_row(None, None)
            cbo_field, cbo_op, txt_val = self.filter_rows[-1]
            if f["field"] in self.selected_fields: cbo_field.SelectedItem = f["field"]
            if f["operator"] in cbo_op.ItemsSource: cbo_op.SelectedItem = f["operator"]
            txt_val.Text = f["value"]
            
        # 7. Sorting
        sorting = data.get("sorting", [])
        if len(sorting) > 0 and sorting[0] in self.selected_fields:
            self.comboSort1.SelectedItem = sorting[0]
        if len(sorting) > 1 and sorting[1] in self.selected_fields:
            self.comboSort2.SelectedItem = sorting[1]

    def add_filter_row(self, sender, args):
        sp = StackPanel()
        sp.Orientation = Orientation.Horizontal
        sp.Margin = System.Windows.Thickness(0, 0, 0, 10)
        
        cbo_field = ComboBox()
        cbo_field.Width = 150
        cbo_field.ItemsSource = self.selected_fields
        if self.selected_fields: cbo_field.SelectedIndex = 0
        
        cbo_op = ComboBox()
        cbo_op.Width = 100
        cbo_op.Margin = System.Windows.Thickness(10, 0, 10, 0)
        cbo_op.ItemsSource = ["Equals", "Not Equals", "Contains", "Greater Than", "Less Than"]
        cbo_op.SelectedIndex = 0
        
        txt_val = TextBox()
        txt_val.Width = 150
        txt_val.Height = 28
        
        btn_del = Button()
        btn_del.Content = "X"
        btn_del.Width = 30
        btn_del.Margin = System.Windows.Thickness(10, 0, 0, 0)
        btn_del.Background = System.Windows.Media.Brushes.DarkRed
        btn_del.Click += lambda s, a: self.remove_filter_row(sp)
        
        sp.Children.Add(cbo_field)
        sp.Children.Add(cbo_op)
        sp.Children.Add(txt_val)
        sp.Children.Add(btn_del)
        
        self.panelFilters.Children.Add(sp)
        self.filter_rows.append((cbo_field, cbo_op, txt_val))
        return sp

    def remove_filter_row(self, row_panel):
        self.panelFilters.Children.Remove(row_panel)

    def clear_filters(self, sender, args):
        self.panelFilters.Children.Clear()
        self.filter_rows = []

    def browse_folder(self, sender, args):
        import System.Windows.Forms as WinForms
        dialog = WinForms.FolderBrowserDialog()
        if dialog.ShowDialog() == WinForms.DialogResult.OK:
            self.txtExportFolder.Text = dialog.SelectedPath

    def close_window(self, sender, args):
        self.Close()

    def generate_takeoff(self, sender, args):
        sel_cat_names = self.get_selected_categories()
        if not sel_cat_names:
            forms.alert("Please select at least one category.")
            return
            
        if not self.selected_fields:
            forms.alert("Please select at least one field.")
            return
            
        sched_name = self.txtScheduleName.Text
        if not sched_name:
            sched_name = "Enterprise Quantity Takeoff"
            
        is_mat_takeoff = getattr(self.chkMaterialTakeoff, 'IsChecked', False)
        push_to_revit = getattr(self.chkPushToRevit, 'IsChecked', True)
        
        export_csv = getattr(self.chkExportCSV, 'IsChecked', False)
        export_json = getattr(self.chkExportJSON, 'IsChecked', False)
        
        calc_gross = getattr(self.radioGrossArea, 'IsChecked', False)
        auto_calc_totals = getattr(self.chkAutoCalculateTotals, 'IsChecked', True)
        
        created_schedules = []
        
        with revit.Transaction("Generate Enterprise QTO"):
            for cat_name in sel_cat_names:
                cat = self.cat_dict[cat_name]
                try:
                    if is_mat_takeoff: schedule = DB.ViewSchedule.CreateMaterialTakeoff(doc, cat.Id)
                    else: schedule = DB.ViewSchedule.CreateSchedule(doc, cat.Id)
                        
                    try: schedule.Name = "{} - {}".format(sched_name, cat_name)
                    except: schedule.Name = "{} - {} (1)".format(sched_name, cat_name)
                    
                    definition = schedule.Definition
                    
                    all_schedulable_fields = {sf.GetName(doc): sf for sf in definition.GetSchedulableFields()}
                    
                    # Store added fields to allow filtering
                    added_fields_dict = {}
                    
                    for field_name in self.selected_fields:
                        if field_name in all_schedulable_fields:
                            sf = all_schedulable_fields[field_name]
                            added_field = definition.AddField(sf)
                            added_fields_dict[field_name] = added_field
                            
                            if auto_calc_totals and field_name in ["Area", "Volume", "Count", "Length", "Material: Area", "Material: Volume", "Perimeter", "Bar Length"]:
                                added_field.DisplayType = DB.ScheduleFieldDisplayType.Totals
                    
                    if calc_gross and cat_name == "Walls":
                        try:
                            DB.ScheduleField.CreateCalculatedField(doc, "Gross Area", DB.UnitType.UT_Area)
                        except: pass
                    
                    definition.IsItemized = getattr(self.chkItemizeEveryInstance, 'IsChecked', True)
                    definition.ShowGrandTotal = getattr(self.chkGrandTotals, 'IsChecked', False)
                    
                    sort1_name = self.comboSort1.SelectedItem
                    if sort1_name and sort1_name != "<None>":
                        for i in range(definition.GetFieldCount()):
                            f = definition.GetField(i)
                            if f.GetName() == sort1_name:
                                sort_field = DB.ScheduleSortGroupField(f.FieldId)
                                definition.AddSortGroupField(sort_field)
                                break
                                
                    sort2_name = self.comboSort2.SelectedItem
                    if sort2_name and sort2_name != "<None>":
                        for i in range(definition.GetFieldCount()):
                            f = definition.GetField(i)
                            if f.GetName() == sort2_name:
                                sort_field = DB.ScheduleSortGroupField(f.FieldId)
                                definition.AddSortGroupField(sort_field)
                                break
                    
                    if getattr(self.chkExcludeLinked, 'IsChecked', False):
                        definition.IncludeLinkedFiles = False
                        
                    # Filtering Logic (Basic string mapping)
                    # Note: Full parameter typed filtering requires ParameterFilterRuleFactory. This attempts basic string filters.
                    for cbo_field, cbo_op, txt_val in self.filter_rows:
                        f_name = cbo_field.SelectedItem
                        op_str = cbo_op.SelectedItem
                        val_str = txt_val.Text
                        if f_name in added_fields_dict and val_str:
                            af = added_fields_dict[f_name]
                            # Attempt basic string filtering (works for many parameters)
                            try:
                                if op_str == "Equals":
                                    filter_rule = DB.ScheduleFilter(af.FieldId, DB.ScheduleFilterType.Equal, val_str)
                                    definition.AddFilter(filter_rule)
                                elif op_str == "Not Equals":
                                    filter_rule = DB.ScheduleFilter(af.FieldId, DB.ScheduleFilterType.NotEqual, val_str)
                                    definition.AddFilter(filter_rule)
                                elif op_str == "Contains":
                                    filter_rule = DB.ScheduleFilter(af.FieldId, DB.ScheduleFilterType.Contains, val_str)
                                    definition.AddFilter(filter_rule)
                            except: pass
                    
                    created_schedules.append(schedule)
                except Exception as e:
                    print("Failed to process {}: {}".format(cat_name, e))
                    
        # EXPORT ENGINE
        if (export_csv or export_json) and created_schedules:
            folder = self.txtExportFolder.Text
            if not os.path.exists(folder):
                try: os.makedirs(folder)
                except: pass
                
            if os.path.exists(folder):
                for sched in created_schedules:
                    try:
                        options = DB.ViewScheduleExportOptions()
                        options.FieldDelimiter = ","
                        options.TextQualifier = DB.ExportTextQualifier.DoubleQuote
                        options.ColumnHeaders = DB.ExportColumnHeaders.OneRow
                        
                        clean_name = "".join(c for c in sched.Name if c not in r'<>:"/\|?*')
                        csv_file = "{}.csv".format(clean_name)
                        
                        if export_csv:
                            sched.Export(folder, csv_file, options)
                        
                        if export_json:
                            csv_path = os.path.join(folder, csv_file)
                            if not export_csv: sched.Export(folder, csv_file, options)
                            
                            json_data = []
                            with open(csv_path, 'r') as csvfile:
                                reader = csv.DictReader(csvfile)
                                for row in reader:
                                    json_data.append(dict(row))
                                    
                            json_path = os.path.join(folder, "{}.json".format(clean_name))
                            with open(json_path, 'w') as jsonfile:
                                json.dump(json_data, jsonfile, indent=4)
                                
                            if not export_csv: os.remove(csv_path) 
                            
                    except Exception as e:
                        print("Failed to export {}: {}".format(sched.Name, e))
                
                try: os.startfile(folder)
                except: pass

        if not push_to_revit and created_schedules:
            with revit.Transaction("Clean up QTO schedules"):
                for sched in created_schedules:
                    doc.Delete(sched.Id)

        self.Close()
        forms.alert("Enterprise Quantity Takeoff processed successfully!")

# Execute UI
win = QuantityTakeoffWindow('ui.xaml')
win.ShowDialog()
