# -*- coding: utf-8 -*-
"""Bulk Load Families from Folder"""

__title__ = 'Bulk Load'
__author__ = 'SamTools'

import os
from pyrevit import revit, DB, forms

doc = revit.doc

def main():
    folder = forms.pick_folder(title="Select Folder containing .rfa files")
    if not folder: return
    
    rfa_files = [f for f in os.listdir(folder) if f.lower().endswith(".rfa")]
    
    if not rfa_files:
        forms.alert("No .rfa files found in the selected folder.", title="Not Found")
        return
        
    with revit.Transaction("SamTools - Bulk Load Families"):
        count = 0
        for rfa in rfa_files:
            path = os.path.join(folder, rfa)
            try:
                doc.LoadFamily(path)
                count += 1
            except: pass
            
    forms.alert("Successfully loaded {} families.".format(count), title="Success")

if __name__ == '__main__':
    main()
