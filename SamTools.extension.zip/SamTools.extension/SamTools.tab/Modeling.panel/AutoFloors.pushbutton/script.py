# -*- coding: utf-8 -*-
"""Batch Create Floors from Wall Selection"""

__title__ = 'Auto Floors'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script

doc = revit.doc

def main():
    selection = revit.get_selection()
    walls = [el for el in selection if isinstance(el, DB.Wall)]
    
    if not walls:
        forms.alert("Please select a closed loop of Walls.", title="Selection Required")
        return
        
    floor_types = DB.FilteredElementCollector(doc).OfClass(DB.FloorType).ToElements()
    ft_dict = {ft.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString() or ft.Name: ft for ft in floor_types}
    
    class AutoFloorWindow(forms.WPFWindow):
        def __init__(self, xaml_file):
            forms.WPFWindow.__init__(self, xaml_file)
            self.comboFloorType.ItemsSource = sorted(ft_dict.keys())
            if floor_types: self.comboFloorType.SelectedIndex = 0
            
            self.btnCancel.Click += self.cancel
            self.btnCreate.Click += self.run_creation
            self.success = False

        def cancel(self, sender, args):
            self.Close()
            
        def run_creation(self, sender, args):
            self.sel_floor_type = ft_dict[self.comboFloorType.SelectedItem]
            self.success = True
            self.Close()

    xaml_file = script.get_bundle_file('ui.xaml')
    win = AutoFloorWindow(xaml_file)
    win.show_dialog()
    
    if not win.success: return
    sel_floor_type = win.sel_floor_type
    
    level = walls[0].LevelId
    
    with revit.Transaction("SamTools - Auto Floors"):
        curve_array = DB.CurveArray()
        for wall in walls:
            loc = wall.Location
            if hasattr(loc, "Curve"):
                curve_array.Append(loc.Curve)
        
        try:
            doc.Create.NewFloor(curve_array, sel_floor_type, doc.GetElement(level), False)
            forms.alert("Floor created successfully.", title="Success")
        except Exception as e:
            forms.alert("Could not create floor. Ensure walls form a closed loop.\nError: {}".format(str(e)), title="Error")

if __name__ == '__main__':
    main()
