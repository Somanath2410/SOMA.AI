# -*- coding: utf-8 -*-
"""Batch Create Walls from Selection"""

__title__ = 'Auto Walls'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script

doc = revit.doc

def main():
    # 1. Select Lines
    selection = revit.get_selection()
    if not selection:
        forms.alert("Please select some Lines or CAD lines first.", title="Selection Required")
        return
        
    # 2. Settings UI
    levels = DB.FilteredElementCollector(doc).OfClass(DB.Level).ToElements()
    levels = sorted(levels, key=lambda l: l.Elevation)
    level_dict = {l.Name: l for l in levels}
    
    wall_types = DB.FilteredElementCollector(doc).OfClass(DB.WallType).ToElements()
    wt_dict = {wt.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString() or wt.Name: wt for wt in wall_types}
    
    class AutoWallWindow(forms.WPFWindow):
        def __init__(self, xaml_file):
            forms.WPFWindow.__init__(self, xaml_file)
            self.comboLevel.ItemsSource = sorted(level_dict.keys())
            if levels: self.comboLevel.SelectedIndex = 0
            
            self.comboWallType.ItemsSource = sorted(wt_dict.keys())
            if wall_types: self.comboWallType.SelectedIndex = 0
            
            self.btnCancel.Click += self.cancel
            self.btnCreate.Click += self.run_creation
            self.success = False

        def cancel(self, sender, args):
            self.Close()
            
        def run_creation(self, sender, args):
            self.sel_level = level_dict[self.comboLevel.SelectedItem]
            self.sel_wall_type = wt_dict[self.comboWallType.SelectedItem]
            self.success = True
            self.Close()

    xaml_file = script.get_bundle_file('ui.xaml')
    win = AutoWallWindow(xaml_file)
    win.show_dialog()
    
    if not win.success: return
    
    selected_level = win.sel_level
    selected_wall_type = win.sel_wall_type
    
    # 3. Process
    with revit.Transaction("SamTools - Auto Walls"):
        count = 0
        for elem in selection:
            curve = None
            if hasattr(elem, "GeometryCurve"):
                curve = elem.GeometryCurve
            elif isinstance(elem, DB.CurveElement):
                curve = elem.GeometryCurve
            
            if curve:
                try:
                    DB.Wall.Create(doc, curve, selected_wall_type.Id, selected_level.Id, 10.0, 0.0, False, False)
                    count += 1
                except: pass
        
    forms.alert("Successfully created {} walls.".format(count), title="Success")

if __name__ == '__main__':
    main()
