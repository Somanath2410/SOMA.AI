# -*- coding: utf-8 -*-
"""Place Columns at Grid Intersections"""

__title__ = 'Grid Columns'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms

doc = revit.doc

def main():
    selection = revit.get_selection()
    grids = [el for el in selection if isinstance(el, DB.Grid)]
    
    if len(grids) < 2:
        forms.alert("Please select at least 2 intersecting Grids.", title="Selection Required")
        return
        
    col_types = DB.FilteredElementCollector(doc).OfClass(DB.FamilySymbol).OfCategory(DB.BuiltInCategory.OST_StructuralColumns).ToElements()
    sel_type = forms.select_family_parameters(col_types)
    if not sel_type: return
    
    level = doc.ActiveView.GenLevel
    if not level:
        levels = DB.FilteredElementCollector(doc).OfClass(DB.Level).ToElements()
        level = levels[0]

    with revit.Transaction("SamTools - Column Grid Placement"):
        if not sel_type.IsActive: sel_type.Activate()
        
        count = 0
        for i in range(len(grids)):
            for j in range(i+1, len(grids)):
                g1 = grids[i]
                g2 = grids[j]
                
                # Find intersection
                c1 = g1.Curve
                c2 = g2.Curve
                
                results = DB.IntersectionResultArray()
                compare = c1.Intersect(c2, results)
                
                if compare == DB.SetComparisonResult.Overlap:
                    for res in results:
                        pt = res.XYZPoint
                        doc.Create.NewFamilyInstance(pt, sel_type, level, DB.Structure.StructuralType.Column)
                        count += 1
                        
    forms.alert("Placed {} columns at intersections.".format(count), title="Success")

if __name__ == '__main__':
    main()
