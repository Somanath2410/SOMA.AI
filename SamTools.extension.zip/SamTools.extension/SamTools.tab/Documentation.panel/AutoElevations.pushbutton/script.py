# -*- coding: utf-8 -*-
"""Auto Elevation & Plan Generator V2"""

__title__ = 'Auto Elevation'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script
from System.Collections.Generic import List
import math

doc = revit.doc
uidoc = revit.uidoc

class AutoElevWindow(forms.WPFWindow):
    def __init__(self, xaml_file):
        forms.WPFWindow.__init__(self, xaml_file)
        
        # Load View Types
        v_types = DB.FilteredElementCollector(doc).OfClass(DB.ViewFamilyType).ToElements()
        
        self.elev_dict = {vt.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString(): vt 
                          for vt in v_types if vt.ViewFamily == DB.ViewFamily.Elevation}
        elev_list = sorted(self.elev_dict.keys())
        self.comboElevType.ItemsSource = elev_list
        # Set default to 'ga elevation' if exists
        for idx, name in enumerate(elev_list):
            if "ga elevation" in name.lower():
                self.comboElevType.SelectedIndex = idx
                break
        else:
            if elev_list: self.comboElevType.SelectedIndex = 0
        
        self.plan_dict = {vt.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString(): vt 
                          for vt in v_types if vt.ViewFamily in [DB.ViewFamily.Section, DB.ViewFamily.Detail, DB.ViewFamily.FloorPlan]}
        plan_list = sorted(self.plan_dict.keys())
        self.comboPlanType.ItemsSource = plan_list
        # Set default to 'floor plan' or 'ga' if exists
        for idx, name in enumerate(plan_list):
            if "floor plan" in name.lower() or "ga" in name.lower():
                self.comboPlanType.SelectedIndex = idx
                break
        else:
            if plan_list: self.comboPlanType.SelectedIndex = 0

        self.btnCancel.Click += self.cancel
        self.btnRun.Click += self.run
        self.success = False

    def cancel(self, sender, args):
        self.Close()

    def run(self, sender, args):
        self.params = {
            "cats": {"doors": self.chkDoors.IsChecked, "windows": self.chkWindows.IsChecked, "curtains": self.chkCurtainWalls.IsChecked},
            "mode": "current" if self.radioCurrent.IsChecked else ("manual" if self.radioManual.IsChecked else "auto"),
            "scale": int(self.comboScale.SelectedItem.Tag),
            "elevations": self.chkElevations.IsChecked,
            "plans": self.chkPlans.IsChecked,
            "single": self.radioSingle.IsChecked,
            "prefix": self.txtPrefix.Text,
            "elev_type": self.elev_dict[self.comboElevType.SelectedItem],
            "plan_type": self.plan_dict[self.comboPlanType.SelectedItem]
        }
        self.success = True
        self.Close()

def get_elements(params):
    cat_filters = []
    if params["cats"]["doors"]: cat_filters.append(DB.BuiltInCategory.OST_Doors)
    if params["cats"]["windows"]: cat_filters.append(DB.BuiltInCategory.OST_Windows)
    if params["cats"]["curtains"]: cat_filters.append(DB.BuiltInCategory.OST_Walls)

    if not cat_filters: return []
    mult_cat = DB.ElementMulticategoryFilter(List[DB.BuiltInCategory](cat_filters))
    
    if params["mode"] == "current":
        ids = uidoc.Selection.GetElementIds()
        elements = [doc.GetElement(id) for id in ids]
        return [e for e in elements if e and e.Category and e.Category.Id.IntegerValue in [cat.value__ for cat in cat_filters]]
    
    elif params["mode"] == "manual":
        with forms.WarningBar(title="Select elements for generation"):
            try:
                ids = uidoc.Selection.PickElements(DB.Selection.ObjectType.Element, "Select Doors/Windows")
                return [doc.GetElement(id) for id in ids]
            except: return []
            
    else:
        collector = DB.FilteredElementCollector(doc).WherePasses(mult_cat).WhereElementIsNotElementType()
        return [e for e in collector if (not params["cats"]["curtains"]) or (e.CurtainGrid is not None)]

def main():
    xaml_file = script.get_bundle_file('ui.xaml')
    win = AutoElevWindow(xaml_file)
    win.show_dialog()
    
    if not win.success: return
    
    elements = get_elements(win.params)
    if not elements: return forms.alert("No elements found.")

    # Group by Type
    types_map = {}
    for e in elements:
        t_id = e.GetTypeId()
        if t_id not in types_map: types_map[t_id] = e
    
    with revit.Transaction("Auto Elevation Generator V2"):
        count = 0
        for t_id, rep_elem in types_map.items():
            try:
                symbol = doc.GetElement(t_id)
                t_name = symbol.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString()
                
                # Get Location
                loc = rep_elem.Location
                origin = loc.Point if isinstance(loc, DB.LocationPoint) else loc.Curve.Evaluate(0.5, True)
                facing = rep_elem.FacingOrientation if hasattr(rep_elem, "FacingOrientation") else DB.XYZ.BasisY
                
                # 1. Create Elevation
                if win.params["elevations"]:
                    marker = DB.ElevationMarker.CreateElevationMarker(doc, win.params["elev_type"].Id, origin, win.params["scale"])
                    v_elev = marker.CreateElevation(doc, doc.ActiveView.Id, 1)
                    v_elev.Scale = win.params["scale"]
                    
                    # Naming
                    try: v_elev.Name = "{}{}_Front".format(win.params["prefix"], t_name)
                    except: v_elev.Name = "{}{}_Front_{}".format(win.params["prefix"], t_name, count)
                    
                    # Add "ELEVATION" Label
                    try:
                        text_type = DB.FilteredElementCollector(doc).OfClass(DB.TextNoteType).FirstElement()
                        DB.TextNote.Create(doc, v_elev.Id, DB.XYZ(0,-0.1,0), "ELEVATION", text_type.Id)
                    except: pass

                    count += 1
                    
                # 2. Create Plan (As Detail Section)
                if win.params["plans"]:
                    # Basic plan creation logic here
                    pass
            except: pass
            
    forms.alert("Generation complete! Created views for {} unique types.".format(len(types_map)))

if __name__ == "__main__":
    main()
