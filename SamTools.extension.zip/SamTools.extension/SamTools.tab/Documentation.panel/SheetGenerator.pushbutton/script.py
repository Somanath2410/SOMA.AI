# -*- coding: utf-8 -*-
"""ISO 19650 Visual Orchestrator V6 (Dynamic Sizing)"""

__title__ = 'ISO Sheet'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script
import clr
clr.AddReference('PresentationFramework')
clr.AddReference('PresentationCore')
from System.Windows import Controls, Media, HorizontalAlignment, VerticalAlignment, Thickness, Point
from System.Windows.Shapes import Rectangle
from System.Windows.Controls import Border, TextBlock, Canvas
from System.Windows.Media import RenderOptions
from System.Windows.Interop import RenderMode

doc = revit.doc

class VisualSheetWindow(forms.WPFWindow):
    def __init__(self, xaml_file):
        forms.WPFWindow.__init__(self, xaml_file)
        self.placed_views = {} 
        self.success = False
        
        # Stability
        try: RenderOptions.SetProcessRenderMode(RenderMode.SoftwareOnly)
        except: pass

        # 1. Load Data
        tblocks = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_TitleBlocks).OfClass(DB.FamilySymbol).ToElements()
        self.tb_dict = {}
        for tb in tblocks:
            try:
                name = "{}: {}".format(tb.Family.Name, tb.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString())
                self.tb_dict[name] = tb
            except: pass
        self.comboTitleBlock.ItemsSource = sorted(self.tb_dict.keys())
        if self.tb_dict: self.comboTitleBlock.SelectedIndex = 0
        
        # Load Views
        views = DB.FilteredElementCollector(doc).OfClass(DB.View).ToElements()
        self.v_dict = {v.Name: v for v in views if not v.IsTemplate and hasattr(v, "ViewType") and v.ViewType in [DB.ViewType.FloorPlan, DB.ViewType.Elevation, DB.ViewType.Section, DB.ViewType.ThreeD, DB.ViewType.DraftingView]}
        self.listViews.ItemsSource = sorted(self.v_dict.keys())
        
        # 2. Events
        self.sheetCanvas.MouseLeftButtonUp += self.on_canvas_click
        self.comboTitleBlock.SelectionChanged += self.update_sheet_size
        self.txtProject.TextChanged += self.update_iso
        self.btnClearLayout.Click += self.clear_layout
        self.btnCancel.Click += self.cancel
        self.btnGenerate.Click += self.run
        
        self.update_iso(None, None)
        self.update_sheet_size(None, None)

    def update_sheet_size(self, sender, args):
        # Dynamically resize the white rectangle based on title block name
        sel = self.comboTitleBlock.SelectedItem
        if not sel: return
        
        name = sel.lower()
        # Default A1: 600x400
        w, h = 600, 400
        
        if "a0" in name: w, h = 800, 560
        elif "a1" in name: w, h = 600, 400
        elif "a2" in name: w, h = 420, 300
        elif "a3" in name: w, h = 300, 210
        elif "a4" in name: w, h = 210, 150
        
        self.rectSheet.Width = w
        self.rectSheet.Height = h
        self.set_status("Sheet Resized to match " + sel.split(":")[0])

    def set_status(self, text, color="#636E72"):
        self.txtStatus.Text = " | Status: " + text
        self.txtStatus.Foreground = Media.SolidColorBrush(Media.ColorConverter.ConvertFromString(color))

    def clear_layout(self, sender, args):
        self.placed_views = {}
        self.render_placed_views()
        self.set_status("Layout Cleared")

    def on_canvas_click(self, sender, args):
        sel_name = self.listViews.SelectedItem
        if not sel_name:
            self.set_status("SELECT A VIEW FIRST!", "#D63031")
            return
            
        pos = args.GetPosition(self.sheetCanvas)
        self.placed_views[sel_name] = (pos.X, pos.Y)
        self.render_placed_views()
        self.set_status("Placed: " + sel_name, "#00B894")

    def remove_view(self, sender, args):
        view_name = sender.Tag
        if view_name in self.placed_views:
            del self.placed_views[view_name]
            self.render_placed_views()
            self.set_status("Removed: " + view_name)

    def render_placed_views(self):
        to_remove = [c for c in self.sheetCanvas.Children if isinstance(c, Border)]
        for c in to_remove: self.sheetCanvas.Children.Remove(c)
        
        for name, (x, y) in self.placed_views.items():
            box = Border()
            box.Tag = name
            box.Background = Media.SolidColorBrush(Media.Color.FromRgb(9, 132, 227))
            box.Width = 90
            box.Height = 65
            box.CornerRadius = Media.CornerRadius(4)
            box.Opacity = 0.85
            box.MouseRightButtonDown += self.remove_view
            
            label = TextBlock()
            label.Text = name[:12] + ".." if len(name) > 12 else name
            label.Foreground = Media.Brushes.White
            label.FontSize = 9
            label.HorizontalAlignment = HorizontalAlignment.Center
            label.VerticalAlignment = VerticalAlignment.Center
            box.Child = label
            
            Canvas.SetLeft(box, x - 45)
            Canvas.SetTop(box, y - 32)
            self.sheetCanvas.Children.Add(box)

    def update_iso(self, sender, args):
        try:
            iso = "{}-{}-{}-{}-DR-A-0001".format(
                self.txtProject.Text, self.txtOriginator.Text, self.txtVolume.Text, self.txtLevel.Text
            )
            self.txtPreview.Text = iso.upper()
        except: pass

    def cancel(self, sender, args):
        self.Close()

    def run(self, sender, args):
        if not self.placed_views:
            self.set_status("No views to generate!", "#D63031")
            return
        self.params = {
            "iso": self.txtPreview.Text,
            "name": self.txtSheetName.Text,
            "tb": self.tb_dict[self.comboTitleBlock.SelectedItem],
            "scale": int(self.comboScale.SelectedItem.Tag),
            "placements": {self.v_dict[n]: (x, y) for n, (x, y) in self.placed_views.items()}
        }
        self.success = True
        self.Close()

def main():
    xaml = script.get_bundle_file('ui.xaml')
    win = VisualSheetWindow(xaml)
    win.show_dialog()
    
    if not win.success: return
    
    with revit.Transaction("ISO Visual Sheet Orchestration"):
        try:
            sheet = DB.ViewSheet.Create(doc, win.params["tb"].Id)
            sheet.SheetNumber = win.params["iso"]
            sheet.Name = win.params["name"]
            for view, (cx, cy) in win.params["placements"].items():
                try:
                    view.Scale = win.params["scale"]
                    rx = (cx - 50) / 185.0 
                    ry = (win.rectSheet.Height - (cy - 50)) / 185.0 # Dynamic Flip
                    DB.Viewport.Create(doc, sheet.Id, view.Id, DB.XYZ(rx, ry, 0))
                except: pass
            forms.alert("ISO Sheet Orchestrated Successfully!", title="Success")
        except Exception as e:
            forms.alert("Error: {}".format(e))

if __name__ == '__main__':
    main()
