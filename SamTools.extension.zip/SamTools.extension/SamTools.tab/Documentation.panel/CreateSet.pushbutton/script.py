# -*- coding: utf-8 -*-
"""Create a reusable View/Sheet Set in Revit"""

__title__ = 'Create Set'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script

doc = revit.doc

class CreateSetWindow(forms.WPFWindow):
    def __init__(self, xaml_file):
        forms.WPFWindow.__init__(self, xaml_file)
        
        # Load all views and sheets
        all_views = DB.FilteredElementCollector(doc).OfClass(DB.View).ToElements()
        self.item_dict = {"[{}] {}".format(v.ViewType, v.Name): v for v in all_views if not v.IsTemplate}
        self.listItems.ItemsSource = sorted(self.item_dict.keys())
        
        self.btnCancel.Click += self.cancel
        self.btnSave.Click += self.run_save
        self.success = False

    def cancel(self, sender, args):
        self.Close()
        
    def run_save(self, sender, args):
        self.set_name = self.txtName.Text
        self.selected_items = [self.item_dict[i] for i in self.listItems.SelectedItems]
        
        if not self.set_name:
            forms.alert("Please enter a name for the set.")
            return
        if not self.selected_items:
            forms.alert("Please select at least one view or sheet.")
            return
            
        self.success = True
        self.Close()

def main():
    xaml_file = script.get_bundle_file('ui.xaml')
    win = CreateSetWindow(xaml_file)
    win.show_dialog()
    
    if not win.success: return
    
    with revit.Transaction("SamTools - Create View Set"):
        try:
            # Create ViewSet
            v_set = DB.ViewSet()
            for v in win.selected_items:
                v_set.Insert(v)
            
            # Use PrintManager to save the set
            pm = doc.PrintManager
            pm.PrintRange = DB.PrintRange.Select
            vss = pm.ViewSheetSetting
            vss.CurrentViewSheetSet.Views = v_set
            
            try:
                vss.SaveAs(win.set_name)
                forms.alert("Set '{}' created successfully!".format(win.set_name), title="Success")
            except:
                # If already exists, delete and recreate? Or just ask.
                forms.alert("A set with this name already exists. Please choose a unique name.", title="Duplicate Name")
        except Exception as e:
            forms.alert("Failed to create set: {}".format(str(e)), title="Error")

if __name__ == '__main__':
    main()
