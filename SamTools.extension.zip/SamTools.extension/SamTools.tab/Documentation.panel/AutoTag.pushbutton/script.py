# -*- coding: utf-8 -*-
"""Batch Tag All Elements in View"""

__title__ = 'Auto Tag'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms
from samtools.documentation import TagService

doc = revit.doc


def main():
    if not doc or not doc.ActiveView:
        forms.alert("No active view available.")
        return

    cat_options = ["Doors", "Windows", "Walls", "Rooms"]
    sel_cat = forms.ask_for_one_item(cat_options, default="Doors", title="Select Category to Tag")
    if not sel_cat:
        return

    bic_map = {
        "Doors": DB.BuiltInCategory.OST_Doors,
        "Windows": DB.BuiltInCategory.OST_Windows,
        "Walls": DB.BuiltInCategory.OST_Walls,
        "Rooms": DB.BuiltInCategory.OST_Rooms
    }

    tag_service = TagService(doc)
    count = tag_service.tag_elements_in_view(doc.ActiveView, bic_map[sel_cat])

    if count > 0:
        forms.alert("Successfully tagged {} elements.".format(count), title="Success")
    else:
        forms.alert("No untagged elements found for category {}.".format(sel_cat))


if __name__ == '__main__':
    main()

