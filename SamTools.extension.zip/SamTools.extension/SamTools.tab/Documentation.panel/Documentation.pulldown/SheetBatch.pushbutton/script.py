# -*- coding: utf-8 -*-
"""Batch Create Sheets from List"""

__title__ = 'Batch Sheets'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script

doc = revit.doc

def main():
    # 1. Get Titleblock
    tblocks = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_TitleBlocks).WhereElementIsElementType().ToElements()
    tb_dict = {tb.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString() or tb.Name: tb for tb in tblocks}
    
    class BatchSheetWindow(forms.WPFWindow):
        def __init__(self, xaml_file):
            forms.WPFWindow.__init__(self, xaml_file)
            self.comboTitleblock.ItemsSource = sorted(tb_dict.keys())
            if tblocks: self.comboTitleblock.SelectedIndex = 0
            
            self.btnCancel.Click += self.cancel
            self.btnCreate.Click += self.run_creation
            self.success = False

        def cancel(self, sender, args):
            self.Close()
            
        def run_creation(self, sender, args):
            self.raw_input = self.txtSheetList.Text
            self.sel_tblock = tb_dict[self.comboTitleblock.SelectedItem]
            self.success = True
            self.Close()

    xaml_file = script.get_bundle_file('ui.xaml')
    win = BatchSheetWindow(xaml_file)
    win.show_dialog()
    
    if not win.success: return
    
    raw_input = win.raw_input
    sel_tblock = win.sel_tblock
    
    sheet_data = []
    for line in raw_input.split('\n'):
        if ':' in line:
            parts = line.split(':')
            sheet_data.append((parts[0].strip(), parts[1].strip()))
            
    # 3. Create
    with revit.Transaction("SamTools - Batch Sheets"):
        count = 0
        for num, name in sheet_data:
            try:
                new_sheet = DB.ViewSheet.Create(doc, sel_tblock.Id)
                new_sheet.SheetNumber = num
                new_sheet.Name = name
                count += 1
            except Exception as e:
                print("Error creating sheet {}: {}".format(num, str(e)))
                
    forms.alert("Successfully created {} sheets.".format(count), title="Success")

if __name__ == '__main__':
    main()
