# -*- coding: utf-8 -*-
"""ISO 19650 Visual Orchestrator V2 (Region Packing Update)"""

__title__ = 'ISO Sheet'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script
import clr
clr.AddReference('PresentationFramework')
clr.AddReference('PresentationCore')
from System.Windows import Controls, Media, HorizontalAlignment, VerticalAlignment, Thickness, Point, CornerRadius, Visibility
from System.Windows.Shapes import Rectangle
from System.Windows.Controls import Border, TextBlock, Canvas
from System.Windows.Media import RenderOptions, DoubleCollection
from System.Windows.Interop import RenderMode
from System.Windows.Media.Imaging import BitmapImage, BitmapCacheOption
from System import Uri
import System
import tempfile
import os

doc = revit.doc

def export_sheet_image(doc, sheet):
    opts = DB.ImageExportOptions()
    opts.ExportRange = DB.ExportRange.SetOfViews
    ids = System.Collections.Generic.List[DB.ElementId]()
    ids.Add(sheet.Id)
    opts.SetViewsAndSheets(ids)
    opts.ZoomType = DB.ZoomFitType.FitToPage
    opts.PixelSize = 1024
    opts.ImageResolution = DB.ImageResolution.DPI_72
    opts.FitDirection = DB.FitDirectionType.Horizontal
    opts.HLRandWFViewsFileType = DB.ImageFileType.PNG
    opts.ShadowViewsFileType = DB.ImageFileType.PNG
    opts.ShouldCreateWebSite = False
    
    temp_dir = tempfile.gettempdir()
    base_name = "samtools_sheet_preview"
    opts.FilePath = os.path.join(temp_dir, base_name)
    
    for f in os.listdir(temp_dir):
        if f.startswith(base_name) and f.endswith(".png"):
            try: os.remove(os.path.join(temp_dir, f))
            except: pass
            
    try:
        doc.ExportImage(opts)
        for f in os.listdir(temp_dir):
            if f.startswith(base_name) and f.endswith(".png"):
                return os.path.join(temp_dir, f)
    except:
        pass
    return None

class ViewItem:
    def __init__(self, view):
        self.view = view
        self._name = view.Name
        self._type = view.ViewType.ToString()
        self.is_existing = False
        
    @property
    def Name(self): return self._name
    
    @property
    def ViewType(self): return self._type

class ExistingViewItem:
    def __init__(self, name):
        self.view = None
        self._name = "[Existing] " + name
        self._type = "Viewport"
        self.is_existing = True
        
    @property
    def Name(self): return self._name
    
    @property
    def ViewType(self): return self._type


class VisualSheetWindow(forms.WPFWindow):
    def __init__(self, xaml_file):
        forms.WPFWindow.__init__(self, xaml_file)
        self.placed_views = {} 
        self.success = False
        
        # Interaction state
        self.dragging_box = None
        self.is_drawing_region = False
        self.region_start_pt = None
        self.selection_rect = None
        
        try: RenderOptions.SetProcessRenderMode(RenderMode.SoftwareOnly)
        except: pass

        self.setup_data()
        self.setup_events()
        self.toggle_mode(None, None)
        self.update_iso(None, None)

    def setup_data(self):
        tblocks = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_TitleBlocks).OfClass(DB.FamilySymbol).ToElements()
        self.tb_dict = {}
        for tb in tblocks:
            try:
                name = "{}: {}".format(tb.Family.Name, tb.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString())
                self.tb_dict[name] = tb
            except: pass
        self.comboTitleBlock.ItemsSource = sorted(self.tb_dict.keys())
        if self.tb_dict: self.comboTitleBlock.SelectedIndex = 0
        
        views = DB.FilteredElementCollector(doc).OfClass(DB.View).ToElements()
        templates = [v for v in views if v.IsTemplate]
        self.vt_dict = {v.Name: v for v in templates}
        self.comboViewTemplate.Items.Add("<None>")
        for name in sorted(self.vt_dict.keys()):
            self.comboViewTemplate.Items.Add(name)
        self.comboViewTemplate.SelectedIndex = 0
        
        placed_view_ids = [vp.ViewId.IntegerValue for vp in DB.FilteredElementCollector(doc).OfClass(DB.Viewport).ToElements()]
        
        self.view_items = []
        for v in views:
            if not v.IsTemplate and hasattr(v, "ViewType"):
                if v.ViewType in [DB.ViewType.FloorPlan, DB.ViewType.Elevation, DB.ViewType.Section, DB.ViewType.ThreeD, DB.ViewType.DraftingView]:
                    if v.Id.IntegerValue not in placed_view_ids:
                        self.view_items.append(ViewItem(v))
                        
        self.listViews.ItemsSource = sorted(self.view_items, key=lambda x: x.Name)
        
        self.sheets = DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet).ToElements()
        self.sheet_dict = {"{} - {}".format(s.SheetNumber, s.Name): s for s in self.sheets}
        for name in sorted(self.sheet_dict.keys()):
            self.comboExistingSheet.Items.Add(name)
        if self.comboExistingSheet.Items.Count > 0:
            self.comboExistingSheet.SelectedIndex = 0

    def setup_events(self):
        # Canvas Interaction Events
        self.sheetCanvas.MouseLeftButtonDown += self.on_canvas_mousedown
        self.sheetCanvas.MouseMove += self.on_canvas_mousemove
        self.sheetCanvas.MouseLeftButtonUp += self.on_canvas_mouseup
        
        self.comboTitleBlock.SelectionChanged += self.update_sheet_size
        self.txtProject.TextChanged += self.update_iso
        self.txtOriginator.TextChanged += self.update_iso
        self.txtVolume.TextChanged += self.update_iso
        self.txtLevel.TextChanged += self.update_iso
        self.btnClearCanvas.Click += self.clear_layout
        self.btnCancel.Click += self.cancel
        self.btnGenerate.Click += self.run
        
        self.rbNewSheet.Checked += self.toggle_mode
        self.rbExistingSheet.Checked += self.toggle_mode
        self.comboExistingSheet.SelectionChanged += self.on_sheet_selected
        self.txtSearchTemplate.TextChanged += self.filter_templates
        self.txtSearchViews.TextChanged += self.filter_views

    def filter_views(self, sender, args):
        search_text = self.txtSearchViews.Text.lower()
        if not search_text:
            self.listViews.ItemsSource = sorted(self.view_items, key=lambda x: x.Name)
        else:
            filtered = [v for v in self.view_items if search_text in v.Name.lower() or search_text in v.ViewType.lower()]
            self.listViews.ItemsSource = sorted(filtered, key=lambda x: x.Name)

    def filter_templates(self, sender, args):
        search_text = self.txtSearchTemplate.Text.lower()
        self.comboViewTemplate.Items.Clear()
        self.comboViewTemplate.Items.Add("<None>")
        for name in sorted(self.vt_dict.keys()):
            if search_text in name.lower():
                self.comboViewTemplate.Items.Add(name)
        if self.comboViewTemplate.Items.Count > 0:
            self.comboViewTemplate.SelectedIndex = 0

    def toggle_mode(self, sender, args):
        if self.rbExistingSheet.IsChecked:
            self.panelIso.Visibility = Visibility.Collapsed
            self.panelNewSheet.Visibility = Visibility.Collapsed
            self.panelExisting.Visibility = Visibility.Visible
            self.on_sheet_selected(None, None)
        else:
            self.panelIso.Visibility = Visibility.Visible
            self.panelNewSheet.Visibility = Visibility.Visible
            self.panelExisting.Visibility = Visibility.Collapsed
            self.update_sheet_size(None, None)

    def load_sheet_background(self, sheet):
        img_path = export_sheet_image(doc, sheet)
        if img_path:
            try:
                bmp = BitmapImage()
                bmp.BeginInit()
                bmp.CacheOption = BitmapCacheOption.OnLoad
                bmp.UriSource = Uri(img_path)
                bmp.EndInit()
                brush = Media.ImageBrush(bmp)
                brush.Stretch = Media.Stretch.Uniform
                self.rectSheet.Fill = brush
            except Exception as e:
                self.rectSheet.Fill = Media.Brushes.White
        else:
            self.rectSheet.Fill = Media.Brushes.White

    def on_sheet_selected(self, sender, args):
        if not self.rbExistingSheet.IsChecked: return
        sel = self.comboExistingSheet.SelectedItem
        if not sel: return
        sheet = self.sheet_dict[sel]
        
        tb = DB.FilteredElementCollector(doc, sheet.Id).OfCategory(DB.BuiltInCategory.OST_TitleBlocks).FirstElement()
        w, h = 600, 400
        if tb:
            name = tb.Name.lower()
            if "a0" in name: w, h = 800, 560
            elif "a1" in name: w, h = 600, 400
            elif "a2" in name: w, h = 420, 300
            elif "a3" in name: w, h = 300, 210
            elif "a4" in name: w, h = 210, 150
            
        self.rectSheet.Width = w
        self.rectSheet.Height = h
        self.set_status("Previewing Target Sheet")
        
        self.load_sheet_background(sheet)
        
        self.placed_views = {}
        vps = [doc.GetElement(vp_id) for vp_id in sheet.GetAllViewports()]
        for vp in vps:
            view = doc.GetElement(vp.ViewId)
            center = vp.GetBoxCenter()
            cx = (center.X * 185.0) + 100
            cy = 100 + self.rectSheet.Height - (center.Y * 185.0)
            item = ExistingViewItem(view.Name)
            self.placed_views[item] = {"x": cx, "y": cy, "w": 90, "h": 65}
            
        self.render_views()

    def update_sheet_size(self, sender, args):
        self.rectSheet.Fill = Media.Brushes.White
        sel = self.comboTitleBlock.SelectedItem
        if not sel: return
        
        name = sel.lower()
        w, h = 600, 400
        if "a0" in name: w, h = 800, 560
        elif "a1" in name: w, h = 600, 400
        elif "a2" in name: w, h = 420, 300
        elif "a3" in name: w, h = 300, 210
        elif "a4" in name: w, h = 210, 150
        
        self.rectSheet.Width = w
        self.rectSheet.Height = h
        self.set_status("Sheet Resized to match " + sel.split(":")[0])
        
        tb_sym = self.tb_dict[self.comboTitleBlock.SelectedItem]
        tb_instances = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_TitleBlocks).OfClass(DB.FamilyInstance).ToElements()
        for inst in tb_instances:
            if inst.Symbol.Id == tb_sym.Id:
                example_sheet = doc.GetElement(inst.OwnerViewId)
                if isinstance(example_sheet, DB.ViewSheet):
                    self.load_sheet_background(example_sheet)
                    break

    def set_status(self, text, color="#6B7280"):
        self.txtStatus.Text = text
        self.txtStatus.Foreground = Media.SolidColorBrush(Media.ColorConverter.ConvertFromString(color))

    def clear_layout(self, sender, args):
        self.placed_views = {}
        self.render_views()
        self.set_status("Layout Cleared")

    def get_view_dimensions(self, view):
        try:
            scale = 50 
            if self.comboScale.SelectedItem:
                scale = int(self.comboScale.SelectedItem.Tag)
            box = view.CropBox
            w = (box.Max.X - box.Min.X) * 304.8 / scale * 2.83 
            h = (box.Max.Y - box.Min.Y) * 304.8 / scale * 2.83
            w = max(50, min(w, 600))
            h = max(50, min(h, 400))
            return w, h
        except:
            return 90, 65

    # --- Canvas Drawing & Packing Logic ---

    def on_canvas_mousedown(self, sender, args):
        if self.dragging_box: return
        
        sel_items = self.listViews.SelectedItems
        if not sel_items or sel_items.Count == 0:
            self.set_status("SELECT VIEW(S) FIRST!", "#DC2626")
            return
            
        self.is_drawing_region = True
        self.region_start_pt = args.GetPosition(self.sheetCanvas)
        
        self.selection_rect = Rectangle()
        self.selection_rect.Stroke = Media.SolidColorBrush(Media.Color.FromRgb(37, 99, 235))
        self.selection_rect.StrokeThickness = 2
        dashes = DoubleCollection()
        dashes.Add(4)
        dashes.Add(4)
        self.selection_rect.StrokeDashArray = dashes
        self.selection_rect.Fill = Media.SolidColorBrush(Media.Color.FromArgb(40, 37, 99, 235))
        self.selection_rect.IsHitTestVisible = False
        
        Canvas.SetLeft(self.selection_rect, self.region_start_pt.X)
        Canvas.SetTop(self.selection_rect, self.region_start_pt.Y)
        self.sheetCanvas.Children.Add(self.selection_rect)
        self.sheetCanvas.CaptureMouse()

    def on_canvas_mousemove(self, sender, args):
        if self.dragging_box:
            pos = args.GetPosition(self.sheetCanvas)
            w = self.dragging_box.Width
            h = self.dragging_box.Height
            Canvas.SetLeft(self.dragging_box, pos.X - (w/2))
            Canvas.SetTop(self.dragging_box, pos.Y - (h/2))
            
        elif self.is_drawing_region:
            curr_pt = args.GetPosition(self.sheetCanvas)
            
            x = min(curr_pt.X, self.region_start_pt.X)
            y = min(curr_pt.Y, self.region_start_pt.Y)
            w = abs(curr_pt.X - self.region_start_pt.X)
            h = abs(curr_pt.Y - self.region_start_pt.Y)
            
            Canvas.SetLeft(self.selection_rect, x)
            Canvas.SetTop(self.selection_rect, y)
            self.selection_rect.Width = w
            self.selection_rect.Height = h

    def on_canvas_mouseup(self, sender, args):
        if self.dragging_box:
            self.dragging_box.ReleaseMouseCapture()
            pos = args.GetPosition(self.sheetCanvas)
            vi = self.dragging_box.Tag
            self.placed_views[vi]["x"] = pos.X
            self.placed_views[vi]["y"] = pos.Y
            self.dragging_box = None
            args.Handled = True
            
        elif self.is_drawing_region:
            self.is_drawing_region = False
            self.sheetCanvas.ReleaseMouseCapture()
            self.sheetCanvas.Children.Remove(self.selection_rect)
            
            sel_items = self.listViews.SelectedItems
            
            w = self.selection_rect.Width if self.selection_rect.Width else 0
            h = self.selection_rect.Height if self.selection_rect.Height else 0
            
            if w > 20 and h > 20:
                x = Canvas.GetLeft(self.selection_rect)
                y = Canvas.GetTop(self.selection_rect)
                self.pack_views_into_region(x, y, w, h, sel_items)
            else:
                # If they just clicked without dragging, fallback to old behavior (pile them)
                base_x, base_y = self.region_start_pt.X, self.region_start_pt.Y
                offset = 0
                for vi in sel_items:
                    vw, vh = self.get_view_dimensions(vi.view)
                    self.placed_views[vi] = {"x": base_x + offset, "y": base_y + offset, "w": vw, "h": vh}
                    offset += 20
                self.render_views()
                self.set_status("Placed {} views".format(sel_items.Count), "#10B981")

    def pack_views_into_region(self, start_x, start_y, region_w, region_h, views_to_place):
        margin = 15
        curr_x = start_x + margin
        curr_y = start_y + margin
        row_height = 0
        
        placed_count = 0
        for vi in views_to_place:
            vw, vh = self.get_view_dimensions(vi.view)
            
            # Check if it fits in current row, else wrap
            if curr_x + vw > start_x + region_w and curr_x != start_x + margin:
                curr_x = start_x + margin
                curr_y += row_height + margin
                row_height = 0
                
            # Place (x, y are the center coordinates for rendering)
            center_x = curr_x + (vw / 2.0)
            center_y = curr_y + (vh / 2.0)
            self.placed_views[vi] = {"x": center_x, "y": center_y, "w": vw, "h": vh}
            
            curr_x += vw + margin
            row_height = max(row_height, vh)
            placed_count += 1
            
        self.render_views()
        self.set_status("Auto-Packed {} views into region".format(placed_count), "#10B981")

    # --- View Interaction Logic ---

    def render_views(self):
        to_remove = [c for c in self.sheetCanvas.Children if isinstance(c, Border)]
        for c in to_remove: self.sheetCanvas.Children.Remove(c)
        
        for vi, data in self.placed_views.items():
            box = Border()
            box.Tag = vi
            
            if vi.is_existing:
                box.Background = Media.SolidColorBrush(Media.Color.FromArgb(200, 107, 114, 128))
                box.BorderBrush = Media.SolidColorBrush(Media.Color.FromRgb(75, 85, 99))
            else:
                box.Background = Media.SolidColorBrush(Media.Color.FromArgb(200, 37, 99, 235))
                box.BorderBrush = Media.SolidColorBrush(Media.Color.FromRgb(29, 78, 216))
                
            box.BorderThickness = Thickness(1)
            box.Width = data["w"]
            box.Height = data["h"]
            box.CornerRadius = CornerRadius(4)
            
            box.MouseRightButtonDown += self.remove_view
            box.MouseLeftButtonDown += self.start_drag
            
            label = TextBlock()
            label.Text = vi.Name
            label.Foreground = Media.Brushes.White
            label.FontSize = 10
            label.FontWeight = System.Windows.FontWeights.SemiBold
            label.TextWrapping = System.Windows.TextWrapping.Wrap
            label.HorizontalAlignment = HorizontalAlignment.Center
            label.VerticalAlignment = VerticalAlignment.Center
            label.Margin = Thickness(5)
            box.Child = label
            
            Canvas.SetLeft(box, data["x"] - (data["w"]/2))
            Canvas.SetTop(box, data["y"] - (data["h"]/2))
            self.sheetCanvas.Children.Add(box)

    def remove_view(self, sender, args):
        vi = sender.Tag
        if vi in self.placed_views:
            del self.placed_views[vi]
            self.render_views()
            self.set_status("Removed: " + vi.Name)

    def start_drag(self, sender, args):
        self.dragging_box = sender
        sender.CaptureMouse()
        args.Handled = True

    def update_iso(self, sender, args):
        try:
            iso = "{}-{}-{}-{}-DR-A-0001".format(
                self.txtProject.Text, self.txtOriginator.Text, self.txtVolume.Text, self.txtLevel.Text
            )
            self.txtIsoPreview.Text = iso.upper()
        except: pass

    def cancel(self, sender, args):
        self.Close()

    def run(self, sender, args):
        if not self.placed_views:
            self.set_status("No views to generate!", "#DC2626")
            return
            
        is_existing = self.rbExistingSheet.IsChecked
        target_sheet = self.sheet_dict[self.comboExistingSheet.SelectedItem] if is_existing else None
        
        self.params = {
            "is_existing": is_existing,
            "target_sheet": target_sheet,
            "iso": self.txtIsoPreview.Text,
            "name": self.txtSheetName.Text,
            "tb": self.tb_dict.get(self.comboTitleBlock.SelectedItem),
            "scale": int(self.comboScale.SelectedItem.Tag),
            "template": self.comboViewTemplate.SelectedItem,
            "views": self.placed_views,
            "canvas_h": self.rectSheet.Height
        }
        self.success = True
        self.Close()

def main():
    xaml = script.get_bundle_file('ui.xaml')
    win = VisualSheetWindow(xaml)
    win.show_dialog()
    
    if not win.success: return
    
    with revit.Transaction("ISO Visual Sheet Orchestration V2"):
        try:
            if win.params["is_existing"]:
                sheet = win.params["target_sheet"]
            else:
                sheet = DB.ViewSheet.Create(doc, win.params["tb"].Id)
                sheet.SheetNumber = win.params["iso"]
                sheet.Name = win.params["name"]
            
            error_log = []
            
            for vi, data in win.params["views"].items():
                if vi.is_existing:
                    view_name = vi.Name.replace("[Existing] ", "")
                    for vp_id in sheet.GetAllViewports():
                        vp = doc.GetElement(vp_id)
                        v = doc.GetElement(vp.ViewId)
                        if v.Name == view_name:
                            rx = (data["x"] - 100) / 185.0 
                            ry = (win.params["canvas_h"] - (data["y"] - 100)) / 185.0
                            vp.SetBoxCenter(DB.XYZ(rx, ry, 0))
                            break
                    continue
                
                v = vi.view
                try:
                    template_name = win.params["template"]
                    if template_name != "<None>":
                        vt = win.vt_dict.get(template_name)
                        if vt: v.ViewTemplateId = vt.Id
                    else:
                        if v.ViewType != DB.ViewType.ThreeD:
                            v.Scale = win.params["scale"]
                            
                    rx = (data["x"] - 100) / 185.0 
                    ry = (win.params["canvas_h"] - (data["y"] - 100)) / 185.0
                    
                    if DB.Viewport.CanAddViewToSheet(doc, sheet.Id, v.Id):
                        DB.Viewport.Create(doc, sheet.Id, v.Id, DB.XYZ(rx, ry, 0))
                    else:
                        error_log.append("Skipped (Already on Sheet): " + v.Name)
                except Exception as e:
                    error_log.append("Failed " + v.Name + ": " + str(e))
                    
            if error_log:
                forms.alert("\n".join(error_log), title="Finished with Warnings")
            else:
                forms.alert("ISO Sheet Orchestrated Successfully!", title="Success")
        except Exception as e:
            forms.alert("Fatal Error: {}".format(e))

if __name__ == '__main__':
    main()
