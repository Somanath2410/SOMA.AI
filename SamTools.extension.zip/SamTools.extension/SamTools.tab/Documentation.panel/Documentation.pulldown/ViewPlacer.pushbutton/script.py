# -*- coding: utf-8 -*-
"""Place Active View on Selected Sheet"""

__title__ = 'Place View'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms

doc = revit.doc

def main():
    active_view = doc.ActiveView
    if active_view.ViewType in [DB.ViewType.ProjectBrowser, DB.ViewType.SystemBrowser, DB.ViewType.Internal]:
        forms.alert("Please open a plan, section, or 3D view first.", title="Invalid View")
        return
        
    # Check if already on sheet
    if DB.Viewport.CanAddViewToSheet(doc, DB.ElementId.InvalidElementId, active_view.Id):
        pass # Good
    else:
        forms.alert("This view is already placed on a sheet.", title="Already Placed")
        # return # User might want to try anyway, but Revit API will fail.
    
    # 1. Select Sheet
    sheets = DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet).ToElements()
    sel_sheet = forms.select_sheets()
    if not sel_sheet: return
    
    # 2. Place
    with revit.Transaction("SamTools - Place View"):
        try:
            # Place at center (0,0)
            DB.Viewport.Create(doc, sel_sheet.Id, active_view.Id, DB.XYZ(1.0, 1.0, 0))
            forms.alert("View placed on sheet {}.".format(sel_sheet.SheetNumber), title="Success")
        except Exception as e:
            forms.alert("Failed to place view: {}".format(str(e)), title="Error")

if __name__ == '__main__':
    main()
