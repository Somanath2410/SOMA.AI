# -*- coding: utf-8 -*-
"""Batch Create Sheets from List"""

__title__ = 'Batch Sheets'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script
from samtools.documentation import SheetService

doc = revit.doc


def main():
    tblocks = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_TitleBlocks).WhereElementIsElementType().ToElements()
    tb_dict = {tb.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString() or tb.Name: tb for tb in tblocks}
    
    class BatchSheetWindow(forms.WPFWindow):
        def __init__(self, xaml_file):
            forms.WPFWindow.__init__(self, xaml_file)
            self.comboTitleblock.ItemsSource = sorted(tb_dict.keys())
            if tblocks:
                self.comboTitleblock.SelectedIndex = 0
            
            self.btnCancel.Click += self.cancel
            self.btnCreate.Click += self.run_creation
            self.success = False

        def cancel(self, sender, args):
            self.Close()
            
        def run_creation(self, sender, args):
            self.raw_input = self.txtSheetList.Text
            self.sel_tblock = tb_dict[self.comboTitleblock.SelectedItem]
            self.success = True
            self.Close()

    xaml_file = script.get_bundle_file('ui.xaml')
    win = BatchSheetWindow(xaml_file)
    win.show_dialog()
    
    if not win.success:
        return
    
    sheet_data = []
    for line in win.raw_input.split('\n'):
        if ':' in line:
            parts = line.split(':')
            sheet_data.append({"number": parts[0].strip(), "name": parts[1].strip()})
            
    sheet_service = SheetService(doc)
    created_sheets = sheet_service.batch_create_sheets(sheet_data)
    
    forms.alert("Successfully created {} sheets.".format(len(created_sheets)), title="Success")


if __name__ == '__main__':
    main()

