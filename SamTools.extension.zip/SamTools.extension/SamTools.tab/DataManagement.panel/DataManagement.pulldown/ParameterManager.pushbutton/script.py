# -*- coding: utf-8 -*-
"""Analyze Parameters of Selected Elements"""

__title__ = 'Parameter\nManager'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script

doc = revit.doc
output = script.get_output()

def main():
    selection = revit.get_selection()
    if not selection:
        forms.alert("Please select an element to analyze parameters.")
        return
        
    el = selection[0]
    output.print_md("# Parameters for: {} (ID: {})".format(el.Name, el.Id))
    
    # Instance Parameters
    output.print_md("### Instance Parameters")
    for p in el.Parameters:
        try:
            val = p.AsValueString() or p.AsString() or str(p.AsDouble())
            print("{}: {}".format(p.Definition.Name, val))
        except: pass
        
    # Type Parameters
    try:
        el_type = doc.GetElement(el.GetTypeId())
        if el_type:
            output.print_md("### Type Parameters")
            for p in el_type.Parameters:
                try:
                    val = p.AsValueString() or p.AsString() or str(p.AsDouble())
                    print("{}: {}".format(p.Definition.Name, val))
                except: pass
    except: pass

if __name__ == '__main__':
    main()
