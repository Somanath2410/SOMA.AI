# -*- coding: utf-8 -*-
"""Update Parameters.

Modify existing parameters in bulk by searching for an old value and replacing it with a new value.
Leave 'Old Value' blank to update empty parameters.
"""
__title__ = "Update\nParameters"
__author__ = "SamTools"

import wpf
from System.Windows import Window
from pyrevit import revit, DB
from pyrevit import forms

class UpdateParamWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.doc = revit.doc
        self.populate_categories()

    def populate_categories(self):
        model_categories = [c for c in self.doc.Settings.Categories if c.CategoryType == DB.CategoryType.Model and c.AllowsBoundParameters]
        self.model_category_list = sorted(model_categories, key=lambda x: x.Name)
        self.CategoryCombo.ItemsSource = self.model_category_list
        if self.model_category_list:
            self.CategoryCombo.SelectedIndex = 0

    def log_msg(self, msg):
        current_text = self.LogTextBox.Text
        if current_text == "System Initialized. Awaiting user input.":
            self.LogTextBox.Text = "> " + msg
        else:
            self.LogTextBox.Text = current_text + "\n> " + msg
        self.LogScroll.ScrollToEnd()
        
    def Cancel_Click(self, sender, e):
        self.Close()

    def Run_Click(self, sender, e):
        selected_cat = self.CategoryCombo.SelectedItem
        param_name = self.ParamNameTextBox.Text
        old_value = self.OldValueTextBox.Text
        new_value = self.NewValueTextBox.Text

        if not selected_cat:
            self.log_msg("Error: No category selected.")
            return
        if not param_name:
            self.log_msg("Error: Parameter name cannot be empty.")
            return

        cat_id = selected_cat.Id
        elements = DB.FilteredElementCollector(self.doc).WhereElementIsNotElementType().OfCategoryId(cat_id).ToElements()

        if not elements:
            self.log_msg("No elements found for category: {}".format(selected_cat.Name))
            return

        updated_count = 0
        missing_param_count = 0
        readonly_param_count = 0
        type_mismatch_count = 0
        no_match_count = 0

        self.log_msg("Scanning {} elements...".format(len(elements)))
        
        with revit.Transaction("Update Parameter: {}".format(param_name)):
            for el in elements:
                param = el.LookupParameter(param_name)
                if param:
                    current_val_str = ""
                    if param.StorageType == DB.StorageType.String:
                        current_val_str = param.AsString() or ""
                    elif param.StorageType == DB.StorageType.Integer:
                        current_val_str = str(param.AsInteger())
                    elif param.StorageType == DB.StorageType.Double:
                        current_val_str = str(param.AsDouble())

                    if current_val_str == old_value:
                        if not param.IsReadOnly:
                            try:
                                param.Set(new_value)
                                updated_count += 1
                            except Exception:
                                type_mismatch_count += 1
                        else:
                            readonly_param_count += 1
                    else:
                        no_match_count += 1
                else:
                    missing_param_count += 1

        self.log_msg("Successfully updated {} element(s).".format(updated_count))
        if missing_param_count > 0:
            self.log_msg("- Parameter '{}' not found on {} element(s).".format(param_name, missing_param_count))
        if readonly_param_count > 0:
            self.log_msg("- Parameter is read-only on {} element(s).".format(readonly_param_count))
        if type_mismatch_count > 0:
            self.log_msg("- Failed to set value on {} element(s).".format(type_mismatch_count))
        if no_match_count > 0:
            self.log_msg("- {} element(s) did not match the old value.".format(no_match_count))
        self.log_msg("Automation Complete.")

def main():
    UpdateParamWindow("ui.xaml").show_dialog()

if __name__ == '__main__':
    main()
