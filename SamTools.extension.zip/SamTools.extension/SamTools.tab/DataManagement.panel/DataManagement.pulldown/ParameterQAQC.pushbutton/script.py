# -*- coding: utf-8 -*-
"""Parameter QA/QC.

Find elements of a selected category that have missing or empty values for a specific parameter.
Displays the results in a list with clickable element IDs.
"""
__title__ = "Parameter\nQA/QC"
__author__ = "SamTools"

import wpf
from System.Windows import Window
from pyrevit import revit, DB
from pyrevit import forms

class ParameterQAQCWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.doc = revit.doc
        self.populate_categories()

    def populate_categories(self):
        model_categories = [c for c in self.doc.Settings.Categories if c.CategoryType == DB.CategoryType.Model and c.AllowsBoundParameters]
        self.model_category_list = sorted(model_categories, key=lambda x: x.Name)
        self.CategoryCombo.ItemsSource = self.model_category_list
        if self.model_category_list:
            self.CategoryCombo.SelectedIndex = 0

    def log_msg(self, msg):
        current_text = self.LogTextBox.Text
        if current_text == "System Initialized. Awaiting user input.":
            self.LogTextBox.Text = "> " + msg
        else:
            self.LogTextBox.Text = current_text + "\n> " + msg
        self.LogScroll.ScrollToEnd()
        
    def Cancel_Click(self, sender, e):
        self.Close()

    def Run_Click(self, sender, e):
        selected_cat = self.CategoryCombo.SelectedItem
        param_name = self.ParamNameTextBox.Text

        if not selected_cat:
            self.log_msg("Error: No category selected.")
            return
        if not param_name:
            self.log_msg("Error: Parameter name cannot be empty.")
            return

        cat_id = selected_cat.Id
        elements = DB.FilteredElementCollector(self.doc).WhereElementIsNotElementType().OfCategoryId(cat_id).ToElements()

        if not elements:
            self.log_msg("No elements found for category: {}".format(selected_cat.Name))
            return

        problem_elements = []
        self.log_msg("Scanning {} elements...".format(len(elements)))

        for el in elements:
            param = el.LookupParameter(param_name)
            if not param:
                problem_elements.append((el, "Parameter not found"))
            else:
                has_value = param.HasValue
                if not has_value:
                    problem_elements.append((el, "Value is empty/null"))
                else:
                    if param.StorageType == DB.StorageType.String:
                        val = param.AsString()
                        if val is None or val.strip() == "":
                            problem_elements.append((el, "String is empty"))

        if not problem_elements:
            self.log_msg("SUCCESS: All elements have a valid value for '{}'.".format(param_name))
        else:
            self.log_msg("FAILED: Found {} element(s) with missing or empty values.".format(len(problem_elements)))
            for el, issue in problem_elements:
                self.log_msg("Element ID: {} | Issue: {}".format(el.Id.IntegerValue, issue))
            
            self.log_msg("Audit Complete. Review the IDs above.")

def main():
    ParameterQAQCWindow("ui.xaml").show_dialog()

if __name__ == '__main__':
    main()
