# -*- coding: utf-8 -*-
"""Assign Parameters.

Assigns a specific parameter value to all elements of a selected category
or manually selected elements. Can optionally create the parameter if missing.
"""
__title__ = "Assign\nParameters"
__author__ = "SamTools"

import os
import tempfile
import wpf
from System.Windows import Window
from pyrevit import revit, DB
from pyrevit import forms

class AssignParamWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.doc = revit.doc
        self.uidoc = revit.uidoc
        
        # Check current selection
        self.selected_ids = list(self.uidoc.Selection.GetElementIds())
        if self.selected_ids:
            self.RadioSelected.Content = "Use Pre-Selected Elements ({} selected)".format(len(self.selected_ids))
            self.RadioSelected.IsChecked = True
        else:
            self.RadioSelected.Content = "Use Pre-Selected Elements (0 selected)"

        self.populate_categories()
        
        # Populate Data Types
        self.DataTypeCombo.ItemsSource = ["Text", "Integer", "Number", "Length", "YesNo"]
        self.DataTypeCombo.SelectedIndex = 0

    def populate_categories(self):
        model_categories = [c for c in self.doc.Settings.Categories if c.CategoryType == DB.CategoryType.Model and c.AllowsBoundParameters]
        self.model_category_list = sorted(model_categories, key=lambda x: x.Name)
        self.CategoryCombo.ItemsSource = self.model_category_list
        if self.model_category_list:
            self.CategoryCombo.SelectedIndex = 0

    def CreateParam_Click(self, sender, e):
        self.CreationOptionsPanel.IsEnabled = self.CreateParamCheckBox.IsChecked

    def PickElements_Click(self, sender, e):
        self.Hide()
        try:
            from pyrevit import UI
            references = self.uidoc.Selection.PickObjects(UI.Selection.ObjectType.Element, "Select elements in Revit. Click Finish on the Options Bar when done.")
            if references:
                self.selected_ids = [ref.ElementId for ref in references]
                self.RadioSelected.Content = "Use Picked Elements ({} selected)".format(len(self.selected_ids))
                self.RadioSelected.IsChecked = True
                self.log_msg("Picked {} elements from model.".format(len(self.selected_ids)))
        except Exception:
            self.log_msg("Element selection cancelled.")
        self.Show()

    def log_msg(self, msg):
        current_text = self.LogTextBox.Text
        if current_text == "System Initialized. Awaiting user input.":
            self.LogTextBox.Text = "> " + msg
        else:
            self.LogTextBox.Text = current_text + "\n> " + msg
        self.LogScroll.ScrollToEnd()
        
    def Cancel_Click(self, sender, e):
        self.Close()

    def create_shared_parameter(self, param_name, data_type_str, is_instance, category_id):
        app = self.doc.Application
        original_file = app.SharedParametersFilename
        
        sp_file = app.OpenSharedParameterFile()
        if not sp_file:
            temp_sp_path = os.path.join(tempfile.gettempdir(), "SamTools_SharedParams.txt")
            if not os.path.exists(temp_sp_path):
                with open(temp_sp_path, 'w') as f:
                    f.write("# This is a Revit shared parameter file.\n")
                    f.write("*META\tVERSION\tMINVERSION\n")
                    f.write("META\t2\t1\n")
                    f.write("*GROUP\tID\tNAME\n")
                    f.write("GROUP\t1\tSamToolsGroup\n")
                    f.write("*PARAM\tGUID\tNAME\tDATATYPE\tDATACATEGORY\tGROUP\tVISIBLE\tDESCRIPTION\tUSERMODIFIABLE\tHIDEWHENNOVALUE\n")
            try:
                app.SharedParametersFilename = temp_sp_path
                sp_file = app.OpenSharedParameterFile()
            except Exception as ex:
                self.log_msg("Failed to set Shared Parameters file: {}".format(ex))
                return False
            
        if not sp_file:
            self.log_msg("Could not access or create Shared Parameter file.")
            return False
            
        group = sp_file.Groups.get_Item("SamToolsGroup")
        if not group:
            group = sp_file.Groups.Create("SamToolsGroup")
            
        definition = group.Definitions.get_Item(param_name)
        if not definition:
            if hasattr(DB, 'SpecTypeId'):
                param_type = DB.SpecTypeId.String.Text
                if data_type_str == "Integer": param_type = DB.SpecTypeId.Int.Integer
                elif data_type_str == "Number": param_type = DB.SpecTypeId.Number
                elif data_type_str == "Length": param_type = DB.SpecTypeId.Length
                elif data_type_str == "YesNo": param_type = DB.SpecTypeId.Boolean.YesNo
            else:
                param_type = DB.ParameterType.Text
                if data_type_str == "Integer": param_type = DB.ParameterType.Integer
                elif data_type_str == "Number": param_type = DB.ParameterType.Number
                elif data_type_str == "Length": param_type = DB.ParameterType.Length
                elif data_type_str == "YesNo": param_type = DB.ParameterType.YesNo
            
            # Use reflection/try-except to handle Revit version differences for creation options
            try:
                opt = DB.ExternalDefinitionCreationOptions(param_name, param_type)
                definition = group.Definitions.Create(opt)
            except Exception as ex:
                self.log_msg("Failed to create definition. Revit version mismatch? Error: {}".format(ex))
                return False
            
        category_set = app.Create.NewCategorySet()
        cat = self.doc.Settings.Categories.get_Item(category_id)
        if cat:
            category_set.Insert(cat)
            
        if is_instance:
            binding = app.Create.NewInstanceBinding(category_set)
        else:
            binding = app.Create.NewTypeBinding(category_set)
            
        # Try to insert
        if self.doc.ParameterBindings.Contains(definition):
            # Already bound, maybe we need to re-insert or it's fine
            success = self.doc.ParameterBindings.ReInsert(definition, binding, DB.BuiltInParameterGroup.PG_DATA)
        else:
            success = self.doc.ParameterBindings.Insert(definition, binding, DB.BuiltInParameterGroup.PG_DATA)
        
        # Restore original file if we changed it
        if original_file and app.SharedParametersFilename != original_file:
            try:
                app.SharedParametersFilename = original_file
            except:
                pass
            
        return success

    def Run_Click(self, sender, e):
        param_name = self.ParamNameTextBox.Text
        param_value = self.ParamValueTextBox.Text

        if not param_name:
            self.log_msg("Error: Parameter name cannot be empty.")
            return

        elements = []
        cat_id = None

        if self.RadioCategory.IsChecked:
            selected_cat = self.CategoryCombo.SelectedItem
            if not selected_cat:
                self.log_msg("Error: No category selected.")
                return
            cat_id = selected_cat.Id
            elements = DB.FilteredElementCollector(self.doc).WhereElementIsNotElementType().OfCategoryId(cat_id).ToElements()
        else:
            if not self.selected_ids:
                self.log_msg("Error: No elements are pre-selected in Revit.")
                return
            for eid in self.selected_ids:
                el = self.doc.GetElement(eid)
                if el:
                    elements.append(el)
                    if not cat_id:
                        cat_id = el.Category.Id # Grab the category of the first element for binding purposes

        if not elements:
            self.log_msg("No target elements found.")
            return

        # Parameter Creation Logic
        create_if_missing = self.CreateParamCheckBox.IsChecked
        if create_if_missing and cat_id:
            is_instance = self.RadioInstance.IsChecked
            data_type_str = self.DataTypeCombo.SelectedItem
            
            with revit.Transaction("Create Parameter: {}".format(param_name)):
                self.log_msg("Attempting to create parameter '{}'...".format(param_name))
                success = self.create_shared_parameter(param_name, data_type_str, is_instance, cat_id)
                if success:
                    self.doc.Regenerate()
                    self.log_msg("Successfully created/bound parameter.")
                else:
                    self.log_msg("Parameter creation failed or it was already bound.")

        updated_count = 0
        missing_param_count = 0
        readonly_param_count = 0
        type_mismatch_count = 0

        self.log_msg("Assigning values for {} elements...".format(len(elements)))
        
        with revit.Transaction("Assign Parameter: {}".format(param_name)):
            for el in elements:
                # Re-fetch element to ensure its parameter map is up-to-date
                el = self.doc.GetElement(el.Id)
                
                # If Type parameter, we need to get the ElementType
                param = el.LookupParameter(param_name)
                if not param:
                    # Check Type
                    el_type = self.doc.GetElement(el.GetTypeId())
                    if el_type:
                        param = el_type.LookupParameter(param_name)
                
                if param:
                    if not param.IsReadOnly:
                        try:
                            # Parse value based on type
                            val_to_set = param_value
                            if param.StorageType == DB.StorageType.Integer:
                                val_str = str(param_value).strip().lower()
                                if val_str in ['yes', 'true', '1']:
                                    val_to_set = 1
                                elif val_str in ['no', 'false', '0', '']:
                                    val_to_set = 0
                                else:
                                    val_to_set = int(param_value) if param_value else 0
                            elif param.StorageType == DB.StorageType.Double:
                                val_to_set = float(param_value) if param_value else 0.0
                                
                            param.Set(val_to_set)
                            updated_count += 1
                        except Exception:
                            type_mismatch_count += 1
                    else:
                        readonly_param_count += 1
                else:
                    missing_param_count += 1

        self.log_msg("Successfully updated {} element(s).".format(updated_count))
        if missing_param_count > 0:
            self.log_msg("- Parameter '{}' not found on {} element(s).".format(param_name, missing_param_count))
        if readonly_param_count > 0:
            self.log_msg("- Parameter is read-only on {} element(s).".format(readonly_param_count))
        if type_mismatch_count > 0:
            self.log_msg("- Failed to set value (type mismatch) on {} element(s).".format(type_mismatch_count))
        self.log_msg("Automation Complete.")

def main():
    AssignParamWindow("ui.xaml").show_dialog()

if __name__ == '__main__':
    main()
