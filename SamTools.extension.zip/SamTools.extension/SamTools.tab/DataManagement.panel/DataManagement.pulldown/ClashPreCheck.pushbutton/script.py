# -*- coding: utf-8 -*-
"""Clash Pre-check.

Detect intersections between two selected categories and list clashing elements.
"""
__title__ = "Clash\nPre-check"
__author__ = "SamTools"

import wpf
from System.Windows import Window
from pyrevit import revit, DB
from pyrevit import forms

class ClashPreCheckWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.doc = revit.doc
        self.populate_categories()

    def populate_categories(self):
        model_categories = [c for c in self.doc.Settings.Categories if c.CategoryType == DB.CategoryType.Model and c.HasMaterialQuantities]
        self.model_category_list = sorted(model_categories, key=lambda x: x.Name)
        
        self.CategoryACombo.ItemsSource = self.model_category_list
        self.CategoryBCombo.ItemsSource = self.model_category_list
        
        if self.model_category_list:
            self.CategoryACombo.SelectedIndex = 0
            self.CategoryBCombo.SelectedIndex = 0

    def log_msg(self, msg):
        current_text = self.LogTextBox.Text
        if current_text == "System Initialized. Awaiting user input.":
            self.LogTextBox.Text = "> " + msg
        else:
            self.LogTextBox.Text = current_text + "\n> " + msg
        self.LogScroll.ScrollToEnd()
        
    def Cancel_Click(self, sender, e):
        self.Close()

    def Run_Click(self, sender, e):
        cat_a = self.CategoryACombo.SelectedItem
        cat_b = self.CategoryBCombo.SelectedItem

        if not cat_a or not cat_b:
            self.log_msg("Error: Select both categories.")
            return

        cat_a_id = cat_a.Id
        cat_b_id = cat_b.Id

        elements_a = DB.FilteredElementCollector(self.doc).WhereElementIsNotElementType().OfCategoryId(cat_a_id).ToElements()
        if not elements_a:
            self.log_msg("No elements found for Category A.")
            return

        elements_b_test = DB.FilteredElementCollector(self.doc).WhereElementIsNotElementType().OfCategoryId(cat_b_id).ToElements()
        if not elements_b_test:
            self.log_msg("No elements found for Category B.")
            return

        clashes = []
        self.log_msg("Checking {} elements for clashes...".format(len(elements_a)))

        for idx, el_a in enumerate(elements_a):
            try:
                intersect_filter = DB.ElementIntersectsElementFilter(el_a)
                clashing_elements_b = DB.FilteredElementCollector(self.doc) \
                                        .WhereElementIsNotElementType() \
                                        .OfCategoryId(cat_b_id) \
                                        .WherePasses(intersect_filter) \
                                        .ToElements()
                
                for el_b in clashing_elements_b:
                    clashes.append((el_a, el_b))
            except Exception:
                pass

        if clashes:
            self.log_msg("Found {} clash pair(s).".format(len(clashes)))
            for el_a, el_b in clashes:
                self.log_msg("- 💥 Clash: A ({}) intersects B ({})".format(el_a.Id.IntegerValue, el_b.Id.IntegerValue))
        else:
            self.log_msg("No clashes found between these categories.")
        
        self.log_msg("Clash check complete.")

def main():
    ClashPreCheckWindow("ui.xaml").show_dialog()

if __name__ == '__main__':
    main()
