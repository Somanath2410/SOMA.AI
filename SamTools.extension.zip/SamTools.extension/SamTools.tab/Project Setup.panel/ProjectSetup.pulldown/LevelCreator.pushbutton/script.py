# -*- coding: utf-8 -*-
"""Batch Create Levels from Elevation List"""

__title__ = 'Batch Levels'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script

doc = revit.doc

class LevelWindow(forms.WPFWindow):
    def __init__(self, xaml_file):
        forms.WPFWindow.__init__(self, xaml_file)
        self.btnCancel.Click += self.cancel
        self.btnCreate.Click += self.run_creation
        self.success = False

    def cancel(self, sender, args):
        self.Close()
        
    def run_creation(self, sender, args):
        self.raw_input = self.txtLevelList.Text
        self.success = True
        self.Close()

def main():
    xaml_file = script.get_bundle_file('ui.xaml')
    win = LevelWindow(xaml_file)
    win.show_dialog()
    
    if not win.success: return
    raw_input = win.raw_input
    
    level_data = []
    for line in raw_input.split('\n'):
        if ':' in line:
            parts = line.split(':')
            # mm to feet conversion (approx 304.8)
            elev_ft = float(parts[0].strip()) / 304.8
            level_data.append((elev_ft, parts[1].strip()))
            
    with revit.Transaction("SamTools - Batch Levels"):
        count = 0
        for elev, name in level_data:
            try:
                new_lvl = DB.Level.Create(doc, elev)
                new_lvl.Name = name
                count += 1
            except: pass
            
    forms.alert("Successfully created {} levels.".format(count), title="Success")

if __name__ == '__main__':
    main()
