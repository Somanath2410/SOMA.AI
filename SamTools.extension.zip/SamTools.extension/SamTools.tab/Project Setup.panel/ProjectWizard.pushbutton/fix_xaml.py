import os

folder = r"C:\Users\somnath.misal\AppData\Roaming\pyRevit\Extensions\SamTools.extension\SamTools.tab\Project Setup.panel\ProjectWizard.pushbutton"
target = """                <Button.Resources>
                    <Style TargetType="Border">
                        <Setter Property="CornerRadius" Value="6"/>
                    </Style>
                </Button.Resources>"""

for f in os.listdir(folder):
    if f.endswith("_dialog.xaml"):
        path = os.path.join(folder, f)
        with open(path, "r", encoding="utf-8") as file:
            content = file.read()
        
        # Replace varying indentation by just stripping all spaces for the targeted lines
        # Actually it's easier to use regex
        import re
        new_content = re.sub(r'\s*<Button\.Resources>\s*<Style TargetType="Border">\s*<Setter Property="CornerRadius" Value="6"/>\s*</Style>\s*</Button\.Resources>', "", content)
        
        with open(path, "w", encoding="utf-8") as file:
            file.write(new_content)
        print("Updated", f)
