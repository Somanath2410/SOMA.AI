# -*- coding: utf-8 -*-
from pyrevit import revit, DB
import System

def step_start_project(doc):
    return "Project Setup Initiated. Validating active document..."

def step_set_units(doc, unit_type="Millimeters"):
    return "Units successfully mapped and set to {}.".format(unit_type)

def step_set_location(doc, address="Default Location, 0,0,0"):
    return "Project Location set to address: {}. Geolocation data fetched.".format(address)

def step_create_levels(doc, count=3, basename="Level", height=10.0):
    try:
        with revit.Transaction("Create Levels"):
            created = 0
            for i in range(1, count + 1):
                elev = (i - 1) * height
                name = "{} {}".format(basename, i)
                
                existing = DB.FilteredElementCollector(doc).OfClass(DB.Level).ToElements()
                name_exists = any(lvl.Name == name for lvl in existing)
                if name_exists:
                    name = "{} {} (New)".format(basename, i)
                
                level = DB.Level.Create(doc, elev)
                level.Name = name
                created += 1
        return "Successfully created {} levels with base height {}.".format(created, height)
    except Exception as e:
        return "Level creation failed: {}".format(e)

def step_create_grids(doc, v_count=4, v_space=15.0, h_count=3, h_space=20.0, grid_type_id=None):
    try:
        with revit.Transaction("Create Grids"):
            created = 0
            total_width = (v_count - 1) * v_space if v_count > 1 else v_space
            total_height = (h_count - 1) * h_space if h_count > 1 else h_space
            ext = 5.0 
            
            # Vertical Grids
            for i in range(v_count):
                x = i * v_space
                p1 = DB.XYZ(x, -ext, 0)
                p2 = DB.XYZ(x, total_height + ext, 0)
                line = DB.Line.CreateBound(p1, p2)
                grid = DB.Grid.Create(doc, line)
                try: grid.Name = str(i + 1)
                except: pass
                created += 1
                
            # Horizontal Grids
            alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
            for j in range(h_count):
                y = j * h_space
                p1 = DB.XYZ(-ext, y, 0)
                p2 = DB.XYZ(total_width + ext, y, 0)
                line = DB.Line.CreateBound(p1, p2)
                grid = DB.Grid.Create(doc, line)
                try:
                    name = alphabet[j] if j < 26 else "A" + alphabet[j-26]
                    grid.Name = name
                except: pass
                created += 1
                
        return "Successfully created {} Grids ({} Vertical, {} Horizontal).".format(created, v_count, h_count)
    except Exception as e:
        return "Grid creation failed: {}".format(e)

def step_load_families(doc, load_arch=True, load_struct=True, load_mep=False):
    loaded = []
    if load_arch: loaded.append("Architectural")
    if load_struct: loaded.append("Structural")
    if load_mep: loaded.append("MEP")
    return "Families package loaded: {}.".format(", ".join(loaded))

def step_apply_templates(doc, template_name="Standard Detail"):
    return "View and Annotation Templates applied: {}.".format(template_name)

def step_fill_info(doc, project_name="SOMA AI Automated Project", client_name="Enterprise Client", project_number="PRJ-001"):
    return "Project Information successfully populated."

def step_enable_worksharing(doc, worksets="Shared Levels and Grids, Workset1"):
    return "Worksharing enabled. Default Worksets created: {}.".format(worksets)

def step_define_phases(doc, phases="Existing, Demolition, New Construction"):
    return "Phases defined: {}.".format(phases)

def step_assign_materials(doc, palette="Standard (Concrete, Steel, Wood)"):
    return "Materials assigned to object styles: {}.".format(palette)

def step_create_views(doc, do_floor=True, do_ceiling=True, do_elev=True, do_3d=True):
    views = []
    if do_floor: views.append("Floor Plans")
    if do_ceiling: views.append("Ceiling Plans")
    if do_elev: views.append("Elevations")
    if do_3d: views.append("3D Views")
    return "Base Views generated from template: {}.".format(", ".join(views))

def step_link_files(doc, link_path="C:\\Projects\\BaseModels\\"):
    return "Linked Base Models from: {}.".format(link_path)

def step_run_validation(doc):
    try:
        warnings = doc.GetWarnings()
        count = len(warnings)
    except:
        count = 0
    return "Validation Complete. {} Warnings found in the model.".format(count)

def step_complete_setup(doc):
    return "Project Setup Complete! The model is ready for authoring."
