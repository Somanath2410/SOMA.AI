# -*- coding: utf-8 -*-
"""Project Setup Wizard"""

__title__ = 'Setup\nWizard'
__author__ = 'SamTools'

import System
import clr
clr.AddReference("PresentationFramework")
clr.AddReference("PresentationCore")
clr.AddReference("WindowsBase")
from System.Windows import Thickness, HorizontalAlignment, CornerRadius
from System.Windows.Controls import Border, TextBlock
from System.Windows.Media import SolidColorBrush, ColorConverter

from pyrevit import revit, DB, forms, script
import setup_logic

class LevelCreatorDialog(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.btnCancel.Click += self.close_dialog
        self.btnCreate.Click += self.create_levels
        self.is_ok = False
        
    def close_dialog(self, sender, args):
        self.Close()
        
    def create_levels(self, sender, args):
        self.is_ok = True
        self.Close()

from System.Windows.Shapes import Line
from System.Windows.Media import Brushes

class GridCreatorDialog(forms.WPFWindow):
    def __init__(self, xaml_file_name, doc):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.doc = doc
        self.btnCancel.Click += self.close_dialog
        self.btnCreate.Click += self.create_grids
        self.is_ok = False
        
    def close_dialog(self, sender, args):
        self.Close()
        
    def create_grids(self, sender, args):
        self.is_ok = True
        self.Close()

class StartSetupDialog(forms.WPFWindow):
    def __init__(self, xaml):
        forms.WPFWindow.__init__(self, xaml)
        self.btnCancel.Click += self.close_dialog
        self.btnCreate.Click += self.create_action
        self.is_ok = False
    def close_dialog(self, s, e): self.Close()
    def create_action(self, s, e):
        self.is_ok = True
        self.Close()

class UnitsDialog(forms.WPFWindow):
    def __init__(self, xaml):
        forms.WPFWindow.__init__(self, xaml)
        self.btnCancel.Click += self.close_dialog
        self.btnCreate.Click += self.create_action
        self.is_ok = False
        self.unit_type = "Millimeters"
    def close_dialog(self, s, e): self.Close()
    def create_action(self, s, e):
        self.unit_type = getattr(self, "cmbLength", None) and self.cmbLength.Text or "Millimeters"
        self.is_ok = True
        self.Close()

class LocationDialog(forms.WPFWindow):
    def __init__(self, xaml):
        forms.WPFWindow.__init__(self, xaml)
        self.btnCancel.Click += self.close_dialog
        self.btnCreate.Click += self.create_action
        self.is_ok = False
        self.address = ""
    def close_dialog(self, s, e): self.Close()
    def create_action(self, s, e):
        self.address = getattr(self, "txtAddress", None) and self.txtAddress.Text or "123 Innovation Drive"
        self.is_ok = True
        self.Close()

class FamiliesDialog(forms.WPFWindow):
    def __init__(self, xaml):
        forms.WPFWindow.__init__(self, xaml)
        self.btnCancel.Click += self.close_dialog
        self.btnCreate.Click += self.create_action
        self.is_ok = False
        self.arch = True
        self.struct = True
        self.mep = False
    def close_dialog(self, s, e): self.Close()
    def create_action(self, s, e):
        self.arch = self.chkArch.IsChecked
        self.struct = self.chkStruct.IsChecked
        self.mep = self.chkMep.IsChecked
        self.is_ok = True
        self.Close()

class TemplatesDialog(forms.WPFWindow):
    def __init__(self, xaml):
        forms.WPFWindow.__init__(self, xaml)
        self.btnCancel.Click += self.close_dialog
        self.btnCreate.Click += self.create_action
        self.is_ok = False
        self.template = ""
    def close_dialog(self, s, e): self.Close()
    def create_action(self, s, e):
        self.template = "Standard"
        self.is_ok = True
        self.Close()

class InfoDialog(forms.WPFWindow):
    def __init__(self, xaml):
        forms.WPFWindow.__init__(self, xaml)
        self.btnCancel.Click += self.close_dialog
        self.btnCreate.Click += self.create_action
        self.is_ok = False
        self.proj_name = ""
        self.client_name = ""
        self.proj_num = ""
    def close_dialog(self, s, e): self.Close()
    def create_action(self, s, e):
        self.proj_name = self.txtProjectName.Text
        self.client_name = self.txtClientName.Text
        self.proj_num = self.txtProjectNumber.Text
        self.is_ok = True
        self.Close()

class WorksharingDialog(forms.WPFWindow):
    def __init__(self, xaml):
        forms.WPFWindow.__init__(self, xaml)
        self.btnCancel.Click += self.close_dialog
        self.btnCreate.Click += self.create_action
        self.is_ok = False
        self.worksets = ""
    def close_dialog(self, s, e): self.Close()
    def create_action(self, s, e):
        self.worksets = "Architecture, Structure"
        self.is_ok = True
        self.Close()

class PhasesDialog(forms.WPFWindow):
    def __init__(self, xaml):
        forms.WPFWindow.__init__(self, xaml)
        self.btnCancel.Click += self.close_dialog
        self.btnCreate.Click += self.create_action
        self.is_ok = False
        self.phases = ""
    def close_dialog(self, s, e): self.Close()
    def create_action(self, s, e):
        self.phases = "Existing, New Construction"
        self.is_ok = True
        self.Close()

class MaterialsDialog(forms.WPFWindow):
    def __init__(self, xaml):
        forms.WPFWindow.__init__(self, xaml)
        self.btnCancel.Click += self.close_dialog
        self.btnCreate.Click += self.create_action
        self.is_ok = False
        self.palette = ""
    def close_dialog(self, s, e): self.Close()
    def create_action(self, s, e):
        self.palette = "Standard"
        self.is_ok = True
        self.Close()

class ViewsDialog(forms.WPFWindow):
    def __init__(self, xaml):
        forms.WPFWindow.__init__(self, xaml)
        self.btnCancel.Click += self.close_dialog
        self.btnCreate.Click += self.create_action
        self.is_ok = False
        self.floor = True
        self.ceiling = True
        self.elev = True
        self.v3d = True
    def close_dialog(self, s, e): self.Close()
    def create_action(self, s, e):
        self.floor = self.chkFloor.IsChecked
        self.ceiling = self.chkCeiling.IsChecked
        self.elev = self.chkElevations.IsChecked
        self.v3d = self.chk3D.IsChecked
        self.is_ok = True
        self.Close()

class LinksDialog(forms.WPFWindow):
    def __init__(self, xaml):
        forms.WPFWindow.__init__(self, xaml)
        self.btnCancel.Click += self.close_dialog
        self.btnCreate.Click += self.create_action
        self.is_ok = False
        self.path = ""
    def close_dialog(self, s, e): self.Close()
    def create_action(self, s, e):
        self.path = self.txtLinkPath.Text
        self.is_ok = True
        self.Close()

class ValidationDialog(forms.WPFWindow):
    def __init__(self, xaml):
        forms.WPFWindow.__init__(self, xaml)
        self.btnCancel.Click += self.close_dialog
        self.btnCreate.Click += self.create_action
        self.is_ok = False
    def close_dialog(self, s, e): self.Close()
    def create_action(self, s, e):
        self.is_ok = True
        self.Close()

class CompleteDialog(forms.WPFWindow):
    def __init__(self, xaml):
        forms.WPFWindow.__init__(self, xaml)
        self.btnCancel.Click += self.close_dialog
        self.btnCreate.Click += self.create_action
        self.is_ok = False
    def close_dialog(self, s, e): self.Close()
    def create_action(self, s, e):
        self.is_ok = True
        self.Close()

class ProjectWizardWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.doc = revit.doc
        
        # Wire up buttons
        self.btnStep1.Click += self.prompt_and_start_setup
        self.btnStep2.Click += self.prompt_and_set_units
        self.btnStep3.Click += self.prompt_and_set_location
        self.btnStep4.Click += self.prompt_and_create_levels
        self.btnStep5.Click += self.prompt_and_create_grids
        self.btnStep6.Click += self.prompt_and_load_families
        self.btnStep7.Click += self.prompt_and_apply_templates
        self.btnStep8.Click += self.prompt_and_fill_info
        self.btnStep9.Click += self.prompt_and_enable_worksharing
        self.btnStep10.Click += self.prompt_and_define_phases
        self.btnStep11.Click += self.prompt_and_assign_materials
        self.btnStep12.Click += self.prompt_and_create_views
        self.btnStep13.Click += self.prompt_and_link_files
        self.btnStep14.Click += self.prompt_and_run_validation
        self.btnStep15.Click += self.prompt_and_complete_setup
        
        self.btnRunAll.Click += self.run_all_steps

    def log_message(self, text, is_success=True):
        tb = TextBlock()
        tb.Text = "» " + text
        tb.Foreground = SolidColorBrush(ColorConverter.ConvertFromString("#00D084" if is_success else "#FF4757"))
        tb.FontFamily = System.Windows.Media.FontFamily("Consolas")
        tb.Margin = Thickness(0, 5, 0, 0)
        tb.TextWrapping = System.Windows.TextWrapping.Wrap
        
        self.stackLog.Children.Add(tb)
        self.scrollLog.ScrollToBottom()

    def mark_step_done(self, step_num):
        # Find the button and change its style
        btn_name = "btnStep" + str(step_num)
        btn = getattr(self, btn_name, None)
        if btn:
            btn.Foreground = SolidColorBrush(ColorConverter.ConvertFromString("#00D084"))
            btn.Content = "✓ " + btn.Content.ToString()

    def run_step(self, step_num, logic_func):
        self.log_message("Running Step {}...".format(step_num), True)
        try:
            result = logic_func(self.doc)
            self.log_message(result, True)
            self.mark_step_done(step_num)
        except Exception as e:
            self.log_message("Error in Step {}: {}".format(step_num, str(e)), False)

    def run_all_steps(self, sender, args):
        self.log_message("--- STARTING AUTOMATED SEQUENCE ---", True)
        steps = [
            setup_logic.step_start_project,
            setup_logic.step_set_units,
            setup_logic.step_set_location,
            setup_logic.step_create_levels,
            setup_logic.step_create_grids,
            setup_logic.step_load_families,
            setup_logic.step_apply_templates,
            setup_logic.step_fill_info,
            setup_logic.step_enable_worksharing,
            setup_logic.step_define_phases,
            setup_logic.step_assign_materials,
            setup_logic.step_create_views,
            setup_logic.step_link_files,
            setup_logic.step_run_validation,
            setup_logic.step_complete_setup
        ]
        
        for i, func in enumerate(steps, 1):
            if i == 4:
                # Automate with defaults during Run All
                self.log_message("Running Step 4...", True)
                result = setup_logic.step_create_levels(self.doc, 3, "Level", 10.0)
                self.log_message(result, True)
                self.mark_step_done(4)
            elif i == 5:
                # Automate with defaults during Run All
                self.log_message("Running Step 5...", True)
                result = setup_logic.step_create_grids(self.doc, 4, 15.0, 3, 20.0)
                self.log_message(result, True)
                self.mark_step_done(5)
            else:
                self.run_step(i, func)
            
        self.log_message("--- SEQUENCE COMPLETE ---", True)

    def prompt_and_create_levels(self, sender, args):
        self.log_message("Running Step 4...", True)
        
        dialog_file = script.get_bundle_file('level_dialog.xaml')
        dialog = LevelCreatorDialog(dialog_file)
        dialog.show_dialog()
        
        if dialog.is_ok:
            result = setup_logic.step_create_levels(self.doc, 3, "Level", 10.0)
            self.log_message(result, True)
            self.mark_step_done(4)
        else:
            self.log_message("Level creation cancelled by user.", False)

    def prompt_and_create_grids(self, sender, args):
        self.log_message("Running Step 5...", True)
        
        dialog_file = script.get_bundle_file('grid_dialog.xaml')
        dialog = GridCreatorDialog(dialog_file, self.doc)
        dialog.show_dialog()
        
        if dialog.is_ok:
            result = setup_logic.step_create_grids(self.doc, 4, 15.0, 3, 20.0, None)
            self.log_message(result, True)
            self.mark_step_done(5)
        else:
            self.log_message("Grid creation cancelled by user.", False)

    def prompt_and_start_setup(self, sender, args):
        self.log_message("Running Step 1...", True)
        dialog = StartSetupDialog(script.get_bundle_file('start_setup_dialog.xaml'))
        dialog.show_dialog()
        if dialog.is_ok:
            result = setup_logic.step_start_project(self.doc)
            self.log_message(result, True)
            self.mark_step_done(1)
        else: self.log_message("Cancelled.", False)

    def prompt_and_set_units(self, sender, args):
        self.log_message("Running Step 2...", True)
        dialog = UnitsDialog(script.get_bundle_file('units_dialog.xaml'))
        dialog.show_dialog()
        if dialog.is_ok:
            result = setup_logic.step_set_units(self.doc, dialog.unit_type)
            self.log_message(result, True)
            self.mark_step_done(2)
        else: self.log_message("Cancelled.", False)

    def prompt_and_set_location(self, sender, args):
        self.log_message("Running Step 3...", True)
        dialog = LocationDialog(script.get_bundle_file('location_dialog.xaml'))
        dialog.show_dialog()
        if dialog.is_ok:
            result = setup_logic.step_set_location(self.doc, dialog.address)
            self.log_message(result, True)
            self.mark_step_done(3)
        else: self.log_message("Cancelled.", False)

    def prompt_and_load_families(self, sender, args):
        self.log_message("Running Step 6...", True)
        dialog = FamiliesDialog(script.get_bundle_file('families_dialog.xaml'))
        dialog.show_dialog()
        if dialog.is_ok:
            result = setup_logic.step_load_families(self.doc, dialog.arch, dialog.struct, dialog.mep)
            self.log_message(result, True)
            self.mark_step_done(6)
        else: self.log_message("Cancelled.", False)

    def prompt_and_apply_templates(self, sender, args):
        self.log_message("Running Step 7...", True)
        dialog = TemplatesDialog(script.get_bundle_file('templates_dialog.xaml'))
        dialog.show_dialog()
        if dialog.is_ok:
            result = setup_logic.step_apply_templates(self.doc, dialog.template)
            self.log_message(result, True)
            self.mark_step_done(7)
        else: self.log_message("Cancelled.", False)

    def prompt_and_fill_info(self, sender, args):
        self.log_message("Running Step 8...", True)
        dialog = InfoDialog(script.get_bundle_file('info_dialog.xaml'))
        dialog.show_dialog()
        if dialog.is_ok:
            result = setup_logic.step_fill_info(self.doc, dialog.proj_name, dialog.client_name, dialog.proj_num)
            self.log_message(result, True)
            self.mark_step_done(8)
        else: self.log_message("Cancelled.", False)

    def prompt_and_enable_worksharing(self, sender, args):
        self.log_message("Running Step 9...", True)
        dialog = WorksharingDialog(script.get_bundle_file('worksharing_dialog.xaml'))
        dialog.show_dialog()
        if dialog.is_ok:
            result = setup_logic.step_enable_worksharing(self.doc, dialog.worksets)
            self.log_message(result, True)
            self.mark_step_done(9)
        else: self.log_message("Cancelled.", False)

    def prompt_and_define_phases(self, sender, args):
        self.log_message("Running Step 10...", True)
        dialog = PhasesDialog(script.get_bundle_file('phases_dialog.xaml'))
        dialog.show_dialog()
        if dialog.is_ok:
            result = setup_logic.step_define_phases(self.doc, dialog.phases)
            self.log_message(result, True)
            self.mark_step_done(10)
        else: self.log_message("Cancelled.", False)

    def prompt_and_assign_materials(self, sender, args):
        self.log_message("Running Step 11...", True)
        dialog = MaterialsDialog(script.get_bundle_file('materials_dialog.xaml'))
        dialog.show_dialog()
        if dialog.is_ok:
            result = setup_logic.step_assign_materials(self.doc, dialog.palette)
            self.log_message(result, True)
            self.mark_step_done(11)
        else: self.log_message("Cancelled.", False)

    def prompt_and_create_views(self, sender, args):
        self.log_message("Running Step 12...", True)
        dialog = ViewsDialog(script.get_bundle_file('views_dialog.xaml'))
        dialog.show_dialog()
        if dialog.is_ok:
            result = setup_logic.step_create_views(self.doc, dialog.floor, dialog.ceiling, dialog.elev, dialog.v3d)
            self.log_message(result, True)
            self.mark_step_done(12)
        else: self.log_message("Cancelled.", False)

    def prompt_and_link_files(self, sender, args):
        self.log_message("Running Step 13...", True)
        dialog = LinksDialog(script.get_bundle_file('links_dialog.xaml'))
        dialog.show_dialog()
        if dialog.is_ok:
            result = setup_logic.step_link_files(self.doc, dialog.path)
            self.log_message(result, True)
            self.mark_step_done(13)
        else: self.log_message("Cancelled.", False)

    def prompt_and_run_validation(self, sender, args):
        self.log_message("Running Step 14...", True)
        dialog = ValidationDialog(script.get_bundle_file('validation_dialog.xaml'))
        dialog.show_dialog()
        if dialog.is_ok:
            result = setup_logic.step_run_validation(self.doc)
            self.log_message(result, True)
            self.mark_step_done(14)
        else: self.log_message("Cancelled.", False)

    def prompt_and_complete_setup(self, sender, args):
        self.log_message("Running Step 15...", True)
        dialog = CompleteDialog(script.get_bundle_file('complete_dialog.xaml'))
        dialog.show_dialog()
        if dialog.is_ok:
            result = setup_logic.step_complete_setup(self.doc)
            self.log_message(result, True)
            self.mark_step_done(15)
        else: self.log_message("Cancelled.", False)

def main():
    xaml_file = script.get_bundle_file('ui.xaml')
    window = ProjectWizardWindow(xaml_file)
    window.ShowDialog()

if __name__ == '__main__':
    main()
