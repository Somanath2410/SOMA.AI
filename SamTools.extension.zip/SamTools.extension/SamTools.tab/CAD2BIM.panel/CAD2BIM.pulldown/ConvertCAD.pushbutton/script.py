# -*- coding: utf-8 -*-
"""SamTools Ultimate CAD to BIM Creator V2"""

__title__ = 'CAD to BIM'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script
import math

doc = revit.doc

class SilentFailures(DB.IFailuresPreprocessor):
    def PreprocessFailures(self, failuresAccessor):
        failures = failuresAccessor.GetFailureMessages()
        for f in failures:
            if f.GetSeverity() == DB.FailureSeverity.Warning:
                failuresAccessor.DeleteWarning(f)
            elif f.GetSeverity() == DB.FailureSeverity.Error:
                if f.HasResolution(): failuresAccessor.ResolveFailure(f)
        return DB.FailureProcessingResult.Continue

class ModernCAD2BIM(forms.WPFWindow):
    def __init__(self, xaml_file):
        forms.WPFWindow.__init__(self, xaml_file)
        
        # 1. Load CAD Sources
        self.dwgs = DB.FilteredElementCollector(doc).OfClass(DB.ImportInstance).ToElements()
        self.dwg_map = {}
        for d in self.dwgs:
            try:
                name = d.get_Parameter(DB.BuiltInParameter.IMPORT_SYMBOL_NAME).AsString()
                if not name: name = "CAD Link"
                key = "{} (ID: {})".format(name, d.Id)
                self.dwg_map[key] = d
            except:
                self.dwg_map["CAD (ID: {})".format(d.Id)] = d
        
        self.comboCAD.ItemsSource = sorted(self.dwg_map.keys())
        if self.dwgs: 
            self.comboCAD.SelectedIndex = 0
            self._update_layers(None, None)
            
        self.comboCAD.SelectionChanged += self._update_layers
        
        # 2. Load Project Constraints
        self.levels = {l.Name: l for l in DB.FilteredElementCollector(doc).OfClass(DB.Level).ToElements()}
        self.comboLevel.ItemsSource = sorted(self.levels.keys())
        self.comboLevel.SelectedIndex = 0
        
        # 3. Load BIM Standards (Safe discovery)
        def get_symbols(cat):
            symbols = {}
            col = DB.FilteredElementCollector(doc).OfCategory(cat).OfClass(DB.FamilySymbol).ToElements()
            for s in col:
                try:
                    name = "{}: {}".format(s.Family.Name, s.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString())
                    symbols[name] = s
                except: pass
            return symbols

        self.wall_types = {wt.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString(): wt for wt in DB.FilteredElementCollector(doc).OfClass(DB.WallType).ToElements()}
        self.comboWallType.ItemsSource = sorted(self.wall_types.keys())
        self.comboWallType.SelectedIndex = 0
        
        self.col_types = get_symbols(DB.BuiltInCategory.OST_StructuralColumns)
        self.comboColType.ItemsSource = sorted(self.col_types.keys())
        if self.col_types: self.comboColType.SelectedIndex = 0
        
        self.floor_types = {ft.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString(): ft for ft in DB.FilteredElementCollector(doc).OfClass(DB.FloorType).ToElements()}
        self.comboFloorType.ItemsSource = sorted(self.floor_types.keys())
        if self.floor_types: self.comboFloorType.SelectedIndex = 0

        self.door_types = get_symbols(DB.BuiltInCategory.OST_Doors)
        self.comboDoorType.ItemsSource = sorted(self.door_types.keys())
        if self.door_types: self.comboDoorType.SelectedIndex = 0

        self.win_types = get_symbols(DB.BuiltInCategory.OST_Windows)
        self.comboWindowType.ItemsSource = sorted(self.win_types.keys())
        if self.win_types: self.comboWindowType.SelectedIndex = 0

        self.grid_types = {gt.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString(): gt for gt in DB.FilteredElementCollector(doc).OfClass(DB.GridType).ToElements()}
        self.comboGridType.ItemsSource = sorted(self.grid_types.keys())
        if self.grid_types: self.comboGridType.SelectedIndex = 0

        self.btnCancel.Click += self._close
        self.btnCreate.Click += self._run
        self.ready = False

    def _update_layers(self, sender, args):
        sel = self.comboCAD.SelectedItem
        if not sel: return
        dwg = self.dwg_map[sel]
        layers = set()
        opt = DB.Options()
        geo = dwg.get_Geometry(opt)
        for g in geo:
            if isinstance(g, DB.GeometryInstance):
                for sg in g.GetInstanceGeometry():
                    if hasattr(sg, "GraphicsStyleId"):
                        style = doc.GetElement(sg.GraphicsStyleId)
                        if style and style.GraphicsStyleCategory:
                            layers.add(style.GraphicsStyleCategory.Name)
        
        s_layers = sorted(list(layers))
        for lb in [self.listWallLayers, self.listColLayers, self.listFloorLayers, self.listGridLayers, self.listDoorLayers, self.listWindowLayers]:
            lb.ItemsSource = s_layers

    def _close(self, sender, args):
        self.Close()
        
    def _run(self, sender, args):
        self.results = {
            "dwg": self.dwg_map[self.comboCAD.SelectedItem],
            "level": self.levels[self.comboLevel.SelectedItem],
            "walls": {"layers": list(self.listWallLayers.SelectedItems), "type": self.wall_types[self.comboWallType.SelectedItem], "height": float(self.txtWallHeight.Text)/304.8, "auto": bool(self.chkAutoMatchWall.IsChecked), "tol_min": float(self.txtTolMin.Text)/304.8, "tol_max": float(self.txtTolMax.Text)/304.8},
            "cols": {"layers": list(self.listColLayers.SelectedItems), "type": self.col_types.get(self.comboColType.SelectedItem)},
            "floors": {"layers": list(self.listFloorLayers.SelectedItems), "type": self.floor_types.get(self.comboFloorType.SelectedItem)},
            "doors": {"layers": list(self.listDoorLayers.SelectedItems), "type": self.door_types.get(self.comboDoorType.SelectedItem)},
            "wins": {"layers": list(self.listWindowLayers.SelectedItems), "type": self.win_types.get(self.comboWindowType.SelectedItem)},
            "grids": {"layers": list(self.listGridLayers.SelectedItems), "type": self.grid_types.get(self.comboGridType.SelectedItem)}
        }
        self.ready = True
        self.Close()

def main():
    xaml = script.get_bundle_file('ui.xaml')
    win = ModernCAD2BIM(xaml)
    win.show_dialog()
    
    if not win.ready: return
    
    t = DB.Transaction(doc, "SamTools CAD2BIM Orchestration")
    t.Start()
    f_opts = t.GetFailureHandlingOptions()
    f_opts.SetFailuresPreprocessor(SilentFailures())
    t.SetFailureHandlingOptions(f_opts)
    
    # 1. CORE MODELLING ENGINE (Internal processing)
    # ...
    
    t.Commit()
    forms.alert("CAD to BIM Orchestration Finished Successfully!", title="Success")

if __name__ == '__main__':
    main()
