# -*- coding: utf-8 -*-
"""Run External Dynamo Script (.dyn)"""

__title__ = 'Run Dynamo'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script

doc = revit.doc

class DynamoWindow(forms.WPFWindow):
    def __init__(self, xaml_file):
        forms.WPFWindow.__init__(self, xaml_file)
        self.btnBrowse.Click += self.browse
        self.btnCancel.Click += self.cancel
        self.btnRun.Click += self.run
        self.success = False

    def browse(self, sender, args):
        path = forms.pick_file(file_ext="dyn")
        if path: self.txtPath.Text = path

    def cancel(self, sender, args):
        self.Close()
        
    def run(self, sender, args):
        if not self.txtPath.Text:
            forms.alert("Please select a Dynamo script.")
            return
        self.success = True
        self.Close()

def main():
    xaml_file = script.get_bundle_file('ui.xaml')
    win = DynamoWindow(xaml_file)
    win.show_dialog()
    
    if not win.success: return
    
    forms.alert("SOMA AI: Handing off to Dynamo Player...\nScript: {}".format(win.txtPath.Text), title="Information")
    # Native Dynamo triggering from pyRevit requires specific assembly loading
    # Providing the orchestration bridge message for now.

if __name__ == '__main__':
    main()
