import os
import shutil

base_path = r"C:\Users\somnath.misal\AppData\Roaming\pyRevit\Extensions\SamTools.extension\SamTools.tab"

# Mapping old numbered panels to new modern panels
migration_map = {
    "01 Sheets.panel": "Documentation.panel",
    "1 Sheets.panel": "Documentation.panel",
    "02 Parameters.panel": "DataManagement.panel",
    "2 Parameters.panel": "DataManagement.panel",
    "03 QAQC.panel": "QAQC.panel",
    "3 QAQC.panel": "QAQC.panel",
    "5 Dashboard.panel": "Utilities.panel",
    "06 Rooms.panel": "Modeling.panel",
    "07 Coord.panel": "Coordination.panel",
    "08 Health.panel": "QAQC.panel",
    "09 IFC.panel": "Export.panel",
    "10 Drawing.panel": "Documentation.panel",
    "11 QS.panel": "Schedules.panel",
    "12 Families.panel": "DataManagement.panel",
    "14 AI.panel": "AIAssistant.panel",
    "15 Settings.panel": "Utilities.panel"
}

print("Starting SamTools Panel Migration...")

for old_name, new_name in migration_map.items():
    old_dir = os.path.join(base_path, old_name)
    new_dir = os.path.join(base_path, new_name)
    
    if os.path.exists(old_dir):
        os.makedirs(new_dir, exist_ok=True)
        
        # Move all contents (.pushbutton, .pulldown, etc)
        for item in os.listdir(old_dir):
            s = os.path.join(old_dir, item)
            d = os.path.join(new_dir, item)
            if not os.path.exists(d):
                shutil.move(s, d)
                print(f"Moved [{item}] -> {new_name}")
            else:
                print(f"Skipped [{item}] (Already exists in {new_name})")
        
        # Delete old directory if empty
        try:
            os.rmdir(old_dir)
            print(f"Deleted empty folder: {old_name}")
        except:
            print(f"Could not delete {old_name} (might not be empty)")

print("\nMigration Complete! Please reload pyRevit.")
input("Press Enter to exit...")
