# -*- coding: utf-8 -*-
"""Check active users in Central Model"""

__title__ = 'User Activity'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script

doc = revit.doc

def main():
    if not doc.IsWorkshared:
        forms.alert("This project is not workshared.", title="Information")
        return
        
    try:
        # Accessing worksharing info often requires higher permissions or specific paths
        # For now, show central model path and basic info
        central_path = doc.GetWorksharingCentralModelPath()
        user = revit.username
        
        forms.alert("Central Model Path: {}\n\nCurrent User: {}".format(DB.ModelPathUtils.ConvertModelPathToUserVisiblePath(central_path), user), title="Worksharing Info")
    except:
        forms.alert("Could not retrieve worksharing details.", title="Error")

if __name__ == '__main__':
    main()
