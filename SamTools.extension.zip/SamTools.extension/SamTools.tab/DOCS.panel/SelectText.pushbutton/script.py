# -*- coding: utf-8 -*-
"""SOMA.DOCS Select & Modify Text
Selects, modifies, and deletes text-based elements matching the query in the project."""

from pyrevit import revit, forms, script
from Autodesk.Revit.DB import *
import clr
import os
import re
import System

clr.AddReference("PresentationFramework")
clr.AddReference("PresentationCore")
clr.AddReference("WindowsBase")

from System.Windows import Window
from System.Windows.Markup import XamlReader
from System.Collections.Generic import List
from System.IO import FileStream, FileMode, FileAccess, FileShare

# Setup output window
output = script.get_output()

class SearchResultItem(object):
    def __init__(self, element, category, text, location, level_name):
        self.element = element
        self._category = category
        self._text = text
        self._location = location
        self._level_name = level_name
        
    @property
    def Category(self):
        return self._category
        
    @property
    def Text(self):
        return self._text
        
    @property
    def Location(self):
        return self._location
        
    @property
    def LevelName(self):
        return self._level_name

class SelectTextWindow(Window):
    def __init__(self):
        # Load XAML
        xaml_path = os.path.join(os.path.dirname(__file__), "UI.xaml")
        fs = FileStream(xaml_path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
        try:
            self.ui = XamlReader.Load(fs)
        finally:
            fs.Close()
            
        # Bind Controls
        self.close_btn = self.ui.FindName("CloseButton")
        self.search_input = self.ui.FindName("SearchInput")
        self.scope_rooms = self.ui.FindName("ScopeRooms")
        self.scope_text_notes = self.ui.FindName("ScopeTextNotes")
        self.scope_model_text = self.ui.FindName("ScopeModelText")
        self.scope_params = self.ui.FindName("ScopeParameters")
        self.opt_case = self.ui.FindName("OptCaseSensitive")
        self.opt_whole = self.ui.FindName("OptWholeWord")
        self.search_btn = self.ui.FindName("SearchButton")
        self.status_text = self.ui.FindName("StatusText")
        
        # Action Panel Bindings
        self.replace_input = self.ui.FindName("ReplaceInput")
        self.replace_btn = self.ui.FindName("ReplaceButton")
        self.delete_btn = self.ui.FindName("DeleteButton")
        self.show_btn = self.ui.FindName("ShowButton")
        self.results_list = self.ui.FindName("ResultsList")
        self.results_title = self.ui.FindName("ResultsTitle")
        self.progress_bar = self.ui.FindName("ProgressBar")
        
        # Selection & Visibility Buttons
        self.select_selected_btn = self.ui.FindName("SelectSelectedButton")
        self.hide_btn = self.ui.FindName("HideButton")
        self.unhide_btn = self.ui.FindName("UnhideButton")
        
        # Level Filter ComboBox
        self.level_filter = self.ui.FindName("LevelFilter")
        
        # Populate Level Filter
        try:
            levels = FilteredElementCollector(revit.doc).OfClass(Level).ToElements()
            level_names = sorted([l.Name for l in levels])
            self.level_filter.Items.Add("<All Levels>")
            for name in level_names:
                self.level_filter.Items.Add(name)
            self.level_filter.SelectedIndex = 0
        except Exception:
            pass
            
        # Events
        self.close_btn.Click += self.on_close
        self.search_btn.Click += self.on_search
        self.replace_btn.Click += self.on_replace
        self.delete_btn.Click += self.on_delete
        self.show_btn.Click += self.on_show_selected
        self.select_selected_btn.Click += self.on_select_selected
        self.hide_btn.Click += self.on_hide_selected
        self.unhide_btn.Click += self.on_unhide_selected
        self.level_filter.SelectionChanged += self.on_level_filter_changed
        self.results_list.SelectionChanged += self.on_selection_changed
        self.ui.Closing += self.on_window_closing
        self.ui.MouseLeftButtonDown += self.on_drag
        
        # Caches
        self.all_search_results = []
        self.found_items = []
        self.overridden_element_ids = []
        
    def on_drag(self, sender, e):
        self.ui.DragMove()
        
    def on_close(self, sender, e):
        self.ui.Close()
        
    def on_window_closing(self, sender, e):
        self.clear_graphic_overrides()

    def clear_graphic_overrides(self):
        if not self.overridden_element_ids:
            return
        doc = revit.doc
        active_view = doc.ActiveView
        t = Transaction(doc, "SOMA | Clear Highlights")
        t.Start()
        try:
            empty_settings = OverrideGraphicSettings()
            for eid in self.overridden_element_ids:
                try:
                    active_view.SetElementOverrides(eid, empty_settings)
                except Exception:
                    pass
            t.Commit()
            self.overridden_element_ids = []
        except Exception:
            t.RollBack()

    def apply_red_overrides(self, element_ids):
        # Clear previous highlights
        self.clear_graphic_overrides()
        
        if not element_ids:
            return
            
        doc = revit.doc
        active_view = doc.ActiveView
        
        # Build Solid Red Graphics Settings
        settings = OverrideGraphicSettings()
        red_color = Color(255, 0, 0)
        
        settings.SetProjectionLineColor(red_color)
        settings.SetCutLineColor(red_color)
        settings.SetProjectionLineWeight(6) # Thicker highlight
        
        # Fetch solid fill pattern for surface override
        try:
            collector = FilteredElementCollector(doc).OfClass(FillPatternElement)
            solid_pattern = None
            for fpe in collector:
                pattern = fpe.GetFillPattern()
                if pattern.IsSolid:
                    solid_pattern = fpe
                    break
            if solid_pattern:
                try:
                    # Revit 2019+
                    settings.SetSurfaceForegroundPatternId(solid_pattern.Id)
                    settings.SetSurfaceForegroundPatternColor(red_color)
                    settings.SetCutForegroundPatternId(solid_pattern.Id)
                    settings.SetCutForegroundPatternColor(red_color)
                except Exception:
                    # Pre-2019 Fallbacks
                    settings.SetProjectionFillPatternId(solid_pattern.Id)
                    settings.SetProjectionFillPatternColor(red_color)
                    settings.SetCutFillPatternId(solid_pattern.Id)
                    settings.SetCutFillPatternColor(red_color)
        except Exception:
            pass
            
        # Apply Overrides
        t = Transaction(doc, "SOMA | Highlight Text Red")
        t.Start()
        try:
            for eid in element_ids:
                try:
                    active_view.SetElementOverrides(eid, settings)
                    self.overridden_element_ids.append(eid)
                except Exception:
                    pass
            t.Commit()
        except Exception:
            t.RollBack()

    def update_highlights(self):
        selected_items = self.results_list.SelectedItems
        if selected_items.Count > 0:
            ids = [item.element.Id for item in selected_items]
        else:
            ids = [item.element.Id for item in self.found_items]
        self.apply_red_overrides(ids)

    def on_selection_changed(self, sender, e):
        self.update_highlights()

    def get_element_level_name(self, el):
        doc = el.Document
        # 1. Rooms/Areas or elements with Level property
        if hasattr(el, "Level") and el.Level:
            return el.Level.Name
            
        # 2. View-specific annotations
        if hasattr(el, "OwnerViewId") and el.OwnerViewId != ElementId.InvalidElementId:
            view = doc.GetElement(el.OwnerViewId)
            if view and hasattr(view, "GenLevel") and view.GenLevel:
                return view.GenLevel.Name
                
        # 3. Parameter fallbacks for Level
        lvl_param = el.get_Parameter(BuiltInParameter.INSTANCE_REFERENCE_LEVEL_PARAM)
        if lvl_param and lvl_param.HasValue:
            lvl = doc.GetElement(lvl_param.AsElementId())
            if lvl:
                return lvl.Name
                
        # 4. Schedule/View level fallback
        lvl_param2 = el.get_Parameter(BuiltInParameter.ROOM_LEVEL_ID)
        if lvl_param2 and lvl_param2.HasValue:
            lvl = doc.GetElement(lvl_param2.AsElementId())
            if lvl:
                return lvl.Name
                
        return "None"

    def get_location_string(self, el):
        doc = el.Document
        # 1. View-specific annotations
        if hasattr(el, "OwnerViewId") and el.OwnerViewId != ElementId.InvalidElementId:
            view = doc.GetElement(el.OwnerViewId)
            if view:
                return "View: {}".format(view.Name)
                
        # 2. Level property
        if hasattr(el, "Level") and el.Level:
            return "Level: {}".format(el.Level.Name)
            
        # 3. Level parameter
        lvl_param = el.get_Parameter(BuiltInParameter.INSTANCE_REFERENCE_LEVEL_PARAM)
        if lvl_param and lvl_param.HasValue:
            lvl = doc.GetElement(lvl_param.AsElementId())
            if lvl:
                return "Level: {}".format(lvl.Name)
                
        return "Model"

    def on_search(self, sender, e=None):
        query = self.search_input.Text
        if not query:
            forms.alert("Please enter a search query.", title="SOMA | Error")
            return
            
        self.status_text.Text = "Scanning model..."
        self.status_text.Foreground = System.Windows.Media.Brushes.Yellow
        self.progress_bar.Value = 10
        
        # Options
        search_rooms = self.scope_rooms.IsChecked
        search_text_notes = self.scope_text_notes.IsChecked
        search_model_text = self.scope_model_text.IsChecked
        search_params = self.scope_params.IsChecked
        
        case_sensitive = self.opt_case.IsChecked
        whole_word = self.opt_whole.IsChecked
        
        self.all_search_results = []
        matching_ids = set()
        doc = revit.doc
        
        # Match pattern
        if whole_word:
            pattern_str = r"\b" + re.escape(query) + r"\b"
            flags = 0 if case_sensitive else re.IGNORECASE
            regex = re.compile(pattern_str, flags)
            
            def is_match(text):
                if not text: return False
                return bool(regex.search(text))
        else:
            query_val = query if case_sensitive else query.lower()
            
            def is_match(text):
                if not text: return False
                text_val = text if case_sensitive else text.lower()
                return query_val in text_val

        # Step calculation for ProgressBar
        steps = sum([search_rooms, search_text_notes, search_model_text, search_params])
        if steps == 0:
            forms.alert("Please select at least one search scope.", title="SOMA | Info")
            self.progress_bar.Value = 0
            self.status_text.Text = "No scope selected"
            return
            
        progress_per_step = 80.0 / steps
        current_progress = 10.0

        # 1. Rooms & Areas
        if search_rooms:
            self.status_text.Text = "Scanning Rooms and Areas..."
            # Rooms
            room_collector = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_Rooms).WhereElementIsNotElementType()
            for r in room_collector:
                try:
                    val = r.Name
                    if is_match(val) and r.Id not in matching_ids:
                        loc = self.get_location_string(r)
                        lvl = self.get_element_level_name(r)
                        self.all_search_results.append(SearchResultItem(r, "Room", val, loc, lvl))
                        matching_ids.add(r.Id)
                except Exception:
                    name_param = r.get_Parameter(BuiltInParameter.ROOM_NAME)
                    if name_param and name_param.HasValue:
                        val = name_param.AsString()
                        if is_match(val) and r.Id not in matching_ids:
                            loc = self.get_location_string(r)
                            lvl = self.get_element_level_name(r)
                            self.all_search_results.append(SearchResultItem(r, "Room", val, loc, lvl))
                            matching_ids.add(r.Id)
            # Areas
            area_collector = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_Areas).WhereElementIsNotElementType()
            for a in area_collector:
                try:
                    val = a.Name
                    if is_match(val) and a.Id not in matching_ids:
                        loc = self.get_location_string(a)
                        lvl = self.get_element_level_name(a)
                        self.all_search_results.append(SearchResultItem(a, "Area", val, loc, lvl))
                        matching_ids.add(a.Id)
                except Exception:
                    name_param = a.get_Parameter(BuiltInParameter.ROOM_NAME)
                    if name_param and name_param.HasValue:
                        val = name_param.AsString()
                        if is_match(val) and a.Id not in matching_ids:
                            loc = self.get_location_string(a)
                            lvl = self.get_element_level_name(a)
                            self.all_search_results.append(SearchResultItem(a, "Area", val, loc, lvl))
                            matching_ids.add(a.Id)
            
            current_progress += progress_per_step
            self.progress_bar.Value = current_progress

        # 2. Text Notes
        if search_text_notes:
            self.status_text.Text = "Scanning Text Notes..."
            note_collector = FilteredElementCollector(doc).OfClass(TextNote).WhereElementIsNotElementType()
            for tn in note_collector:
                if is_match(tn.Text) and tn.Id not in matching_ids:
                    loc = self.get_location_string(tn)
                    lvl = self.get_element_level_name(tn)
                    self.all_search_results.append(SearchResultItem(tn, "Text Note", tn.Text, loc, lvl))
                    matching_ids.add(tn.Id)
            
            current_progress += progress_per_step
            self.progress_bar.Value = current_progress
                    
        # 3. Model Text
        if search_model_text:
            self.status_text.Text = "Scanning Model Text..."
            try:
                mtext_collector = FilteredElementCollector(doc).OfClass(ModelText).WhereElementIsNotElementType()
                for mt in mtext_collector:
                    if is_match(mt.Text) and mt.Id not in matching_ids:
                        loc = self.get_location_string(mt)
                        lvl = self.get_element_level_name(mt)
                        self.all_search_results.append(SearchResultItem(mt, "Model Text", mt.Text, loc, lvl))
                        matching_ids.add(mt.Id)
            except Exception:
                pass
                
            current_progress += progress_per_step
            self.progress_bar.Value = current_progress

        # 4. Search All Parameters
        if search_params:
            self.status_text.Text = "Scanning all parameters (may take a moment)..."
            all_collector = FilteredElementCollector(doc).WhereElementIsNotElementType()
            elements = list(all_collector)
            total_elements = len(elements)
            
            for i, el in enumerate(elements):
                if i % 100 == 0:
                    self.progress_bar.Value = current_progress + ((float(i) / total_elements) * progress_per_step)
                    
                if el.Category is None:
                    continue
                if el.Id in matching_ids:
                    continue
                
                # Check parameters
                for param in el.Parameters:
                    if param.StorageType == StorageType.String:
                        val = param.AsString()
                        if val and is_match(val):
                            loc = self.get_location_string(el)
                            lvl = self.get_element_level_name(el)
                            cat_name = el.Category.Name
                            self.all_search_results.append(SearchResultItem(el, cat_name, "Parameter: '{}'".format(val), loc, lvl))
                            matching_ids.add(el.Id)
                            break
                            
            current_progress += progress_per_step
            self.progress_bar.Value = current_progress

        # Apply filtering
        self.apply_filter()

    def on_level_filter_changed(self, sender, e):
        self.apply_filter()

    def apply_filter(self):
        selected_lvl = self.level_filter.SelectedItem
        if not selected_lvl or selected_lvl == "<All Levels>":
            self.found_items = self.all_search_results
        else:
            self.found_items = [item for item in self.all_search_results if item.LevelName == selected_lvl]
            
        self.results_list.ItemsSource = self.found_items
        self.results_title.Text = "FOUND ELEMENTS ({})".format(len(self.found_items))
        
        # Apply selection
        if self.found_items:
            element_ids = List[ElementId]()
            for item in self.found_items:
                element_ids.Add(item.element.Id)
                
            try:
                selection = revit.get_selection()
                selection.set_to(element_ids)
            except Exception:
                try:
                    revit.uidoc.Selection.SetElementIds(element_ids)
                except Exception:
                    pass
            
            self.status_text.Text = "Selected {} elements! (Level: '{}')".format(len(self.found_items), selected_lvl)
            self.status_text.Foreground = System.Windows.Media.Brushes.SpringGreen
            self.progress_bar.Value = 100
        else:
            try:
                revit.get_selection().set_to(List[ElementId]())
            except Exception:
                try:
                    revit.uidoc.Selection.SetElementIds(List[ElementId]())
                except Exception:
                    pass
            self.status_text.Text = "No matching elements on Level '{}'.".format(selected_lvl)
            self.status_text.Foreground = System.Windows.Media.Brushes.Coral
            self.progress_bar.Value = 100
            
        # Update floor plan highlights
        self.update_highlights()

    def on_show_selected(self, sender, e):
        selected_item = self.results_list.SelectedItem
        if not selected_item:
            forms.alert("Please select an item from the list to zoom to.", title="SOMA | Info")
            return
            
        uidoc = revit.uidoc
        el_id = selected_item.element.Id
        
        try:
            ids = List[ElementId]()
            ids.Add(el_id)
            uidoc.Selection.SetElementIds(ids)
            uidoc.ShowElements(ids)
            
            self.status_text.Text = "Zoomed to selected element: ID {}".format(el_id)
            self.status_text.Foreground = System.Windows.Media.Brushes.SpringGreen
        except Exception as ex:
            forms.alert("Could not zoom to element: {}".format(ex), title="SOMA | Zoom Error")

    def on_select_selected(self, sender, e):
        selected_items = self.results_list.SelectedItems
        if not selected_items:
            forms.alert("Please select one or more items from the list.", title="SOMA | Info")
            return
            
        element_ids = List[ElementId]()
        for item in selected_items:
            element_ids.Add(item.element.Id)
            
        try:
            selection = revit.get_selection()
            selection.set_to(element_ids)
            self.status_text.Text = "Selected {} items in Revit.".format(element_ids.Count)
            self.status_text.Foreground = System.Windows.Media.Brushes.SpringGreen
        except Exception as ex:
            try:
                revit.uidoc.Selection.SetElementIds(element_ids)
                self.status_text.Text = "Selected {} items in Revit.".format(element_ids.Count)
                self.status_text.Foreground = System.Windows.Media.Brushes.SpringGreen
            except Exception as e:
                forms.alert("Failed to set selection: {}".format(e), title="SOMA | Selection Error")

    def on_hide_selected(self, sender, e):
        selected_items = self.results_list.SelectedItems
        if not selected_items:
            forms.alert("Please select one or more items from the list to hide.", title="SOMA | Info")
            return
            
        doc = revit.doc
        active_view = doc.ActiveView
        element_ids = List[ElementId]()
        for item in selected_items:
            el = item.element
            if el.CanBeHidden(active_view):
                element_ids.Add(el.Id)
                
        if element_ids.Count > 0:
            t = Transaction(doc, "SOMA | Hide Elements")
            t.Start()
            try:
                active_view.HideElements(element_ids)
                t.Commit()
                self.status_text.Text = "Hidden {} elements in active view.".format(element_ids.Count)
                self.status_text.Foreground = System.Windows.Media.Brushes.SpringGreen
            except Exception as ex:
                t.RollBack()
                forms.alert("Hide failed: {}".format(ex), title="SOMA | Visibility Error")
        else:
            forms.alert("None of the selected elements can be hidden in the active view.", title="SOMA | Info")

    def on_unhide_selected(self, sender, e):
        selected_items = self.results_list.SelectedItems
        if not selected_items:
            forms.alert("Please select one or more items from the list to unhide.", title="SOMA | Info")
            return
            
        doc = revit.doc
        active_view = doc.ActiveView
        element_ids = List[ElementId]()
        for item in selected_items:
            element_ids.Add(item.element.Id)
            
        t = Transaction(doc, "SOMA | Unhide Elements")
        t.Start()
        try:
            active_view.UnhideElements(element_ids)
            t.Commit()
            self.status_text.Text = "Unhidden {} elements in active view.".format(element_ids.Count)
            self.status_text.Foreground = System.Windows.Media.Brushes.SpringGreen
        except Exception as ex:
            t.RollBack()
            forms.alert("Unhide failed: {}".format(ex), title="SOMA | Visibility Error")

    def on_delete(self, sender, e):
        selected_items = self.results_list.SelectedItems
        target_items = []
        
        if selected_items.Count > 0:
            prompt = "Are you sure you want to delete the selected {} elements?".format(selected_items.Count)
            for item in selected_items:
                target_items.append(item.element)
        else:
            if not self.found_items:
                forms.alert("No elements to delete. Run a search first.", title="SOMA | Info")
                return
            prompt = "Are you sure you want to delete ALL {} filtered elements?".format(len(self.found_items))
            target_items = [item.element for item in self.found_items]
            
        if not forms.alert(prompt, yesno=True, title="SOMA | Confirm Delete"):
            return
            
        doc = revit.doc
        t = Transaction(doc, "SOMA | Delete Text Elements")
        t.Start()
        try:
            deleted_count = 0
            for el in target_items:
                try:
                    doc.Delete(el.Id)
                    deleted_count += 1
                except Exception:
                    pass
            t.Commit()
            forms.alert("Successfully deleted {} elements.".format(deleted_count), title="SOMA | Success")
            
            # Reset
            self.results_list.ItemsSource = []
            self.all_search_results = []
            self.found_items = []
            self.results_title.Text = "FOUND ELEMENTS (0)"
            self.progress_bar.Value = 0
            self.status_text.Text = "Deleted {} elements.".format(deleted_count)
            self.status_text.Foreground = System.Windows.Media.Brushes.SpringGreen
        except Exception as ex:
            t.RollBack()
            forms.alert("Delete failed: {}".format(ex), title="SOMA | Delete Error")

    def on_replace(self, sender, e):
        query = self.search_input.Text
        replacement_text = self.replace_input.Text
        
        if not query:
            forms.alert("Please run a search first by entering a search query.", title="SOMA | Info")
            return
        if replacement_text is None:
            replacement_text = ""
            
        if not self.found_items:
            forms.alert("No elements found to modify. Run a search first.", title="SOMA | Info")
            return
            
        prompt = "Are you sure you want to replace text in ALL {} matching elements in the current filter?".format(len(self.found_items))
        if not forms.alert(prompt, yesno=True, title="SOMA | Confirm Replace"):
            return
            
        case_sensitive = self.opt_case.IsChecked
        doc = revit.doc
        t = Transaction(doc, "SOMA | Replace Text")
        t.Start()
        try:
            modified_count = 0
            for item in self.found_items:
                el = item.element
                modified = False
                
                # Check Category IDs to bypass namespaces
                # 1. Rooms
                if el.Category and el.Category.Id.IntegerValue == int(BuiltInCategory.OST_Rooms):
                    try:
                        el.Name = replacement_text
                        modified = True
                    except Exception:
                        name_param = el.get_Parameter(BuiltInParameter.ROOM_NAME)
                        if name_param:
                            name_param.Set(replacement_text)
                            modified = True
                            
                # 2. Areas
                elif el.Category and el.Category.Id.IntegerValue == int(BuiltInCategory.OST_Areas):
                    try:
                        el.Name = replacement_text
                        modified = True
                    except Exception:
                        name_param = el.get_Parameter(BuiltInParameter.ROOM_NAME)
                        if name_param:
                            name_param.Set(replacement_text)
                            modified = True
                            
                # 3. Text Notes
                elif isinstance(el, TextNote):
                    el.Text = replacement_text
                    modified = True
                    
                # 4. Model Text
                elif isinstance(el, ModelText):
                    el.Text = replacement_text
                    modified = True
                    
                # 5. General Parameters
                else:
                    for param in el.Parameters:
                        if param.StorageType == StorageType.String and param.HasValue:
                            val = param.AsString()
                            if val and (query in val if case_sensitive else query.lower() in val.lower()):
                                new_val = re.sub(re.escape(query), replacement_text, val, flags=0 if case_sensitive else re.IGNORECASE)
                                param.Set(new_val)
                                modified = True
                                
                if modified:
                    modified_count += 1
                    
            t.Commit()
            forms.alert("Successfully replaced text in {} elements.".format(modified_count), title="SOMA | Success")
            
            # Re-run search
            self.on_search(None)
        except Exception as ex:
            t.RollBack()
            forms.alert("Replace failed: {}".format(ex), title="SOMA | Replace Error")

    def show(self):
        self.ui.ShowDialog()

if __name__ == "__main__":
    win = SelectTextWindow()
    win.show()
