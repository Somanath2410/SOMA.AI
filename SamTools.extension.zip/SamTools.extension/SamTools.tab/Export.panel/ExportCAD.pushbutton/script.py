# -*- coding: utf-8 -*-
"""Comprehensive Batch DWG Export Orchestrator"""

__title__ = 'Export CAD'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script

doc = revit.doc

class DWGExportWindow(forms.WPFWindow):
    def __init__(self, xaml_file):
        forms.WPFWindow.__init__(self, xaml_file)
        
        # Load Setups
        setups = DB.FilteredElementCollector(doc).OfClass(DB.ExportDWGSettings).ToElements()
        self.setup_dict = {s.Name: s for s in setups}
        self.comboSetup.ItemsSource = sorted(self.setup_dict.keys())
        if setups: self.comboSetup.SelectedIndex = 0
        
        # Load Views/Sheets
        all_views = DB.FilteredElementCollector(doc).OfClass(DB.View).ToElements()
        self.view_dict = {"[{}] {}".format(v.ViewType, v.Name): v for v in all_views if not v.IsTemplate}
        self.listViews.ItemsSource = sorted(self.view_dict.keys())
        
        # Load Sets
        sets = DB.FilteredElementCollector(doc).OfClass(DB.ViewSheetSet).ToElements()
        self.set_dict = {s.Name: s for s in sets}
        self.comboSets.ItemsSource = ["<Manual Selection>"] + sorted(self.set_dict.keys())
        self.comboSets.SelectedIndex = 0
        self.comboSets.SelectionChanged += self.on_set_changed
        
        self.btnBrowse.Click += self.select_folder
        self.btnCancel.Click += self.cancel
        self.btnExport.Click += self.run_export
        self.success = False
        self.output_path = ""

    def on_set_changed(self, sender, args):
        set_name = self.comboSets.SelectedItem
        if set_name == "<Manual Selection>": 
            self.listViews.SelectedItems.Clear()
            return
            
        target_set = self.set_dict[set_name]
        set_views = [v.Id for v in target_set.Views]
        
        self.listViews.SelectedItems.Clear()
        for item in self.listViews.Items:
            if self.view_dict[item].Id in set_views:
                self.listViews.SelectedItems.Add(item)

    def select_folder(self, sender, args):
        path = forms.pick_folder(title="Select Output Directory")
        if path:
            self.output_path = path
            self.lblPath.Text = path
            self.lblPath.Foreground = System.Windows.Media.Brushes.Green

    def cancel(self, sender, args):
        self.Close()
        
    def run_export(self, sender, args):
        if not self.output_path:
            forms.alert("Please select an output folder.")
            return
        if not self.listViews.SelectedItems:
            forms.alert("Please select at least one view.")
            return
            
        self.sel_setup = self.setup_dict[self.comboSetup.SelectedItem]
        self.selected_views = [self.view_dict[v] for v in self.listViews.SelectedItems]
        self.project_code = self.txtProjectCode.Text
        self.success = True
        self.Close()

def main():
    xaml_file = script.get_bundle_file('ui.xaml')
    win = DWGExportWindow(xaml_file)
    win.show_dialog()
    
    if not win.success: return
    
    with revit.Transaction("SamTools - Premium DWG Export"):
        try:
            options = win.sel_setup.GetDWGExportOptions()
            
            view_ids = System.Collections.Generic.List[DB.ElementId]()
            for v in win.selected_views: view_ids.Add(v.Id)
            
            # Export each view with the project code prefix
            for v in win.selected_views:
                v_ids = System.Collections.Generic.List[DB.ElementId]()
                v_ids.Add(v.Id)
                name = "{}_{}".format(win.project_code, v.Name)
                doc.Export(win.output_path, name, v_ids, options)
                
            forms.alert("Premium DWG Export Complete!", title="Success")
        except Exception as e:
            forms.alert("DWG Export Failed: {}".format(str(e)), title="Error")

if __name__ == '__main__':
    import System
    main()
