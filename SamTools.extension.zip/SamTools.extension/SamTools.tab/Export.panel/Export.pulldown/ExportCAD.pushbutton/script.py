# -*- coding: utf-8 -*-
"""Comprehensive Batch DWG Export Orchestrator"""

__title__ = 'Export CAD'
__author__ = 'SamTools'

from samtools.exporter import run_exporter

if __name__ == '__main__':
    run_exporter(default_format="DWG")
