# -*- coding: utf-8 -*-
"""Comprehensive Premium Multi-Format Export Orchestrator (ProSheets Grade)"""

__title__ = 'Export Pro'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script, framework
import System
import os
import re
import datetime
import System.Drawing.Printing as Printing

doc = revit.doc

class ExportProWindow(forms.WPFWindow):
    def __init__(self, xaml_file):
        forms.WPFWindow.__init__(self, xaml_file)
        
        self.success = False
        self.output_path = ""
        self.active_rules = ["Sheet Number", "Sheet Name"]
        
        # 1. Load Views & Sheets
        self.load_views_and_sheets()
        
        # 2. Load View/Sheet Sets
        self.load_view_sheet_sets()
        
        # 3. Load Printers (pyRevit PrintManager Reference)
        self.load_printers()
        
        # 4. Load Revit Print Settings
        self.load_print_settings()
        
        # 5. Load Revit DWG Export Settings
        self.load_dwg_settings()
        
        # 6. Initialize Custom Naming UI
        self.update_active_rules_list()
        self.update_preview(None, None)
        
        # Hook up Event Handlers
        self.comboSets.SelectionChanged += self.on_set_filtered
        self.btnExecuteSaveSet.Click += self.on_execute_save_set
        self.btnAddParam.Click += self.on_add_param
        self.btnRemoveParam.Click += self.on_remove_param
        self.btnMoveUp.Click += self.on_move_up
        self.btnMoveDown.Click += self.on_move_down
        self.txtPrefix.TextChanged += self.update_preview
        self.txtSuffix.TextChanged += self.update_preview
        self.txtSeparator.TextChanged += self.update_preview
        self.txtSearch.TextChanged += self.on_search_changed
        self.btnSelectAll.Click += self.on_select_all
        self.btnSelectNone.Click += self.on_select_none
        self.listSheets.SelectionChanged += self.on_sheet_selected
        
        self.btnBrowse.Click += self.select_folder
        self.btnCancel.Click += self.cancel
        self.btnExport.Click += self.run_export

    def load_views_and_sheets(self):
        # Collect Sheets
        sheets = DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet).ToElements()
        # Collect Views (excluding templates and internal views)
        views = DB.FilteredElementCollector(doc).OfClass(DB.View).ToElements()
        valid_views = [v for v in views if not v.IsTemplate and v.CanBePrinted and not isinstance(v, DB.ViewSheet)]
        
        self.sheet_dict = {}
        for s in sheets:
            self.sheet_dict["[Sheet] {} - {}".format(s.SheetNumber, s.Name)] = s
        for v in valid_views:
            self.sheet_dict["[View: {}] {}".format(v.ViewType, v.Name)] = v
            
        self.listSheets.ItemsSource = sorted(self.sheet_dict.keys())

    def load_view_sheet_sets(self):
        sets = DB.FilteredElementCollector(doc).OfClass(DB.ViewSheetSet).ToElements()
        self.set_dict = {s.Name: s for s in sets}
        self.comboSets.ItemsSource = ["<All Views/Sheets>"] + sorted(self.set_dict.keys())
        self.comboSets.SelectedIndex = 0

    def load_printers(self):
        try:
            printers = list(Printing.PrinterSettings.InstalledPrinters)
            self.comboPrinters.ItemsSource = printers
            print_mgr = doc.PrintManager
            if print_mgr.PrinterName in printers:
                self.comboPrinters.SelectedItem = print_mgr.PrinterName
            elif printers:
                self.comboPrinters.SelectedIndex = 0
        except Exception as e:
            print("Error loading system printers: {}".format(e))

    def load_print_settings(self):
        try:
            setups = DB.FilteredElementCollector(doc).OfClass(DB.PrintSetting).ToElements()
            self.print_setting_dict = {s.Name: s for s in setups}
            self.comboPrintSettings.ItemsSource = sorted(self.print_setting_dict.keys())
            
            print_mgr = doc.PrintManager
            cur_setting = print_mgr.PrintSetup.CurrentPrintSetting
            if cur_setting and cur_setting.Name in self.print_setting_dict:
                self.comboPrintSettings.SelectedItem = cur_setting.Name
            elif setups:
                self.comboPrintSettings.SelectedIndex = 0
        except Exception as e:
            print("Error loading print settings: {}".format(e))

    def load_dwg_settings(self):
        try:
            setups = DB.FilteredElementCollector(doc).OfClass(DB.ExportDWGSettings).ToElements()
            self.dwg_setting_dict = {s.Name: s for s in setups}
            self.comboDWGSettings.ItemsSource = sorted(self.dwg_setting_dict.keys())
            
            if setups:
                self.comboDWGSettings.SelectedIndex = 0
        except Exception as e:
            print("Error loading DWG settings: {}".format(e))

    def filter_sheets(self):
        keys = sorted(self.sheet_dict.keys())
        
        set_name = self.comboSets.SelectedItem
        if set_name and set_name != "<All Views/Sheets>" and set_name in self.set_dict:
            target_set = self.set_dict[set_name]
            set_view_ids = [v.Id for v in target_set.Views]
            keys = [k for k in keys if self.sheet_dict[k].Id in set_view_ids]
            
        search_str = self.txtSearch.Text.lower() if self.txtSearch.Text else ""
        if search_str:
            keys = [k for k in keys if search_str in k.lower()]
            
        self.listSheets.ItemsSource = keys

    def on_set_filtered(self, sender, args):
        self.filter_sheets()
        self.listSheets.SelectedItems.Clear()
        if self.comboSets.SelectedItem != "<All Views/Sheets>":
            for item in self.listSheets.Items:
                self.listSheets.SelectedItems.Add(item)

    def on_search_changed(self, sender, args):
        self.filter_sheets()

    def on_select_all(self, sender, args):
        self.listSheets.SelectedItems.Clear()
        for item in self.listSheets.Items:
            self.listSheets.SelectedItems.Add(item)

    def on_select_none(self, sender, args):
        self.listSheets.SelectedItems.Clear()

    def on_sheet_selected(self, sender, args):
        try:
            selected = self.listSheets.SelectedItems
            if selected is None or selected.Count != 1:
                self.imgPreview.Source = None
                self.lblPreviewStatus.Text = "Select a single sheet or view to generate live preview..." if (selected is None or selected.Count == 0) else "Multiple items selected. Preview disabled."
                self.lblPreviewStatus.Visibility = System.Windows.Visibility.Visible
                return
                
            item_key = selected[0]
            item = self.sheet_dict.get(item_key)
            if not item:
                self.lblPreviewStatus.Text = "Item not found in dictionary."
                self.lblPreviewStatus.Visibility = System.Windows.Visibility.Visible
                return
            
            self.lblPreviewStatus.Text = "Generating preview for {}...".format(item_key)
            self.lblPreviewStatus.Visibility = System.Windows.Visibility.Visible
            self.imgPreview.Source = None
            
            temp_dir = os.path.join(os.environ.get("TEMP", r"C:\Temp"), "SamTools_Previews")
            if not os.path.exists(temp_dir):
                os.makedirs(temp_dir)
                
            existing_file = None
            prefix = "preview_{}".format(item.Id.IntegerValue)
            for f in os.listdir(temp_dir):
                if f.startswith(prefix) and f.endswith(".png"):
                    existing_file = os.path.join(temp_dir, f)
                    break
                    
            if not existing_file:
                with revit.Transaction("SamTools - Preview Generation"):
                    options = DB.ImageExportOptions()
                    options.FilePath = os.path.join(temp_dir, prefix + ".png")
                    options.ExportRange = DB.ExportRange.SetOfViews
                    v_ids = System.Collections.Generic.List[DB.ElementId]()
                    v_ids.Add(item.Id)
                    options.SetViewsAndSheets(v_ids)
                    options.ZoomType = DB.ZoomFitType.FitToPage
                    options.PixelSize = 1024
                    options.ImageResolution = DB.ImageResolution.DPI_72
                    options.FitDirection = DB.FitDirectionType.Horizontal
                    options.HLRandWFViewsFileType = DB.ImageFileType.PNG
                    options.ShadowViewsFileType = DB.ImageFileType.PNG
                    doc.ExportImage(options)
                
                for f in os.listdir(temp_dir):
                    if f.startswith(prefix) and f.endswith(".png"):
                        existing_file = os.path.join(temp_dir, f)
                        break

            if existing_file and os.path.exists(existing_file):
                bmp = System.Windows.Media.Imaging.BitmapImage()
                bmp.BeginInit()
                bmp.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad
                bmp.UriSource = System.Uri(existing_file)
                bmp.EndInit()
                self.imgPreview.Source = bmp
                self.lblPreviewStatus.Visibility = System.Windows.Visibility.Collapsed
            else:
                self.lblPreviewStatus.Text = "Preview generation failed. Could not find exported PNG."
                self.lblPreviewStatus.Visibility = System.Windows.Visibility.Visible
        except Exception as e:
            self.lblPreviewStatus.Text = "Preview error: {}".format(e)
            self.lblPreviewStatus.Visibility = System.Windows.Visibility.Visible
            print("Error in on_sheet_selected: {}".format(e))

    def on_execute_save_set(self, sender, args):
        action = self.comboSaveSet.Text
        if not action or action == "<Select Save Action>":
            forms.alert("Please select a save action first (New Set, Add to Existing, or Delete Set).")
            return
            
        selected_items = [self.sheet_dict[item] for item in self.listSheets.SelectedItems]
        
        if action == "New Set":
            if not selected_items:
                forms.alert("Please select at least one view/sheet to create a set.")
                return
            set_name = forms.ask_for_string("Enter name for the new View/Sheet Set:")
            if not set_name: return
            
            with revit.Transaction("SamTools - Create ViewSheetSet"):
                try:
                    view_set = DB.ViewSet()
                    for item in selected_items: view_set.Insert(item)
                    print_mgr = doc.PrintManager
                    print_mgr.ViewSheetSetting.CurrentViewSheetSet.Views = view_set
                    print_mgr.ViewSheetSetting.SaveAs(set_name)
                    forms.alert("View/Sheet Set '{}' created successfully!".format(set_name), title="Success")
                    self.load_view_sheet_sets()
                    self.comboSets.SelectedItem = set_name
                except Exception as e:
                    forms.alert("Failed to create set: {}".format(e))
                    
        elif action == "Add to Existing":
            if not selected_items:
                forms.alert("Please select at least one view/sheet to add.")
                return
            set_name = self.comboSets.SelectedItem
            if set_name == "<All Views/Sheets>":
                forms.alert("Please choose an existing set from the 'Filter by V/S Sets' dropdown to add to.")
                return
            with revit.Transaction("SamTools - Update ViewSheetSet"):
                try:
                    target_set = self.set_dict[set_name]
                    view_set = target_set.Views
                    for item in selected_items: view_set.Insert(item)
                    print_mgr = doc.PrintManager
                    print_mgr.ViewSheetSetting.CurrentViewSheetSet = target_set
                    print_mgr.ViewSheetSetting.CurrentViewSheetSet.Views = view_set
                    print_mgr.ViewSheetSetting.Save()
                    forms.alert("Updated set '{}' successfully!".format(set_name), title="Success")
                except Exception as e:
                    forms.alert("Failed to update set: {}".format(e))
                    
        elif action == "Delete Set":
            set_name = self.comboSets.SelectedItem
            if set_name == "<All Views/Sheets>":
                forms.alert("Please choose an existing set from the 'Filter by V/S Sets' dropdown to delete.")
                return
            if forms.alert("Are you sure you want to delete the set '{}'?".format(set_name), yes=True, no=True):
                with revit.Transaction("SamTools - Delete ViewSheetSet"):
                    try:
                        target_set = self.set_dict[set_name]
                        print_mgr = doc.PrintManager
                        print_mgr.ViewSheetSetting.CurrentViewSheetSet = target_set
                        print_mgr.ViewSheetSetting.Delete()
                        forms.alert("Deleted set '{}' successfully!".format(set_name), title="Success")
                        self.load_view_sheet_sets()
                    except Exception as e:
                        forms.alert("Failed to delete set: {}".format(e))

    def update_active_rules_list(self):
        self.listActiveRules.ItemsSource = None
        self.listActiveRules.ItemsSource = self.active_rules

    def update_preview(self, sender, args):
        prefix = self.txtPrefix.Text
        suffix = self.txtSuffix.Text
        separator = self.txtSeparator.Text
        rule_str = separator.join(self.active_rules)
        self.lblPreview.Text = "Custom Name Preview: {}{}{}".format(prefix, rule_str, suffix)

    def on_add_param(self, sender, args):
        sel = self.listAvailableParams.SelectedItem
        if sel:
            param_name = sel.Content
            self.active_rules.append(param_name)
            self.update_active_rules_list()
            self.update_preview(None, None)

    def on_remove_param(self, sender, args):
        sel_idx = self.listActiveRules.SelectedIndex
        if sel_idx >= 0 and sel_idx < len(self.active_rules):
            self.active_rules.pop(sel_idx)
            self.update_active_rules_list()
            self.update_preview(None, None)

    def on_move_up(self, sender, args):
        sel_idx = self.listActiveRules.SelectedIndex
        if sel_idx > 0:
            item = self.active_rules.pop(sel_idx)
            self.active_rules.insert(sel_idx - 1, item)
            self.update_active_rules_list()
            self.listActiveRules.SelectedIndex = sel_idx - 1
            self.update_preview(None, None)

    def on_move_down(self, sender, args):
        sel_idx = self.listActiveRules.SelectedIndex
        if sel_idx >= 0 and sel_idx < len(self.active_rules) - 1:
            item = self.active_rules.pop(sel_idx)
            self.active_rules.insert(sel_idx + 1, item)
            self.update_active_rules_list()
            self.listActiveRules.SelectedIndex = sel_idx + 1
            self.update_preview(None, None)

    def select_folder(self, sender, args):
        path = forms.pick_folder(title="Select Export Directory")
        if path:
            self.output_path = path
            self.lblPath.Text = path
            self.lblPath.Foreground = System.Windows.Media.Brushes.Green

    def cancel(self, sender, args):
        self.Close()

    def run_export(self, sender, args):
        if not self.output_path:
            forms.alert("Please select an output folder in Tab 4.")
            return
        if not self.listSheets.SelectedItems:
            forms.alert("Please select at least one view or sheet in Tab 1.")
            return
            
        items = [self.sheet_dict[item] for item in self.listSheets.SelectedItems]
        order = self.comboPrintOrder.Text
        
        if order == "Sheet Number (Ascending)":
            items.sort(key=lambda x: getattr(x, "SheetNumber", x.Name))
        elif order == "Sheet Number (Descending)":
            items.sort(key=lambda x: getattr(x, "SheetNumber", x.Name), reverse=True)
        elif order == "Sheet Name (Ascending)":
            items.sort(key=lambda x: x.Name)
        elif order == "Sheet Name (Descending)":
            items.sort(key=lambda x: x.Name, reverse=True)
        elif order == "Sheet Issue Date (Ascending)":
            def get_date(elem):
                try:
                    p = elem.Parameter[DB.BuiltInParameter.SHEET_ISSUE_DATE]
                    return p.AsString() if p else ""
                except: return ""
            items.sort(key=get_date)
        elif order == "Creation Order (Element ID)":
            items.sort(key=lambda x: x.Id.IntegerValue)
            
        self.selected_items = items
        self.export_params = {
            "pdf": bool(self.chkPDF.IsChecked),
            "dwg": bool(self.chkDWG.IsChecked),
            "dgn": bool(self.chkDGN.IsChecked),
            "dwf": bool(self.chkDWF.IsChecked),
            "nwc": bool(self.chkNWC.IsChecked),
            "ifc": bool(self.chkIFC.IsChecked),
            "img": bool(self.chkIMG.IsChecked),
            "split_format": bool(self.radioSplitFolder.IsChecked),
            "dwg_setting": self.comboDWGSettings.Text,
            "dwg_merge": bool(self.chkDWGMerge.IsChecked),
            "printer": self.comboPrinters.Text,
            "print_setting": self.comboPrintSettings.Text,
            "combine": bool(self.radioCombine.IsChecked),
            "zoom_100": bool(self.radioZoom100.IsChecked),
            "placement_offset": bool(self.radioPlaceOffset.IsChecked),
            "print_order": order,
            "prefix": self.txtPrefix.Text,
            "suffix": self.txtSuffix.Text,
            "separator": self.txtSeparator.Text,
            "rules": self.active_rules
        }
        self.success = True
        self.Close()

def sanitize(name):
    return re.sub(r'[\\/*?:"<>|]', "", name)

def generate_custom_filename(item, params):
    parts = []
    for rule in params["rules"]:
        if rule == "Sheet Number":
            parts.append(getattr(item, "SheetNumber", item.Name))
        elif rule == "Sheet Name":
            parts.append(item.Name)
        elif rule == "Current Revision":
            try:
                rev_id = item.GetCurrentRevision()
                if rev_id != DB.ElementId.InvalidElementId:
                    rev_elem = doc.GetElement(rev_id)
                    parts.append(rev_elem.RevisionNumber)
                else:
                    parts.append("Rev0")
            except:
                parts.append("Rev0")
        elif rule == "Project Name":
            parts.append(doc.ProjectInformation.Name)
        elif rule == "Project Number":
            parts.append(doc.ProjectInformation.Number)
        elif rule == "Sheet Issue Date":
            try:
                parts.append(item.Parameter[DB.BuiltInParameter.SHEET_ISSUE_DATE].AsString())
            except:
                parts.append(datetime.date.today().strftime("%Y-%m-%d"))
        elif rule == "View Type":
            parts.append(getattr(item, "ViewType", "Sheet").ToString())
        elif rule == "View Name":
            parts.append(item.Name)
        elif rule == "YYYY-MM-DD (Date)":
            parts.append(datetime.date.today().strftime("%Y-%m-%d"))
            
    custom_name = "{}{}{}".format(params["prefix"], params["separator"].join(parts), params["suffix"])
    return sanitize(custom_name)

def main():
    xaml_file = script.get_bundle_file('ui.xaml')
    win = ExportProWindow(xaml_file)
    win.show_dialog()
    
    if not win.success: return
    
    p = win.export_params
    out_dir = win.output_path
    items = win.selected_items
    
    # Run Exports
    with revit.Transaction("SamTools - Multi-Format Batch Export"):
        # 1. PDF Export via pyRevit PrintManager Reference
        if p["pdf"]:
            try:
                cur_out_dir = os.path.join(out_dir, "PDF") if p.get("split_format") else out_dir
                if not os.path.exists(cur_out_dir): os.makedirs(cur_out_dir)
                
                print_mgr = doc.PrintManager
                print_mgr.SelectNewPrintDriver(p["printer"])
                if p["print_setting"] in win.print_setting_dict:
                    print_mgr.PrintSetup.CurrentPrintSetting = win.print_setting_dict[p["print_setting"]]
                    
                print_params = print_mgr.PrintSetup.CurrentPrintSetting.PrintParameters
                if p.get("zoom_100"):
                    print_params.ZoomType = DB.ZoomType.Zoom
                    print_params.Zoom = 100
                else:
                    print_params.ZoomType = DB.ZoomType.FitToPage
                    
                if p.get("placement_offset"):
                    print_params.PaperPlacement = DB.PaperPlacementType.Margins
                    print_params.MarginType = DB.MarginType.NoMargin
                else:
                    print_params.PaperPlacement = DB.PaperPlacementType.Center
                    
                print_mgr.PrintToFile = True
                
                if p["combine"]:
                    print_mgr.CombinedFile = True
                    # Build temporary viewset for combined print
                    view_set = DB.ViewSet()
                    for item in items: view_set.Insert(item)
                    temp_set_name = "SamTools_Temp_CombinedSet"
                    
                    # Clean up if existing
                    try:
                        existing_sets = DB.FilteredElementCollector(doc).OfClass(DB.ViewSheetSet).ToElements()
                        for s in existing_sets:
                            if s.Name == temp_set_name:
                                print_mgr.ViewSheetSetting.CurrentViewSheetSet = s
                                print_mgr.ViewSheetSetting.Delete()
                                break
                    except: pass
                    
                    print_mgr.ViewSheetSetting.CurrentViewSheetSet.Views = view_set
                    print_mgr.ViewSheetSetting.SaveAs(temp_set_name)
                    
                    file_name = os.path.join(cur_out_dir, p["prefix"] + "Combined_DrawingSet.pdf")
                    if os.path.exists(file_name):
                        res = forms.alert("Combined PDF already exists:\n\n{}\n\nOverwrite?".format(file_name), options=["Yes", "No"])
                        if res == "Yes":
                            try: os.remove(file_name)
                            except Exception as e: raise Exception("Could not delete existing file. Make sure it is closed.")
                        else:
                            raise Exception("Export cancelled by user to prevent overwrite.")
                            
                    print_mgr.PrintToFileName = file_name
                    print_mgr.Apply()
                    print_mgr.SubmitPrint()
                else:
                    print_mgr.PrintRange = DB.PrintRange.Select
                    print_mgr.CombinedFile = True
                    overwrite_all = False
                    for item in items:
                        custom_name = generate_custom_filename(item, p)
                        file_name = os.path.join(cur_out_dir, custom_name + ".pdf")
                        
                        if os.path.exists(file_name):
                            if not overwrite_all:
                                res = forms.alert("File already exists:\n\n{}\n\nOverwrite?".format(file_name), options=["Yes", "Yes to All", "No", "Cancel"])
                                if res == "Yes to All": overwrite_all = True
                                elif res == "Yes": pass
                                elif res == "No": continue
                                else: break
                            try: os.remove(file_name)
                            except:
                                print("Could not delete {}. It may be open.".format(file_name))
                                continue
                                
                        print_mgr.PrintToFileName = file_name
                        print_mgr.Apply()
                        print_mgr.SubmitPrint(item)
            except Exception as e:
                forms.alert("PDF Export encountered an error: {}".format(e), title="PDF Export Warning")

        # 2. DWG Export
        if p["dwg"]:
            try:
                cur_out_dir = os.path.join(out_dir, "DWG") if p.get("split_format") else out_dir
                if not os.path.exists(cur_out_dir): os.makedirs(cur_out_dir)
                
                options = DB.DWGExportOptions()
                if p.get("dwg_setting") and hasattr(win, "dwg_setting_dict") and p["dwg_setting"] in win.dwg_setting_dict:
                    options = win.dwg_setting_dict[p["dwg_setting"]].GetDWGExportOptions()
                    
                options.MergedViews = not p.get("dwg_merge", False)
                
                for item in items:
                    custom_name = generate_custom_filename(item, p)
                    v_ids = System.Collections.Generic.List[DB.ElementId]()
                    v_ids.Add(item.Id)
                    doc.Export(cur_out_dir, custom_name, v_ids, options)
            except Exception as e:
                forms.alert("DWG Export encountered an error: {}".format(e), title="DWG Export Warning")

        # 3. DGN Export
        if p["dgn"]:
            try:
                cur_out_dir = os.path.join(out_dir, "DGN") if p.get("split_format") else out_dir
                if not os.path.exists(cur_out_dir): os.makedirs(cur_out_dir)
                
                options = DB.DGNExportOptions()
                for item in items:
                    custom_name = generate_custom_filename(item, p)
                    v_ids = System.Collections.Generic.List[DB.ElementId]()
                    v_ids.Add(item.Id)
                    doc.Export(cur_out_dir, custom_name, v_ids, options)
            except Exception as e:
                forms.alert("DGN Export encountered an error: {}".format(e), title="DGN Export Warning")

        # 4. DWF Export
        if p["dwf"]:
            try:
                cur_out_dir = os.path.join(out_dir, "DWF") if p.get("split_format") else out_dir
                if not os.path.exists(cur_out_dir): os.makedirs(cur_out_dir)
                
                options = DB.DWFExportOptions()
                for item in items:
                    custom_name = generate_custom_filename(item, p)
                    v_ids = System.Collections.Generic.List[DB.ElementId]()
                    v_ids.Add(item.Id)
                    doc.Export(cur_out_dir, custom_name, v_ids, options)
            except Exception as e:
                forms.alert("DWF Export encountered an error: {}".format(e), title="DWF Export Warning")

        # 5. NWC Export
        if p["nwc"]:
            try:
                cur_out_dir = os.path.join(out_dir, "NWC") if p.get("split_format") else out_dir
                if not os.path.exists(cur_out_dir): os.makedirs(cur_out_dir)
                
                options = DB.NWCExportOptions()
                doc.Export(cur_out_dir, p["prefix"] + "Navisworks_Model.nwc", options)
            except Exception as e:
                forms.alert("NWC Export requires Navisworks Exporter add-in installed in Revit.\nError: {}".format(e), title="NWC Export Warning")

        # 6. IFC Export
        if p["ifc"]:
            try:
                cur_out_dir = os.path.join(out_dir, "IFC") if p.get("split_format") else out_dir
                if not os.path.exists(cur_out_dir): os.makedirs(cur_out_dir)
                
                options = DB.IFCExportOptions()
                doc.Export(cur_out_dir, p["prefix"] + "BIM_Model.ifc", options)
            except Exception as e:
                forms.alert("IFC Export encountered an error: {}".format(e), title="IFC Export Warning")

        # 7. IMG Export
        if p["img"]:
            try:
                cur_out_dir = os.path.join(out_dir, "IMG") if p.get("split_format") else out_dir
                if not os.path.exists(cur_out_dir): os.makedirs(cur_out_dir)
                
                for item in items:
                    custom_name = generate_custom_filename(item, p)
                    options = DB.ImageExportOptions()
                    options.FilePath = os.path.join(cur_out_dir, custom_name + ".png")
                    options.ExportRange = DB.ExportRange.SetOfViews
                    v_ids = System.Collections.Generic.List[DB.ElementId]()
                    v_ids.Add(item.Id)
                    options.SetViewsAndSheets(v_ids)
                    options.ZoomType = DB.ZoomFitType.FitToPage
                    options.PixelSize = 2048
                    doc.ExportImage(options)
            except Exception as e:
                forms.alert("IMG Export encountered an error: {}".format(e), title="IMG Export Warning")

    # Open output directory when finished
    try:
        os.startfile(out_dir)
    except: pass
    
    forms.alert("Premium Multi-Format Export Pro Complete!", title="Batch Success")

if __name__ == '__main__':
    main()
