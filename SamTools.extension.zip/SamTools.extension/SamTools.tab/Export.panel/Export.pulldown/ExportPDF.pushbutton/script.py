# -*- coding: utf-8 -*-
"""Comprehensive Batch PDF Export Orchestrator"""

__title__ = 'Export PDF'
__author__ = 'SamTools'

from samtools.exporter import run_exporter

if __name__ == '__main__':
    run_exporter(default_format="PDF")
