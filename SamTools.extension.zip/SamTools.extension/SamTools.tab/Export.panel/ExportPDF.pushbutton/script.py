# -*- coding: utf-8 -*-
"""Comprehensive Batch PDF Export Orchestrator"""

__title__ = 'Export PDF'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script
import datetime

doc = revit.doc

class PDFExportWindow(forms.WPFWindow):
    def __init__(self, xaml_file):
        forms.WPFWindow.__init__(self, xaml_file)
        
        # Load Sheets
        sheets = DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet).ToElements()
        self.sheet_dict = {"{} - {}".format(s.SheetNumber, s.Name): s for s in sheets}
        self.listSheets.ItemsSource = sorted(self.sheet_dict.keys())
        
        # Load Sets
        sets = DB.FilteredElementCollector(doc).OfClass(DB.ViewSheetSet).ToElements()
        self.set_dict = {s.Name: s for s in sets}
        self.comboSets.ItemsSource = ["<Manual Selection>"] + sorted(self.set_dict.keys())
        self.comboSets.SelectedIndex = 0
        self.comboSets.SelectionChanged += self.on_set_changed
        
        self.btnBrowse.Click += self.select_folder
        self.btnCancel.Click += self.cancel
        self.btnExport.Click += self.run_export
        self.success = False
        self.output_path = ""

    def on_set_changed(self, sender, args):
        set_name = self.comboSets.SelectedItem
        if set_name == "<Manual Selection>": 
            self.listSheets.SelectedItems.Clear()
            return
            
        target_set = self.set_dict[set_name]
        set_views = [v.Id for v in target_set.Views]
        
        self.listSheets.SelectedItems.Clear()
        for item in self.listSheets.Items:
            if self.sheet_dict[item].Id in set_views:
                self.listSheets.SelectedItems.Add(item)

    def select_folder(self, sender, args):
        path = forms.pick_folder(title="Select Output Directory")
        if path:
            self.output_path = path
            self.lblPath.Text = path
            self.lblPath.Foreground = System.Windows.Media.Brushes.Green

    def cancel(self, sender, args):
        self.Close()
        
    def run_export(self, sender, args):
        if not self.output_path:
            forms.alert("Please select an output folder.")
            return
            
        self.selected_sheets = [self.sheet_dict[s] for s in self.listSheets.SelectedItems]
        if not self.selected_sheets:
            forms.alert("Please select at least one sheet.")
            return
            
        self.export_params = {
            "combine": bool(self.chkCombine.IsChecked),
            "prefix": self.txtPrefix.Text,
            "filename": self.txtFileName.Text,
            "hide_ref": bool(self.chkHideRef.IsChecked),
            "hide_crop": bool(self.chkHideCrop.IsChecked),
            "hide_scope": bool(self.chkHideScope.IsChecked),
            "hide_unref": bool(self.chkHideUnref.IsChecked)
        }
        self.success = True
        self.Close()

def main():
    xaml_file = script.get_bundle_file('ui.xaml')
    win = PDFExportWindow(xaml_file)
    win.show_dialog()
    
    if not win.success: return
    
    # Execute Export (Revit 2022+)
    with revit.Transaction("SamTools - Premium PDF Export"):
        try:
            options = DB.PDFExportOptions()
            options.Combine = win.export_params["combine"]
            # Visibility Settings
            try:
                options.HideUnreferencedViewTags = win.export_params["hide_unref"]
                options.HideScopeBoxes = win.export_params["hide_scope"]
                options.HideCropBoundaries = win.export_params["hide_crop"]
            except: pass
            
            filename = "{}{}".format(win.export_params["prefix"], win.export_params["filename"])
            
            sheet_ids = System.Collections.Generic.List[DB.ElementId]()
            for s in win.selected_sheets: sheet_ids.Add(s.Id)
            
            doc.Export(win.output_path, filename, sheet_ids, options)
            forms.alert("Advanced PDF Orchestration Complete!", title="Success")
        except Exception as e:
            forms.alert("Advanced Export Failed.\nRevit 2022+ required for native PDF API.\nError: {}".format(str(e)), title="Error")

if __name__ == '__main__':
    import System
    main()
