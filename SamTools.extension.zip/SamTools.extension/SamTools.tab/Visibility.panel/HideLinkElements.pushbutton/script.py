# -*- coding: utf-8 -*-
"""SOMA AI | Visibility Orchestrator - Collision Fix."""

__title__ = "Hide Link\nElements"
__author__ = "SOMA AI"

import clr
clr.AddReference("PresentationFramework")
clr.AddReference("PresentationCore")
clr.AddReference("WindowsBase")

import System.Windows
import System.Windows.Controls as Controls
import System.Windows.Media as Media
from System.Collections.Generic import List
from System.Windows import Window, Thickness, HorizontalAlignment, VerticalAlignment, WindowStartupLocation, WindowStyle, ResizeMode, FontWeight, FontWeights
from System.Windows.Media import SolidColorBrush, ColorConverter

from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from pyrevit import revit, forms, script

# Initialize environment
doc = revit.doc
uidoc = revit.uidoc
view = doc.ActiveView

class LinkedElementFilter(ISelectionFilter):
    def AllowElement(self, element):
        return isinstance(element, RevitLinkInstance)
    def AllowReference(self, reference, position):
        return True

class SOMA_UI(Window):
    def __init__(self):
        self.Title = "SOMA AI | Visibility Orchestrator"
        self.Width = 420
        self.Height = 480
        self.WindowStartupLocation = WindowStartupLocation.CenterScreen
        self.WindowStyle = WindowStyle.None
        self.ResizeMode = ResizeMode.NoResize
        self.Background = self.brush("#1A1A1A")
        self.AllowsTransparency = True
        self.selection_mode = None

        # Main Layout - Using Controls.Grid to avoid collision with Revit DB.Grid
        root = Controls.Grid()
        root.Margin = Thickness(1)
        
        # Shadow effect
        try:
            clr.AddReference("System.Windows.Presentation")
            from System.Windows.Media.Effects import DropShadowEffect
            shadow = DropShadowEffect()
            shadow.Color = self.color("#007ACC")
            shadow.BlurRadius = 10
            shadow.ShadowDepth = 0
            root.Effect = shadow
        except:
            pass 

        main_stack = Controls.StackPanel()
        main_stack.Margin = Thickness(20)
        root.Children.Add(main_stack)

        # Header
        header_text = Controls.TextBlock()
        header_text.Text = "SOMA AI"
        header_text.Foreground = self.brush("#007ACC")
        header_text.FontSize = 28
        header_text.FontWeight = FontWeights.Bold
        header_text.HorizontalAlignment = HorizontalAlignment.Center
        main_stack.Children.Add(header_text)

        sub_header = Controls.TextBlock()
        sub_header.Text = "VISIBILITY ORCHESTRATOR"
        sub_header.Foreground = self.brush("#888888")
        sub_header.FontSize = 10
        sub_header.HorizontalAlignment = HorizontalAlignment.Center
        sub_header.Margin = Thickness(0, 5, 0, 20)
        main_stack.Children.Add(sub_header)

        # Options Container
        options_stack = Controls.StackPanel()
        main_stack.Children.Add(options_stack)

        # Buttons
        self.add_option(options_stack, "BtnPrecision", "🎯", "Precision Selection", "Pick individual elements from links to hide.")
        self.add_option(options_stack, "BtnCategory", "🔥", "Category Blast", "Select one element to hide its entire category.")
        self.add_option(options_stack, "BtnRestore", "🔄", "Restore All", "Reset all hidden linked elements in this view.")

        # Footer
        footer_grid = Controls.Grid()
        footer_grid.Margin = Thickness(0, 30, 0, 0)
        main_stack.Children.Add(footer_grid)

        footer_text = Controls.TextBlock()
        footer_text.Text = "SamTools v1.0 | SOMA.AI"
        footer_text.Foreground = self.brush("#444444")
        footer_text.FontSize = 9
        footer_grid.Children.Add(footer_text)

        close_btn = Controls.Button()
        close_btn.Content = "CLOSE"
        close_btn.Width = 80
        close_btn.HorizontalAlignment = HorizontalAlignment.Right
        close_btn.Background = self.brush("#252525")
        close_btn.Foreground = self.brush("#888888")
        close_btn.Click += self.on_close
        footer_grid.Children.Add(close_btn)

        self.Content = root

    def brush(self, hex_color):
        return SolidColorBrush(self.color(hex_color))

    def color(self, hex_color):
        return ColorConverter.ConvertFromString(hex_color)

    def add_option(self, parent, name, emoji, title, desc):
        btn = Controls.Button()
        btn.Height = 70
        btn.Margin = Thickness(0, 5, 0, 5)
        btn.Background = self.brush("#252525")
        btn.BorderThickness = Thickness(0)
        btn.Click += getattr(self, "on_" + name.lower())
        
        stack = Controls.StackPanel()
        stack.Orientation = Controls.Orientation.Horizontal
        stack.Width = 340
        
        icon = Controls.TextBlock()
        icon.Text = emoji
        icon.FontSize = 26
        icon.Margin = Thickness(15, 0, 15, 0)
        icon.VerticalAlignment = VerticalAlignment.Center
        stack.Children.Add(icon)
        
        txt_stack = Controls.StackPanel()
        txt_stack.VerticalAlignment = VerticalAlignment.Center
        
        t_text = Controls.TextBlock()
        t_text.Text = title
        t_text.Foreground = self.brush("#FFFFFF")
        t_text.FontWeight = FontWeights.Bold
        txt_stack.Children.Add(t_text)
        
        d_text = Controls.TextBlock()
        d_text.Text = desc
        d_text.Foreground = self.brush("#666666")
        d_text.FontSize = 10
        txt_stack.Children.Add(d_text)
        
        stack.Children.Add(txt_stack)
        btn.Content = stack
        parent.Children.Add(btn)

    def on_btnprecision(self, sender, e):
        self.selection_mode = "precision"
        self.Close()

    def on_btncategory(self, sender, e):
        self.selection_mode = "category"
        self.Close()

    def on_btnrestore(self, sender, e):
        self.selection_mode = "reset"
        self.Close()

    def on_close(self, sender, e):
        self.Close()

def run_precision():
    # Clear current selection to ensure a fresh start
    uidoc.Selection.SetElementIds(List[ElementId]())
    
    # Check for View Template (EH is disabled if a template controls visibility)
    if view.ViewTemplateId != ElementId.InvalidElementId:
        forms.alert("This view has a View Template assigned. Permanent Hiding (EH) may be disabled by the template.", 
                    title="SOMA AI Warning", warn_icon=True)
    
    try:
        # Prompt user to select and use the Finish button
        picked_refs = uidoc.Selection.PickObjects(
            ObjectType.LinkedElement, 
            "SOMA | Select elements from link, then click 'Finish' in the Options Bar (Top-Left)."
        )
        
        if picked_refs:
            # Set the selection to the picked references
            uidoc.Selection.SetReferences(picked_refs)
            
            # Post the built-in 'Hide in View > Elements' (EH) command
            # This command is permanent and persists in the view.
            hide_cmd = RevitCommandId.LookupPostableCommandId(PostableCommand.HideElements)
            
            if uidoc.CanPostCommand(hide_cmd):
                uidoc.PostCommand(hide_cmd)
                forms.toast("EH (Permanent Hide) applied to {} items.".format(len(picked_refs)), title="SOMA AI")
            else:
                forms.alert("The 'Hide Elements' command is currently unavailable in this view.")
    except:
        # User likely pressed Escape or Cancelled
        pass

def run_category_blast():
    uidoc.Selection.SetElementIds(List[ElementId]())
    try:
        # For category blast, we only need one pick
        ref = uidoc.Selection.PickObject(
            ObjectType.LinkedElement, 
            "SOMA | Select ONE element to hide its CATEGORY in this link."
        )
        if ref:
            uidoc.Selection.SetReferences([ref])
            cmd_id = RevitCommandId.LookupPostableCommandId(PostableCommand.HideCategory)
            if uidoc.CanPostCommand(cmd_id):
                uidoc.PostCommand(cmd_id)
                forms.toast("Category hidden.", title="SOMA AI")
    except:
        pass

def main():
    ui = SOMA_UI()
    ui.ShowDialog()

    if ui.selection_mode == "precision":
        run_precision()
    elif ui.selection_mode == "category":
        run_category_blast()
    elif ui.selection_mode == "reset":
        forms.alert("Manual reset: Use the Lightbulb icon to Reveal Hidden Elements.", title="SOMA AI Info")

if __name__ == "__main__":
    main()
