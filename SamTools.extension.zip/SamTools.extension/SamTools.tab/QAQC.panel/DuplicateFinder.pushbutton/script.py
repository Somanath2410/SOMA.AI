# -*- coding: utf-8 -*-
"""Find Duplicate Marks in Category"""

__title__ = 'Duplicate\nFinder'
__author__ = 'SamTools'

from pyrevit import revit, DB, forms, script

doc = revit.doc
output = script.get_output()

class DuplicateFinderWindow(forms.WPFWindow):
    def __init__(self, xaml_file):
        forms.WPFWindow.__init__(self, xaml_file)
        self.cat_names = ["Walls", "Doors", "Windows", "Rooms", "Furniture"]
        self.comboCategory.ItemsSource = self.cat_names
        self.comboCategory.SelectedIndex = 1 # Default to Doors
        
        self.btnCancel.Click += self.cancel
        self.btnScan.Click += self.run_scan
        self.success = False

    def cancel(self, sender, args):
        self.Close()
        
    def run_scan(self, sender, args):
        self.selected_cat = self.comboCategory.SelectedItem
        self.success = True
        self.Close()

def main():
    xaml_file = script.get_bundle_file('ui.xaml')
    win = DuplicateFinderWindow(xaml_file)
    win.show_dialog()
    
    if not win.success: return
    selected_cat_name = win.selected_cat
    
    bic_map = {
        "Walls": DB.BuiltInCategory.OST_Walls,
        "Doors": DB.BuiltInCategory.OST_Doors,
        "Windows": DB.BuiltInCategory.OST_Windows,
        "Rooms": DB.BuiltInCategory.OST_Rooms,
        "Furniture": DB.BuiltInCategory.OST_Furniture
    }
    
    elements = DB.FilteredElementCollector(doc).OfCategory(bic_map[selected_cat_name]).WhereElementIsNotElementType().ToElements()
    
    mark_dict = {}
    duplicates = []
    
    for el in elements:
        mark = None
        p_mark = el.get_Parameter(DB.BuiltInParameter.ALL_MODEL_MARK)
        if p_mark:
            mark = p_mark.AsString()
            
        if not mark:
            p_room = el.get_Parameter(DB.BuiltInParameter.ROOM_NUMBER)
            if p_room:
                mark = p_room.AsString()
               
        if mark:
            if mark in mark_dict:
                duplicates.append((mark, el.Id))
                if mark_dict[mark] not in duplicates:
                    duplicates.append((mark, mark_dict[mark]))
            else:
                mark_dict[mark] = el.Id
                
    if not duplicates:
        forms.alert("No duplicate Marks found in category {}.".format(selected_cat_name), title="Clean Model")
    else:
        output.print_md("# Duplicate Marks Found: {}".format(selected_cat_name))
        for mark, el_id in duplicates:
            print("Mark: {} | ID: {}".format(mark, el_id))
        
        # Option to select them
        if forms.alert("Duplicates found. Would you like to select them in Revit?", yes=True, no=True):
            revit.get_selection().set_to([el_id for m, el_id in duplicates])

if __name__ == '__main__':
    main()
