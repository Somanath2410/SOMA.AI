using System;
using Autodesk.Revit.UI;

namespace SamToolsCore.Providers
{
    /// <summary>
    /// This is the core provider required by Revit to instantiate our Dockable Control Center.
    /// It must be registered during the Revit Application OnStartup phase.
    /// </summary>
    public class ControlCenterProvider : IDockablePaneProvider
    {
        // Unique GUID for the SamTools Structural Control Center
        public static readonly DockablePaneId PaneId = new DockablePaneId(new Guid("D53B26AF-89B4-4D1C-A1A8-79C0A97E0C39"));

        private readonly Views.ControlCenterPane _paneControl;

        public ControlCenterProvider(Views.ControlCenterPane paneControl)
        {
            _paneControl = paneControl;
        }

        public void SetupDockablePane(DockablePaneProviderData data)
        {
            data.FrameworkElement = _paneControl;
            
            // Set up initial state of the dockable pane (Docked to the right by default like Properties)
            data.InitialState = new DockablePaneState
            {
                DockPosition = DockPosition.Right,
                MinimumWidth = 350,
                MinimumHeight = 500
            };
        }
    }
}
