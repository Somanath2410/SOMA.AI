using System.Windows.Controls;

namespace SamToolsCore.Views
{
    /// <summary>
    /// Interaction logic for ControlCenterPane.xaml
    /// </summary>
    public partial class ControlCenterPane : UserControl
    {
        public ControlCenterPane()
        {
            InitializeComponent();
        }
    }
}
