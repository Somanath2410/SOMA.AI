using System;
using System.Data.SQLite;
using System.IO;

namespace SamToolsCore.DataAccess
{
    public class DatabaseContext
    {
        private string _connectionString;

        public DatabaseContext(string dbPath)
        {
            _connectionString = $"Data Source={dbPath};Version=3;";
            InitializeDatabase(dbPath);
        }

        private void InitializeDatabase(string dbPath)
        {
            if (!File.Exists(dbPath))
            {
                SQLiteConnection.CreateFile(dbPath);
                using (var connection = new SQLiteConnection(_connectionString))
                {
                    connection.Open();

                    // Create tables for QAQC warnings, project settings, etc.
                    string createSettingsTable = @"
                        CREATE TABLE IF NOT EXISTS ProjectSettings (
                            Key TEXT PRIMARY KEY,
                            Value TEXT NOT NULL
                        )";

                    string createWarningsTable = @"
                        CREATE TABLE IF NOT EXISTS QAQCWarnings (
                            Id INTEGER PRIMARY KEY AUTOINCREMENT,
                            ElementId INTEGER NOT NULL,
                            Category TEXT NOT NULL,
                            Severity TEXT NOT NULL,
                            Description TEXT NOT NULL,
                            Timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                        )";

                    using (var command = new SQLiteCommand(createSettingsTable, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                    
                    using (var command = new SQLiteCommand(createWarningsTable, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }
            }
        }

        public SQLiteConnection GetConnection()
        {
            return new SQLiteConnection(_connectionString);
        }
    }
}
