using System;
using SamToolsCore.Models;

namespace SamToolsCore.Services
{
    public interface ICodeEngine
    {
        string CodeName { get; }

        // Column Validation
        bool ValidateColumnSlenderness(StructuralElementData element);
        bool ValidateColumnReinforcementRatio(StructuralElementData element, double providedRatio);

        // Beam Validation
        bool ValidateBeamSpanToDepth(StructuralElementData element, double span, double depth);
        bool ValidateBeamDeflection(StructuralElementData element, double calculatedDeflection, double allowableDeflection);

        // Slab Validation
        bool ValidateSlabThickness(StructuralElementData element, double span, bool isTwoWay);

        // General
        double CalculateRequiredCover(StructuralElementData element, string exposureClass);
    }
}
