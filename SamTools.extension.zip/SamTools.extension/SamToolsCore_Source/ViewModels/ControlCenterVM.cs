using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace SamToolsCore.ViewModels
{
    public class ControlCenterVM : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private string _projectName = "No Project Loaded";
        public string ProjectName
        {
            get { return _projectName; }
            set { _projectName = value; OnPropertyChanged(); }
        }

        private string _currentLevel = "Level 1";
        public string CurrentLevel
        {
            get { return _currentLevel; }
            set { _currentLevel = value; OnPropertyChanged(); }
        }

        private string _currentSelectionCount = "0 Elements";
        public string CurrentSelectionCount
        {
            get { return _currentSelectionCount; }
            set { _currentSelectionCount = value; OnPropertyChanged(); }
        }

        private ObservableCollection<string> _availableDesignCodes;
        public ObservableCollection<string> AvailableDesignCodes
        {
            get { return _availableDesignCodes; }
            set { _availableDesignCodes = value; OnPropertyChanged(); }
        }

        private string _selectedDesignCode;
        public string SelectedDesignCode
        {
            get { return _selectedDesignCode; }
            set { _selectedDesignCode = value; OnPropertyChanged(); }
        }

        // Live Statistics
        private int _totalColumns = 0;
        public int TotalColumns { get { return _totalColumns; } set { _totalColumns = value; OnPropertyChanged(); } }

        private int _totalBeams = 0;
        public int TotalBeams { get { return _totalBeams; } set { _totalBeams = value; OnPropertyChanged(); } }

        private int _totalSlabs = 0;
        public int TotalSlabs { get { return _totalSlabs; } set { _totalSlabs = value; OnPropertyChanged(); } }

        // QAQC Stats
        private int _warningCount = 0;
        public int WarningCount { get { return _warningCount; } set { _warningCount = value; OnPropertyChanged(); } }

        private int _disconnectedCount = 0;
        public int DisconnectedCount { get { return _disconnectedCount; } set { _disconnectedCount = value; OnPropertyChanged(); } }

        public ControlCenterVM()
        {
            AvailableDesignCodes = new ObservableCollection<string>
            {
                "IS 456 (India)",
                "IS 13920 (Seismic India)",
                "BS 8110 (British)",
                "Eurocode 2 (Europe)",
                "ACI 318 (USA)"
            };
            SelectedDesignCode = AvailableDesignCodes[0];
        }

        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
