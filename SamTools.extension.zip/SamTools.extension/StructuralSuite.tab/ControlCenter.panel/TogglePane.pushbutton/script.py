# -*- coding: utf-8 -*-

import clr
import System
from pyrevit import revit, UI

# The GUID must match the one defined in ControlCenterProvider.cs
PANE_ID_GUID = System.Guid("D53B26AF-89B4-4D1C-A1A8-79C0A97E0C39")
pane_id = UI.DockablePaneId(PANE_ID_GUID)

try:
    # Attempt to get the registered dockable pane
    pane = revit.uidoc.Application.GetDockablePane(pane_id)
    
    # Toggle visibility
    if pane.IsShown():
        pane.Hide()
    else:
        pane.Show()
except Exception as e:
    from pyrevit import forms
    forms.alert("The Control Center dockable pane is not registered.\n\nMake sure SamToolsCore.dll is compiled and placed in the 'bin' folder, and that you have restarted Revit.", title="Pane Not Found")
