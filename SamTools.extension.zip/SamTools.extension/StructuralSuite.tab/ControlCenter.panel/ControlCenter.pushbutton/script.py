# -*- coding: utf-8 -*-
from pyrevit import revit, DB, UI
from pyrevit import forms
import sys
import os

# Import our shared SamToolsStructural Library
sys.path.append(os.path.join(os.path.dirname(__file__), "..", "..", "..", "lib"))
from SamToolsStructural.viewmodels import ControlCenterVM
from SamToolsStructural import database, qaqc_engine

doc = revit.doc

class ModelessControlCenter(forms.WPFWindow):
    def __init__(self, xaml_file_name, vm):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.vm = vm
        self.DataContext = self.vm
        
        # Bind events
        self.btnRefresh.Click += self.refresh_stats
        self.btnRunQAQC.Click += self.run_qaqc
        
        self.btnAutoColumn.Click += self.stub_feature
        self.btnAutoBeam.Click += self.stub_feature
        self.btnAutoSlab.Click += self.stub_feature
        self.btnAutoWall.Click += self.stub_feature
        self.btnAutoFoundation.Click += self.stub_feature
        self.btnSmartStairs.Click += self.stub_feature
        
        self.refresh_stats(None, None)
        
    def refresh_stats(self, sender, args):
        if not doc:
            return
            
        self.vm.ProjectName = doc.Title
        
        active_view = doc.ActiveView
        if hasattr(active_view, "GenLevel") and active_view.GenLevel:
            self.vm.CurrentLevel = active_view.GenLevel.Name
        else:
            self.vm.CurrentLevel = "Multiple/None"
            
        selection = revit.uidoc.Selection.GetElementIds()
        self.vm.CurrentSelectionCount = "{} Elements".format(len(selection))
        
        # Count Elements
        cols = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_StructuralColumns).WhereElementIsNotElementType().ToElements()
        beams = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_StructuralFraming).WhereElementIsNotElementType().ToElements()
        slabs = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Floors).WhereElementIsNotElementType().ToElements()
        
        self.vm.TotalColumns = len(cols)
        self.vm.TotalBeams = len(beams)
        self.vm.TotalSlabs = len(slabs)
        
    def run_qaqc(self, sender, args):
        duplicates = qaqc_engine.find_duplicate_elements(doc, DB.BuiltInCategory.OST_StructuralColumns)
        unconnected = qaqc_engine.find_unconnected_columns(doc)
        
        self.vm.WarningCount = len(duplicates)
        self.vm.DisconnectedCount = len(unconnected)
        
        # Save to DB
        for dup_pair in duplicates:
            database.log_qaqc_warning(dup_pair[0].Id.IntegerValue, "Columns", "High", "Duplicate Element")
            
        forms.alert("QAQC Check Complete!\nFound {} Duplicates\nFound {} Unconnected".format(len(duplicates), len(unconnected)))

    def stub_feature(self, sender, args):
        # We can detect which button was clicked based on sender.Name
        button_name = sender.Name
        
        tool_map = {
            "btnAutoColumn": "Auto Column",
            "btnAutoBeam": "Auto Beam",
            "btnAutoSlab": "Auto Slab",
            "btnAutoFoundation": "Auto Foundation"
        }
        
        if button_name in tool_map:
            forms.alert("Please use the dedicated '{}' button located on the 'Modeling' panel in the StructuralSuite Ribbon!".format(tool_map[button_name]))
        else:
            forms.alert("This automation module is scheduled for Phase 5 development.")

# Launch Modal (Safest approach for pure Python)
vm = ControlCenterVM()
win = ModelessControlCenter('ui.xaml', vm)
win.ShowDialog()
