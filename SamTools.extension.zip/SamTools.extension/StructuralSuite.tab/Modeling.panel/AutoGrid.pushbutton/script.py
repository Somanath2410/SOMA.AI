# -*- coding: utf-8 -*-
from pyrevit import revit, DB, UI, forms
import sys
import os
import string

doc = revit.doc

class AutoGridWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.dialog_result = False
        
        # Load Level Types
        level_types = DB.FilteredElementCollector(doc).OfClass(DB.LevelType).ToElements()
        self.level_types = {}
        for t in level_types:
            try:
                name = t.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString()
            except Exception:
                name = "LevelType_" + str(t.Id.IntegerValue)
            if name: self.level_types[name] = t
            
        self.comboLevelTypes.ItemsSource = sorted(self.level_types.keys())
        if self.level_types: self.comboLevelTypes.SelectedIndex = 0
        
        # Load Grid Types
        grid_types = DB.FilteredElementCollector(doc).OfClass(DB.GridType).ToElements()
        self.grid_types = {}
        for t in grid_types:
            try:
                name = t.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString()
            except Exception:
                name = "GridType_" + str(t.Id.IntegerValue)
            if name: self.grid_types[name] = t
            
        self.comboGridTypes.ItemsSource = sorted(self.grid_types.keys())
        if self.grid_types: self.comboGridTypes.SelectedIndex = 0
        
        # Events
        self.btnGenerate.Click += self.generate
        self.btnCancel.Click += self.close
        
    def close(self, sender, args):
        self.dialog_result = False
        self.Close()
        
    def generate(self, sender, args):
        try:
            self.l_qty = int(self.txtLevelQty.Text)
            self.l_space = float(self.txtLevelHeight.Text)
            self.v_qty = int(self.txtVerticalQty.Text)
            self.v_space = float(self.txtVerticalSpacing.Text)
            self.h_qty = int(self.txtHorizontalQty.Text)
            self.h_space = float(self.txtHorizontalSpacing.Text)
        except Exception:
            forms.alert("Please enter valid numbers for quantity and spacing.")
            return
            
        if self.v_qty < 1 or self.h_qty < 1 or self.l_qty < 1:
            forms.alert("Quantity must be at least 1.")
            return
            
        if not self.comboLevelTypes.SelectedItem:
            forms.alert("Please select a Level Type.")
            return
        if not self.comboGridTypes.SelectedItem:
            forms.alert("Please select a Grid Type.")
            return
            
        self.level_type = self.level_types[self.comboLevelTypes.SelectedItem]
        self.grid_type = self.grid_types[self.comboGridTypes.SelectedItem]
            
        self.dialog_result = True
        self.Close()

def get_alphabetical_label(index):
    """Convert index 0 -> A, 25 -> Z, 26 -> AA, etc."""
    result = ""
    while index >= 0:
        result = string.ascii_uppercase[index % 26] + result
        index = index // 26 - 1
    return result

win = AutoGridWindow('ui.xaml')
win.ShowDialog()

# --- EXECUTE AFTER WINDOW CLOSES TO PREVENT FATAL ERRORS ---
if win.dialog_result:
    count_levels = 0
    count_grids = 0
    
    with revit.Transaction("Project Setup (Levels & Grids)"):
        # Generate Levels
        # Check existing levels to avoid duplicate names
        existing_levels = list(DB.FilteredElementCollector(doc).OfClass(DB.Level).ToElements())
        max_elev = max([l.Elevation for l in existing_levels]) if existing_levels else 0.0
        
        for i in range(win.l_qty):
            elev = max_elev + (i + 1) * win.l_space
            lvl = DB.Level.Create(doc, elev)
            lvl.Name = "Level {}".format(len(existing_levels) + i + 1)
            lvl.ChangeTypeId(win.level_type.Id)
            count_levels += 1
        
        # Generate Vertical Grids (Numerical)
        start_y = -10.0
        end_y = (win.h_qty - 1) * win.h_space + 10.0
        
        for i in range(win.v_qty):
            x = i * win.v_space
            start = DB.XYZ(x, start_y, 0)
            end = DB.XYZ(x, end_y, 0)
            line = DB.Line.CreateBound(start, end)
            
            grid = DB.Grid.Create(doc, line)
            grid.Name = str(i + 1)
            grid.ChangeTypeId(win.grid_type.Id)
            count_grids += 1
            
        # Generate Horizontal Grids (Alphabetical)
        start_x = -10.0
        end_x = (win.v_qty - 1) * win.v_space + 10.0
        
        for i in range(win.h_qty):
            y = i * win.h_space
            start = DB.XYZ(start_x, y, 0)
            end = DB.XYZ(end_x, y, 0)
            line = DB.Line.CreateBound(start, end)
            
            grid = DB.Grid.Create(doc, line)
            grid.Name = get_alphabetical_label(i)
            grid.ChangeTypeId(win.grid_type.Id)
            count_grids += 1
            
    forms.alert("Successfully generated {} Levels and {} Grids!".format(count_levels, count_grids))
