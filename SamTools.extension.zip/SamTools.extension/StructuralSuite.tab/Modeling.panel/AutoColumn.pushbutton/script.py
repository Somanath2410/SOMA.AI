# -*- coding: utf-8 -*-
from pyrevit import revit, DB, UI, forms
import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), "..", "..", "..", "lib"))
from SamToolsStructural import code_engines, database

doc = revit.doc

class AutoColumnWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.dialog_result = False
        
        # Load Levels
        self.levels = list(DB.FilteredElementCollector(doc).OfClass(DB.Level).ToElements())
        self.levels.sort(key=lambda l: l.Elevation)
        
        self.listLevels.ItemsSource = [l.Name for l in self.levels]
            
        # Load Column Types
        col_types = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_StructuralColumns).OfClass(DB.FamilySymbol).ToElements()
        self.column_types = {t.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString(): t for t in col_types}
        
        self.comboFamilyTypes.ItemsSource = sorted(self.column_types.keys())
        if self.column_types: self.comboFamilyTypes.SelectedIndex = 0
        
        # Events
        self.btnGenerate.Click += self.generate
        self.btnCancel.Click += self.close
        
    def close(self, sender, args):
        self.dialog_result = False
        self.Close()
        
    def generate(self, sender, args):
        if not self.comboFamilyTypes.SelectedItem:
            forms.alert("Please select a column type.")
            return
            
        if self.listLevels.SelectedItems.Count < 2:
            forms.alert("Please select at least 2 levels (a base and a top) to generate columns.")
            return
            
        selected_level_names = list(self.listLevels.SelectedItems)
        self.selected_levels = [l for l in self.levels if l.Name in selected_level_names]
        self.selected_levels.sort(key=lambda l: l.Elevation)
            
        self.col_type = self.column_types[self.comboFamilyTypes.SelectedItem]
        self.is_spliced = self.rbSpliced.IsChecked
        
        self.dialog_result = True
        self.Close()

win = AutoColumnWindow('ui.xaml')
win.ShowDialog()

# --- EXECUTE AFTER WINDOW CLOSES TO PREVENT FATAL ERRORS ---
if win.dialog_result:
    with revit.Transaction("Activate Column Family"):
        if not win.col_type.IsActive:
            win.col_type.Activate()
            doc.Regenerate()
            
    # Find Grids
    grids = list(DB.FilteredElementCollector(doc).OfClass(DB.Grid).ToElements())
    if not grids:
        forms.alert("No grids found in the model.")
        sys.exit()
        
    intersections = []
    for i in range(len(grids)):
        curve_i = grids[i].Curve
        for j in range(i + 1, len(grids)):
            curve_j = grids[j].Curve
            
            import clr
            res_array = clr.Reference[DB.IntersectionResultArray]()
            intersect_result = curve_i.Intersect(curve_j, res_array)
            
            if intersect_result == DB.SetComparisonResult.Overlap and res_array.Value is not None:
                pt = res_array.Value.get_Item(0).XYZPoint
                intersections.append(pt)
                
    if not intersections:
        forms.alert("No grid intersections found.")
        sys.exit()
        
    # Place Columns
    count = 0
    with revit.Transaction("Auto Generate Columns"):
        for pt in intersections:
            if win.is_spliced:
                # Generate a discrete column for each story
                for i in range(len(win.selected_levels) - 1):
                    b_lvl = win.selected_levels[i]
                    t_lvl = win.selected_levels[i+1]
                    
                    place_pt = DB.XYZ(pt.X, pt.Y, b_lvl.Elevation)
                    col = doc.Create.NewFamilyInstance(place_pt, win.col_type, b_lvl, DB.Structure.StructuralType.Column)
                    
                    param_top_level = col.get_Parameter(DB.BuiltInParameter.FAMILY_TOP_LEVEL_PARAM)
                    if param_top_level: param_top_level.Set(t_lvl.Id)
                        
                    param_top_offset = col.get_Parameter(DB.BuiltInParameter.FAMILY_TOP_LEVEL_OFFSET_PARAM)
                    if param_top_offset: param_top_offset.Set(0.0)
                        
                    param_base_offset = col.get_Parameter(DB.BuiltInParameter.FAMILY_BASE_LEVEL_OFFSET_PARAM)
                    if param_base_offset: param_base_offset.Set(0.0)
                    
                    count += 1
            else:
                # Generate one continuous column spanning bottom to top
                b_lvl = win.selected_levels[0]
                t_lvl = win.selected_levels[-1]
                
                place_pt = DB.XYZ(pt.X, pt.Y, b_lvl.Elevation)
                col = doc.Create.NewFamilyInstance(place_pt, win.col_type, b_lvl, DB.Structure.StructuralType.Column)
                
                param_top_level = col.get_Parameter(DB.BuiltInParameter.FAMILY_TOP_LEVEL_PARAM)
                if param_top_level: param_top_level.Set(t_lvl.Id)
                    
                param_top_offset = col.get_Parameter(DB.BuiltInParameter.FAMILY_TOP_LEVEL_OFFSET_PARAM)
                if param_top_offset: param_top_offset.Set(0.0)
                    
                param_base_offset = col.get_Parameter(DB.BuiltInParameter.FAMILY_BASE_LEVEL_OFFSET_PARAM)
                if param_base_offset: param_base_offset.Set(0.0)
                
                count += 1
                
    forms.alert("Successfully generated {} structural columns!".format(count))
