# -*- coding: utf-8 -*-
from pyrevit import revit, DB, UI, forms
import sys
import os

doc = revit.doc

class AutoWallWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.dialog_result = False
        
        # Load Levels
        self.levels = list(DB.FilteredElementCollector(doc).OfClass(DB.Level).ToElements())
        self.levels.sort(key=lambda l: l.Elevation)
        self.listLevels.ItemsSource = [l.Name for l in self.levels]
            
        # Load Wall Types
        wall_types = DB.FilteredElementCollector(doc).OfClass(DB.WallType).ToElements()
        self.wall_types = {}
        for t in wall_types:
            name_param = t.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM)
            if not name_param: name_param = t.get_Parameter(DB.BuiltInParameter.ALL_MODEL_TYPE_NAME)
            if name_param and name_param.AsString(): self.wall_types[name_param.AsString()] = t
            else:
                try: self.wall_types[t.Name] = t
                except: self.wall_types["WallType_" + str(t.Id.IntegerValue)] = t
        
        self.comboFamilyTypes.ItemsSource = sorted(self.wall_types.keys())
        if self.wall_types: self.comboFamilyTypes.SelectedIndex = 0
        
        # Events
        self.btnGenerate.Click += self.generate
        self.btnCancel.Click += self.close
        
    def close(self, sender, args):
        self.dialog_result = False
        self.Close()
        
    def generate(self, sender, args):
        if not self.comboFamilyTypes.SelectedItem:
            forms.alert("Please select a wall type.")
            return
            
        if self.listLevels.SelectedItems.Count == 0:
            forms.alert("Please select at least 1 target level.")
            return
            
        selected_level_names = list(self.listLevels.SelectedItems)
        self.selected_levels = [l for l in self.levels if l.Name in selected_level_names]
        
        self.wall_type = self.wall_types[self.comboFamilyTypes.SelectedItem]
        self.dialog_result = True
        self.Close()

win = AutoWallWindow('ui.xaml')
win.ShowDialog()

# --- EXECUTE AFTER WINDOW CLOSES TO PREVENT FATAL ERRORS ---
if win.dialog_result:
    selection = revit.uidoc.Selection.GetElementIds()
    
    if not selection:
        # Post-selection interactive prompt
        from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
        class BeamPathFilter(ISelectionFilter):
            def AllowElement(self, elem):
                if elem.Category and elem.Category.Id.IntegerValue == int(DB.BuiltInCategory.OST_StructuralFraming): return True
                return False
            def AllowReference(self, ref, pos):
                return False
                
        try:
            refs = revit.uidoc.Selection.PickObjects(ObjectType.Element, BeamPathFilter(), "Select Structural Beams to define the wall paths. Click Finish on the Options Bar when done.")
            selection = [r.ElementId for r in refs]
        except Exception:
            # User hit ESC or Cancelled
            sys.exit()
            
    if not selection:
        sys.exit()
        
    curves = []
    for e_id in selection:
        beam = doc.GetElement(e_id)
        if beam.Category and beam.Category.Id.IntegerValue == int(DB.BuiltInCategory.OST_StructuralFraming):
            loc = beam.Location
            if isinstance(loc, DB.LocationCurve):
                loc_curve = loc.Curve
                if isinstance(loc_curve, DB.Line):
                    # Algorithm to get the exact physical trimmed length of the beam (avoiding column overlap)
                    opt = DB.Options()
                    opt.DetailLevel = DB.ViewDetailLevel.Coarse
                    geom_elem = beam.get_Geometry(opt)
                    
                    points = []
                    if geom_elem:
                        for geom_obj in geom_elem:
                            if isinstance(geom_obj, DB.Solid) and geom_obj.Faces.Size > 0:
                                for edge in geom_obj.Edges:
                                    points.append(edge.AsCurve().GetEndPoint(0))
                            elif isinstance(geom_obj, DB.GeometryInstance):
                                inst_geom = geom_obj.GetInstanceGeometry()
                                for inst_obj in inst_geom:
                                    if isinstance(inst_obj, DB.Solid) and inst_obj.Faces.Size > 0:
                                        for edge in inst_obj.Edges:
                                            points.append(edge.AsCurve().GetEndPoint(0))
                    
                    if points:
                        start_pt = loc_curve.GetEndPoint(0)
                        direction = loc_curve.Direction
                        
                        t_values = []
                        for p in points:
                            vec = p - start_pt
                            t = vec.DotProduct(direction)
                            t_values.append(t)
                            
                        if t_values:
                            min_t = min(t_values)
                            max_t = max(t_values)
                            
                            new_start = start_pt + direction.Multiply(min_t)
                            new_end = start_pt + direction.Multiply(max_t)
                            
                            if new_start.DistanceTo(new_end) > 0.5: # Valid wall length
                                curves.append(DB.Line.CreateBound(new_start, new_end))
                            else:
                                curves.append(loc_curve)
                        else:
                            curves.append(loc_curve)
                    else:
                        curves.append(loc_curve)
                else:
                    curves.append(loc_curve)
                
    if not curves:
        forms.alert("No valid structural beams found in selection.")
        sys.exit()
        
    # --- Eliminate Duplicate Stacked Curves ---
    # If the user selects beams across multiple stories, we don't want to generate 
    # redundant walls on the same footprint on every level.
    unique_curves = []
    seen_keys = set()
    
    for curve in curves:
        pt1 = curve.GetEndPoint(0)
        pt2 = curve.GetEndPoint(1)
        
        # Round to 1 decimal place (1.2 inches) and sort points to make it direction-agnostic
        pts = sorted([(round(pt1.X, 1), round(pt1.Y, 1)), (round(pt2.X, 1), round(pt2.Y, 1))])
        key = tuple(pts)
        
        if key not in seen_keys:
            seen_keys.add(key)
            unique_curves.append(curve)
            
    count = 0
    with revit.Transaction("Auto Generate Walls"):
        for lvl in win.selected_levels:
            for curve in unique_curves:
                # Wall height usually spans to the next level or a default height (e.g. 10ft) if no next level
                lvl_index = win.levels.index(lvl)
                if lvl_index < len(win.levels) - 1:
                    height = win.levels[lvl_index+1].Elevation - lvl.Elevation
                else:
                    height = 10.0 # Default top story height
                    
                # To create a structural wall
                wall = DB.Wall.Create(doc, curve, win.wall_type.Id, lvl.Id, height, 0.0, False, True)
                count += 1
            
    forms.alert("Successfully generated {} single structural walls across {} levels!".format(count, len(win.selected_levels)))
