# -*- coding: utf-8 -*-
from pyrevit import revit, DB, UI, forms
import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), "..", "..", "..", "lib"))
from SamToolsStructural import code_engines, database

doc = revit.doc

class AutoBeamWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.dialog_result = False
        
        # Load Levels
        self.levels = list(DB.FilteredElementCollector(doc).OfClass(DB.Level).ToElements())
        self.levels.sort(key=lambda l: l.Elevation)
        
        self.listLevels.ItemsSource = [l.Name for l in self.levels]
            
        # Load Beam Types
        beam_types = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_StructuralFraming).OfClass(DB.FamilySymbol).ToElements()
        self.beam_types = {t.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString(): t for t in beam_types}
        
        self.comboFamilyTypes.ItemsSource = sorted(self.beam_types.keys())
        if self.beam_types: self.comboFamilyTypes.SelectedIndex = 0
        
        # Load Floor Types
        floor_types = DB.FilteredElementCollector(doc).OfClass(DB.FloorType).ToElements()
        self.floor_types = {}
        for t in floor_types:
            name_param = t.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM)
            if not name_param: name_param = t.get_Parameter(DB.BuiltInParameter.ALL_MODEL_TYPE_NAME)
            if name_param and name_param.AsString(): self.floor_types[name_param.AsString()] = t
            else:
                try: self.floor_types[t.Name] = t
                except: self.floor_types["FloorType_" + str(t.Id.IntegerValue)] = t
                
        self.comboFloorTypes.ItemsSource = sorted(self.floor_types.keys())
        if self.floor_types: self.comboFloorTypes.SelectedIndex = 0
        
        # Events
        self.btnGenerate.Click += self.generate
        self.btnCancel.Click += self.close
        
    def close(self, sender, args):
        self.dialog_result = False
        self.Close()
        
    def generate(self, sender, args):
        if not self.comboFamilyTypes.SelectedItem:
            forms.alert("Please select a beam type.")
            return
            
        if self.listLevels.SelectedItems.Count == 0:
            forms.alert("Please select at least 1 target level.")
            return
            
        selected_level_names = list(self.listLevels.SelectedItems)
        self.selected_levels = [l for l in self.levels if l.Name in selected_level_names]
        
        self.beam_type = self.beam_types[self.comboFamilyTypes.SelectedItem]
        
        self.auto_slab = self.chkAutoSlab.IsChecked
        if self.auto_slab:
            if not self.comboFloorTypes.SelectedItem:
                forms.alert("Please select a slab type.")
                return
            self.floor_type = self.floor_types[self.comboFloorTypes.SelectedItem]
            
        self.dialog_result = True
        self.Close()

win = AutoBeamWindow('ui.xaml')
win.ShowDialog()

# --- EXECUTE AFTER WINDOW CLOSES TO PREVENT FATAL ERRORS ---
if win.dialog_result:
    with revit.Transaction("Activate Beam Family"):
        if not win.beam_type.IsActive:
            win.beam_type.Activate()
            doc.Regenerate()
            
    # Find Columns
    cols = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_StructuralColumns).WhereElementIsNotElementType().ToElements()
    
    if not cols:
        forms.alert("No columns found to span between.")
        sys.exit()
        
    # Extract UNIQUE 2D coordinates (ignoring Z) to prevent exponential duplicate generation
    unique_pts_dict = {}
    for c in cols:
        loc = c.Location
        if isinstance(loc, DB.LocationPoint):
            pt = loc.Point
            # Round to 2 decimal places to handle floating point errors
            key = (round(pt.X, 2), round(pt.Y, 2))
            if key not in unique_pts_dict:
                unique_pts_dict[key] = pt
                
    pts = list(unique_pts_dict.values())
            
    # Generate orthogonal pairs
    pairs = []
    
    for i in range(len(pts)):
        for j in range(i + 1, len(pts)):
            p1 = pts[i]
            p2 = pts[j]
            
            # Check orthogonal (sharing X or Y)
            if abs(p1.X - p2.X) < 0.1 or abs(p1.Y - p2.Y) < 0.1:
                dist = p1.DistanceTo(p2)
                if 1.0 < dist < 100.0: 
                    # Prevent overlapping beams: check if any other column lies directly between p1 and p2
                    has_midpoint = False
                    for pt in pts:
                        if pt.IsAlmostEqualTo(p1) or pt.IsAlmostEqualTo(p2):
                            continue
                        dist1 = p1.DistanceTo(pt)
                        dist2 = pt.DistanceTo(p2)
                        # If the sum of distances equals the total distance, the point is collinear and between them
                        if abs((dist1 + dist2) - dist) < 0.1:
                            has_midpoint = True
                            break
                            
                    if not has_midpoint:
                        pairs.append((p1, p2))
                    
    if not pairs:
        forms.alert("No valid orthogonal column spans found.")
        sys.exit()
        
    cells = []
    if win.auto_slab:
        # Determine 1x1 grid cells
        X_coords = sorted(list(set(round(p.X, 1) for p in pts)))
        Y_coords = sorted(list(set(round(p.Y, 1) for p in pts)))
        
        # Find all valid 1x1 cells where there are 4 perimeter beams
        for i in range(len(X_coords)-1):
            for j in range(len(Y_coords)-1):
                x1, x2 = X_coords[i], X_coords[i+1]
                y1, y2 = Y_coords[j], Y_coords[j+1]
                
                # Check if all 4 corners have columns
                def has_col(x, y):
                    for p in pts:
                        if abs(p.X - x) < 0.2 and abs(p.Y - y) < 0.2: return True
                    return False
                    
                if has_col(x1, y1) and has_col(x2, y1) and has_col(x2, y2) and has_col(x1, y2):
                    # Check if the 4 beams exist in pairs
                    def has_beam(bx1, by1, bx2, by2):
                        for p1, p2 in pairs:
                            if (abs(p1.X - bx1) < 0.2 and abs(p1.Y - by1) < 0.2 and abs(p2.X - bx2) < 0.2 and abs(p2.Y - by2) < 0.2) or \
                               (abs(p2.X - bx1) < 0.2 and abs(p2.Y - by1) < 0.2 and abs(p1.X - bx2) < 0.2 and abs(p1.Y - by2) < 0.2):
                               return True
                        return False
                        
                    if has_beam(x1, y1, x2, y1) and has_beam(x2, y1, x2, y2) and \
                       has_beam(x2, y2, x1, y2) and has_beam(x1, y2, x1, y1):
                       cells.append((x1, y1, x2, y2))
                       
    count = 0
    slab_count = 0
    with revit.Transaction("Auto Generate Beams & Slabs"):
        import System.Collections.Generic as SCG
        
        for lvl in win.selected_levels:
            for p1, p2 in pairs:
                start = DB.XYZ(p1.X, p1.Y, lvl.Elevation)
                end = DB.XYZ(p2.X, p2.Y, lvl.Elevation)
                curve = DB.Line.CreateBound(start, end)
                
                doc.Create.NewFamilyInstance(curve, win.beam_type, lvl, DB.Structure.StructuralType.Beam)
                count += 1
                
            if win.auto_slab and cells:
                for x1, y1, x2, y2 in cells:
                    loop = DB.CurveLoop()
                    p0 = DB.XYZ(x1, y1, lvl.Elevation)
                    p1 = DB.XYZ(x2, y1, lvl.Elevation)
                    p2 = DB.XYZ(x2, y2, lvl.Elevation)
                    p3 = DB.XYZ(x1, y2, lvl.Elevation)
                    
                    loop.Append(DB.Line.CreateBound(p0, p1))
                    loop.Append(DB.Line.CreateBound(p1, p2))
                    loop.Append(DB.Line.CreateBound(p2, p3))
                    loop.Append(DB.Line.CreateBound(p3, p0))
                    
                    loops = SCG.List[DB.CurveLoop]()
                    loops.Add(loop)
                    
                    try:
                        DB.Floor.Create(doc, loops, win.floor_type.Id, lvl.Id)
                        slab_count += 1
                    except Exception:
                        pass
            
    if win.auto_slab:
        forms.alert("Successfully generated {} structural beams and {} slabs across {} levels!".format(count, slab_count, len(win.selected_levels)))
    else:
        forms.alert("Successfully generated {} structural beams across {} levels!".format(count, len(win.selected_levels)))
