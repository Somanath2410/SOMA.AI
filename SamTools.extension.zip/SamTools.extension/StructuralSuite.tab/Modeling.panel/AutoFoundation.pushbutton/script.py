# -*- coding: utf-8 -*-
from pyrevit import revit, DB, UI, forms
import sys
import os

doc = revit.doc

class AutoFoundationWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.dialog_result = False
        # Load Levels
        self.levels = list(DB.FilteredElementCollector(doc).OfClass(DB.Level).ToElements())
        self.levels.sort(key=lambda l: l.Elevation)
        
        self.listLevels.ItemsSource = [l.Name for l in self.levels]
        
        # Load Foundation Types
        found_types = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_StructuralFoundation).OfClass(DB.FamilySymbol).ToElements()
        self.found_types = {t.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString(): t for t in found_types}
        
        self.comboFamilyTypes.ItemsSource = sorted(self.found_types.keys())
        if self.found_types: self.comboFamilyTypes.SelectedIndex = 0
        
        # Events
        self.btnGenerate.Click += self.generate
        self.btnCancel.Click += self.close
        
    def close(self, sender, args):
        self.dialog_result = False
        self.Close()
        
    def generate(self, sender, args):
        if not self.comboFamilyTypes.SelectedItem:
            forms.alert("Please select a foundation type.")
            return
            
        if self.listLevels.SelectedItems.Count == 0:
            forms.alert("Please select at least 1 target base level.")
            return
            
        selected_level_names = list(self.listLevels.SelectedItems)
        self.selected_levels = [l for l in self.levels if l.Name in selected_level_names]
            
        self.found_type = self.found_types[self.comboFamilyTypes.SelectedItem]
        self.dialog_result = True
        self.Close()

win = AutoFoundationWindow('ui.xaml')
win.ShowDialog()

# --- EXECUTE AFTER WINDOW CLOSES TO PREVENT FATAL ERRORS ---
if win.dialog_result:
    with revit.Transaction("Activate Foundation Family"):
        if not win.found_type.IsActive:
            win.found_type.Activate()
            doc.Regenerate()
            
    # Find Columns
    cols = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_StructuralColumns).WhereElementIsNotElementType().ToElements()
    
    if not cols:
        forms.alert("No columns found in model.")
        sys.exit()
        
    selected_level_ids = [lvl.Id.IntegerValue for lvl in win.selected_levels]
        
    count = 0
    with revit.Transaction("Auto Generate Foundations"):
        for col in cols:
            base_lvl_id = col.get_Parameter(DB.BuiltInParameter.FAMILY_BASE_LEVEL_PARAM).AsElementId()
            if base_lvl_id == DB.ElementId.InvalidElementId: continue
            
            # Filter: Only generate foundation if the column's base level is one of the selected levels
            if base_lvl_id.IntegerValue not in selected_level_ids:
                continue
            
            base_lvl = doc.GetElement(base_lvl_id)
            base_offset = col.get_Parameter(DB.BuiltInParameter.FAMILY_BASE_LEVEL_OFFSET_PARAM).AsDouble()
            
            loc = col.Location
            if isinstance(loc, DB.LocationPoint):
                pt = loc.Point
                place_pt = DB.XYZ(pt.X, pt.Y, base_lvl.Elevation + base_offset)
                
                footing = doc.Create.NewFamilyInstance(place_pt, win.found_type, base_lvl, DB.Structure.StructuralType.Footing)
                
                foot_offset = footing.get_Parameter(DB.BuiltInParameter.FLOOR_HEIGHTABOVELEVEL_PARAM)
                if foot_offset:
                    foot_offset.Set(base_offset)
                
                count += 1
            
    forms.alert("Successfully generated {} foundations!".format(count))
