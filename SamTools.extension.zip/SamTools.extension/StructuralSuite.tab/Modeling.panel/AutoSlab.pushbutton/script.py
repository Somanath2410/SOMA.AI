# -*- coding: utf-8 -*-
from pyrevit import revit, DB, UI, forms
import sys
import os

doc = revit.doc

class AutoSlabWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.dialog_result = False
        
        # Load Levels
        self.levels = list(DB.FilteredElementCollector(doc).OfClass(DB.Level).ToElements())
        self.levels.sort(key=lambda l: l.Elevation)
        
        self.listLevels.ItemsSource = [l.Name for l in self.levels]
        
        # Load Floor Types
        floor_types = DB.FilteredElementCollector(doc).OfClass(DB.FloorType).ToElements()
        self.floor_types = {}
        for t in floor_types:
            name_param = t.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM)
            if not name_param:
                name_param = t.get_Parameter(DB.BuiltInParameter.ALL_MODEL_TYPE_NAME)
            
            if name_param and name_param.AsString():
                self.floor_types[name_param.AsString()] = t
            else:
                try:
                    self.floor_types[t.Name] = t
                except:
                    self.floor_types["FloorType_" + str(t.Id.IntegerValue)] = t
        
        self.comboFamilyTypes.ItemsSource = sorted(self.floor_types.keys())
        if self.floor_types: self.comboFamilyTypes.SelectedIndex = 0
        
        # Events
        self.btnGenerate.Click += self.generate
        self.btnCancel.Click += self.close
        
    def close(self, sender, args):
        self.dialog_result = False
        self.Close()
        
    def generate(self, sender, args):
        if not self.comboFamilyTypes.SelectedItem:
            forms.alert("Please select a slab type.")
            return
            
        if self.listLevels.SelectedItems.Count == 0:
            forms.alert("Please select at least 1 target level.")
            return
            
        selected_level_names = list(self.listLevels.SelectedItems)
        self.selected_levels = [l for l in self.levels if l.Name in selected_level_names]
            
        self.floor_type = self.floor_types[self.comboFamilyTypes.SelectedItem]
        self.dialog_result = True
        self.Close()

win = AutoSlabWindow('ui.xaml')
win.ShowDialog()

# --- EXECUTE AFTER WINDOW CLOSES TO PREVENT FATAL ERRORS ---
if win.dialog_result:
    selection = revit.uidoc.Selection.GetElementIds()
    
    if not selection:
        # Post-selection interactive prompt
        from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
        class BeamFilter(ISelectionFilter):
            def AllowElement(self, elem):
                if elem.Category and elem.Category.Id.IntegerValue == int(DB.BuiltInCategory.OST_StructuralFraming): return True
                return False
            def AllowReference(self, ref, pos):
                return False
                
        try:
            refs = revit.uidoc.Selection.PickObjects(ObjectType.Element, BeamFilter(), "Select Structural Beams that form a closed slab boundary. Click Finish on the Options Bar when done.")
            selection = [r.ElementId for r in refs]
        except Exception:
            # User hit ESC or Cancelled
            sys.exit()
            
    if not selection:
        sys.exit()
        
    beams = []
    for e_id in selection:
        elem = doc.GetElement(e_id)
        if elem.Category and elem.Category.Id.IntegerValue == int(DB.BuiltInCategory.OST_StructuralFraming):
            beams.append(elem)
            
    if not beams:
        forms.alert("No structural beams found in selection.")
        sys.exit()
        
    raw_curves = []
    for beam in beams:
        loc = beam.Location
        if isinstance(loc, DB.LocationCurve):
            raw_curves.append(loc.Curve)
            
    if len(raw_curves) < 3:
        forms.alert("You must select at least 3 connected beams to form a closed slab boundary.")
        sys.exit()
        
    def get_continuous_loop(curves, z_elev):
        if not curves: return None
        
        # Extract 2D endpoints
        all_raw_lines = []
        for c in curves:
            p0 = c.GetEndPoint(0)
            p1 = c.GetEndPoint(1)
            all_raw_lines.append((DB.XYZ(p0.X, p0.Y, z_elev), DB.XYZ(p1.X, p1.Y, z_elev)))
            
        # Try starting from each line to find a valid closed loop
        for start_idx in range(len(all_raw_lines)):
            raw_lines = list(all_raw_lines)
            ordered_lines = [raw_lines.pop(start_idx)]
            
            success = False
            while True:
                last_pt = ordered_lines[-1][1]
                first_pt = ordered_lines[0][0]
                
                # Check if we naturally circled back to the start!
                if len(ordered_lines) >= 3 and last_pt.DistanceTo(first_pt) < 1.0:
                    success = True
                    break
                    
                found = False
                for i, line in enumerate(raw_lines):
                    p0, p1 = line
                    if p0.DistanceTo(last_pt) < 1.0: # Auto-snap up to 1ft gap
                        ordered_lines.append((last_pt, p1))
                        raw_lines.pop(i)
                        found = True
                        break
                    elif p1.DistanceTo(last_pt) < 1.0:
                        ordered_lines.append((last_pt, p0))
                        raw_lines.pop(i)
                        found = True
                        break
                        
                if not found:
                    break # Dead end, try next starting line
                    
            if success:
                # We found a loop! Ignore any leftover 'extra' beams in raw_lines
                # Snap last point to first point to perfectly close the loop
                first_pt = ordered_lines[0][0]
                last_idx = len(ordered_lines) - 1
                ordered_lines[last_idx] = (ordered_lines[last_idx][0], first_pt)
                        
                loop = DB.CurveLoop()
                for p0, p1 in ordered_lines:
                    if p0.DistanceTo(p1) > 0.01:
                        loop.Append(DB.Line.CreateBound(p0, p1))
                return loop
                
        return None # No closed loop found anywhere in selection

    count = 0
    with revit.Transaction("Auto Generate Slabs"):
        for lvl in win.selected_levels:
            loop = get_continuous_loop(raw_curves, lvl.Elevation)
            
            if loop is None:
                forms.alert("Failed to form a closed boundary on {}. Your beams have a gap larger than 1 foot or do not form a loop.".format(lvl.Name))
                continue
                
            try:
                import System.Collections.Generic as SCG
                loops = SCG.List[DB.CurveLoop]()
                loops.Add(loop)
                
                DB.Floor.Create(doc, loops, win.floor_type.Id, lvl.Id)
                count += 1
            except Exception as ex:
                forms.alert("Failed to create slab on {}.\n\nError: {}".format(lvl.Name, ex))
                continue
                
    if count > 0:
        forms.alert("Successfully generated {} structural slabs!".format(count))
