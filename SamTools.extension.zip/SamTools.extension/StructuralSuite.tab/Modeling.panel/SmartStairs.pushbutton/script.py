# -*- coding: utf-8 -*-
from pyrevit import revit, DB, UI, forms
import sys
import os

doc = revit.doc

class SmartStairsWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.dialog_result = False
        
        # Load Levels
        self.levels = list(DB.FilteredElementCollector(doc).OfClass(DB.Level).ToElements())
        self.levels.sort(key=lambda l: l.Elevation)
        
        # Load Stair Types
        stair_types = DB.FilteredElementCollector(doc).OfClass(DB.Architecture.StairsType).ToElements()
        self.stair_types = {}
        for t in stair_types:
            name_param = t.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM)
            if not name_param: name_param = t.get_Parameter(DB.BuiltInParameter.ALL_MODEL_TYPE_NAME)
            if name_param and name_param.AsString(): self.stair_types[name_param.AsString()] = t
            else:
                try: self.stair_types[t.Name] = t
                except: self.stair_types["StairsType_" + str(t.Id.IntegerValue)] = t
                
        self.comboFamilyTypes.ItemsSource = sorted(self.stair_types.keys())
        if self.stair_types: self.comboFamilyTypes.SelectedIndex = 0
        
        self.comboBaseLevel.ItemsSource = [l.Name for l in self.levels]
        self.comboTopLevel.ItemsSource = [l.Name for l in self.levels]
        
        if self.levels:
            self.comboBaseLevel.SelectedIndex = 0
            if len(self.levels) > 1: self.comboTopLevel.SelectedIndex = 1
            else: self.comboTopLevel.SelectedIndex = 0
        
        # Events
        self.btnGenerate.Click += self.generate
        self.btnCancel.Click += self.close
        
    def close(self, sender, args):
        self.dialog_result = False
        self.Close()
        
    def generate(self, sender, args):
        base_lvl_name = self.comboBaseLevel.SelectedItem
        top_lvl_name = self.comboTopLevel.SelectedItem
        
        self.base_level = next((l for l in self.levels if l.Name == base_lvl_name), None)
        self.top_level = next((l for l in self.levels if l.Name == top_lvl_name), None)
        
        if self.top_level.Elevation <= self.base_level.Elevation:
            forms.alert("Top level must be above Base level.")
            return
            
        if not self.comboFamilyTypes.SelectedItem:
            forms.alert("Please select a stair type.")
            return
            
        self.stair_type = self.stair_types[self.comboFamilyTypes.SelectedItem]
            
        self.dialog_result = True
        self.Close()

win = SmartStairsWindow('ui.xaml')
win.ShowDialog()

# --- EXECUTE AFTER WINDOW CLOSES TO PREVENT FATAL ERRORS ---
if win.dialog_result:
    try:
        from Autodesk.Revit.DB.Architecture import StairsEditScope, StairsRun, StairsRunJustification, StairsEditScopeFailureAction
        
        # StairsEditScope handles its own internal transactions
        edit_scope = StairsEditScope(doc, "Smart Stairs Generator")
        stair_id = edit_scope.Start(win.base_level.Id, win.top_level.Id)
        
        # Create a straight run
        height = win.top_level.Elevation - win.base_level.Elevation
        riser_count = int(height / 0.583)
        run_length = riser_count * 0.916
        
        p1 = DB.XYZ(0, 0, win.base_level.Elevation)
        p2 = DB.XYZ(run_length, 0, win.base_level.Elevation)
        
        run_line = DB.Line.CreateBound(p1, p2)
        
        StairsRun.CreateStraightRun(doc, stair_id, run_line, StairsRunJustification.Center)
        
        edit_scope.Commit(StairsEditScopeFailureAction.FailAndRollback)
        
        # Change the stair type to the selected type
        with revit.Transaction("Change Stair Type"):
            stair = doc.GetElement(stair_id)
            if stair:
                stair.ChangeTypeId(win.stair_type.Id)
                
        forms.alert("Successfully generated a straight-run stair from {} to {}! It is located at the project origin (0,0,0).".format(win.base_level.Name, win.top_level.Name))
        
    except Exception as e:
        forms.alert("Failed to create Smart Stair. This is often due to missing default Stair Types in your Revit template.\n\nError: {}".format(e))
